import os

try:
    import webview
except ImportError:
    webview = None

class Api:
    """Exposes Python functions to the JavaScript frontend."""
    def __init__(self, engine=None, backup_manager=None):
        self.engine = engine
        self.backup_manager = backup_manager

    def send_message(self, text):
        if self.engine:
            return self.engine.process_input(text)
        return f"[Stub] Processed: {text}"

    def start_arena_match(self):
        return "> Arena match started! Ashley vs Cortana... (Simulated Win for Ashley)"

    def run_diagnostics(self):
        return "> Diagnostics complete. No syntax errors found in project."

    def create_backup(self):
        if self.backup_manager:
            result = self.backup_manager.create_backup()
            return f"> Backup result: {result}" if result else "> No changes detected. Backup skipped."
        return "> Smart backup created successfully (Stub)."

class PyWebShell:
    """
    A modern HTML/CSS/JS GUI shell using PyWebView.
    Replaces the Tkinter/Pygame hybrid for a more flexible, web-standard interface.
    """
    def __init__(self, engine=None, backup_manager=None):
        self.api = Api(engine, backup_manager)
        self.html_path = os.path.join(os.path.dirname(__file__), 'web', 'index.html')

    def run(self):
        if webview is None:
            print("[Error] pywebview is not installed.")
            self._fallback()
            return
            
        print("[PyWebShell] Launching modern web-based GUI...")
        try:
            window = webview.create_window('Ashley AI Studio', url=self.html_path, js_api=self.api, width=1200, height=800)
            webview.start()
        except Exception as e:
            print(f"[PyWebShell] Native GUI failed to launch: {e}")
            self._fallback()

    def _fallback(self):
        print("\n" + "="*50)
        print("                 HEADLESS MODE ACTIVE                 ")
        print("==================================================")
        print("It looks like you are running in a headless environment")
        print("(like a cloud sandbox or SSH terminal) without a display.")
        print(f"\nYour GUI is ready and can be opened directly in your browser!")
        print(f"File location: {self.html_path}")
        print("==================================================\n")