import os
import zipfile
import hashlib
from datetime import datetime

class BackupManager:
    """
    Smart Backup System.
    Hashes the directory to only create backups when actual changes occur.
    """
    def __init__(self, source_dir, backup_dir):
        self.source_dir = source_dir
        self.backup_dir = backup_dir
        self.last_hash_file = os.path.join(backup_dir, ".last_hash")
        os.makedirs(self.backup_dir, exist_ok=True)

    def _get_directory_hash(self):
        hasher = hashlib.md5()
        for root, _, files in os.walk(self.source_dir):
            if 'backups' in root or '__pycache__' in root:
                continue
            for file in sorted(files):
                filepath = os.path.join(root, file)
                try:
                    with open(filepath, 'rb') as f:
                        hasher.update(f.read())
                except Exception:
                    pass
        return hasher.hexdigest()

    def create_backup(self, prefix="backup"):
        try:
            current_hash = self._get_directory_hash()
            
            if os.path.exists(self.last_hash_file):
                with open(self.last_hash_file, 'r') as f:
                    last_hash = f.read().strip()
                if current_hash == last_hash:
                    print("[BackupManager] No changes detected. Skipping backup.")
                    return None

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{prefix}_{timestamp}.zip"
            backup_path = os.path.join(self.backup_dir, backup_name)
            
            print(f"[BackupManager] Changes detected. Creating backup: {backup_name}...")
            
            with zipfile.ZipFile(backup_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(self.source_dir):
                    if 'backups' in root or '__pycache__' in root:
                        continue
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, self.source_dir)
                        zipf.write(file_path, arcname)
                        
            with open(self.last_hash_file, 'w') as f:
                f.write(current_hash)
                
            print(f"[BackupManager] Backup saved successfully to {backup_path}")
            return backup_path
        except OSError as e:
            print(f"[BackupManager] Failed to create backup (OS Error - likely out of disk space): {e}")
            return None
        except Exception as e:
            print(f"[BackupManager] Failed to create backup: {e}")
            return None