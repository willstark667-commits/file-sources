import os
import sys

# Add the current directory to the path so imports work correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from engine.tools.diagnostics import CodeDiagnostic

class PreLaunchTester:
    """
    Runs a quick diagnostic check before launching the Studio.
    If critical errors are found, it triggers an emergency fallback.
    """
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.diagnostic = CodeDiagnostic(base_dir)

    def run_tests(self):
        print("[PreLaunchTester] Running syntax diagnostics...")
        errors = self.diagnostic.check_syntax()
        
        if errors:
            print("[PreLaunchTester] CRITICAL ERRORS FOUND:")
            for error in errors:
                print(f"  - {error}")
            return False
            
        print("[PreLaunchTester] All systems nominal. No syntax errors detected.")
        return True