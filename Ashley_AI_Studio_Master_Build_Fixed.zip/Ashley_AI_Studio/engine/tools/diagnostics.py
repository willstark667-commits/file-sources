import ast
import os

class CodeDiagnostic:
    """
    Scans Python files for syntax errors before launching.
    """
    def __init__(self, root_dir):
        self.root_dir = root_dir

    def check_syntax(self):
        errors = []
        for subdir, _, files in os.walk(self.root_dir):
            for file in files:
                if file.endswith('.py'):
                    filepath = os.path.join(subdir, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8') as f:
                            ast.parse(f.read(), filename=filepath)
                    except SyntaxError as e:
                        errors.append(f"Syntax Error in {filepath}: {e}")
                    except Exception as e:
                        errors.append(f"Error reading {filepath}: {e}")
        return errors