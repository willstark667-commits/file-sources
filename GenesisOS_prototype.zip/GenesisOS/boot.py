"""
boot.py
--------
Genesis OS entry point.

    python3 boot.py

Sequence: load BIOS -> run POST on virtual CPU/RAM/disk -> mount filesystem
-> load or seed the neural core -> run one diagnostics pass (repairing
anything fixable) -> hand off to the tkinter desktop shell.

All boot text is collected into `boot_lines` and replayed as a typewriter
animation in the desktop shell, so what you see on screen is exactly what
really happened during boot, not a canned script.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from genesis_os import config, bios
from genesis_os.kernel.memory import VirtualRAM
from genesis_os.kernel.filesystem import VirtualFileSystem
from genesis_os.kernel.cpu import VirtualCPU
from genesis_os.kernel.diagnostics import DiagnosticsEngine
from genesis_os.kernel.scheduler import Scheduler
from genesis_os.ai.neural_core import GrowingNeuralNetwork
from genesis_os.desktop import desktop


def main():
    config.ensure_dirs()
    boot_lines = []
    log = boot_lines.append

    log("GENESIS OS")
    log("=" * 40)

    # 1. Hardware
    ram = VirtualRAM()
    disk = VirtualFileSystem()
    cpu = VirtualCPU(ram)

    # 2. BIOS / POST
    post = bios.BIOS(ram, disk, cpu, log_fn=log)
    report = post.run()

    # 3. Neural core: load existing checkpoint, or seed a new one
    log("")
    log("Loading neural core...")
    try:
        if config.NEURAL_WEIGHTS_PATH.exists():
            net = GrowingNeuralNetwork.load()
            log(f"  checkpoint found: generation={net.generation} "
                f"hidden={net.hidden_size} steps={net.training_steps}")
        else:
            net = GrowingNeuralNetwork()
            net.save()
            log("  no checkpoint found -- seeded a fresh network and saved it.")
    except Exception as exc:  # noqa: BLE001
        log(f"  checkpoint load failed ({exc}); seeding fresh network.")
        net = GrowingNeuralNetwork()
        net.save()

    # 4. Diagnostics pass (scan + auto-repair anything fixable)
    log("")
    log("Running boot diagnostics...")
    diagnostics = DiagnosticsEngine(ram, disk, neural_core=net, log_fn=log)
    diag_report = diagnostics.scan()
    if diag_report.healthy:
        log("  no issues found.")
    else:
        for issue in diag_report.issues:
            log(f"  issue: [{issue['severity']}] {issue['subsystem']}: {issue['problem']}")
        diagnostics.attempt_repair(diag_report)
        for rep in diag_report.repairs:
            log(f"  repair: {rep['subsystem']} -> {rep['action']} ({rep['result']})")

    # 5. Scheduler (available to the desktop for future background tasks)
    scheduler = Scheduler()

    log("")
    log(f"POST: {'PASSED' if report['post_passed'] else 'FAILED (see diagnostics)'}")
    log("Starting desktop environment...")

    system = {
        "ram": ram,
        "disk": disk,
        "cpu": cpu,
        "neural": net,
        "diagnostics": diagnostics,
        "scheduler": scheduler,
        "bios_report": report,
    }

    desktop.launch(system, boot_lines)


if __name__ == "__main__":
    main()
