"""
genesis_os.desktop.desktop
------------------------------
The tkinter shell: an animated boot screen followed by a CRT-styled desktop
with a taskbar and four apps (Terminal, Neural Monitor, Diagnostics,
File Manager). Each app is a Toplevel window that talks directly to the
kernel/AI objects passed in from boot.py -- there's no hidden global state.
"""

import tkinter as tk
from tkinter import scrolledtext

from .. import config
from ..config import Theme


# ---------------------------------------------------------------------------
# Boot screen
# ---------------------------------------------------------------------------
class BootScreen(tk.Frame):
    """Shows boot_lines one at a time with a typewriter effect, then calls
    on_complete()."""

    def __init__(self, master, boot_lines, on_complete):
        super().__init__(master, bg=Theme.BG)
        self.on_complete = on_complete
        self.text = tk.Text(
            self, bg=Theme.BG, fg=Theme.GREEN, insertbackground=Theme.GREEN,
            font=Theme.FONT_MONO, borderwidth=0, highlightthickness=0, wrap="word",
        )
        self.text.pack(fill="both", expand=True, padx=24, pady=24)
        self.text.config(state="disabled")
        self._lines = list(boot_lines)
        self._line_idx = 0
        self._char_idx = 0
        self.after(150, self._type_next)

    def _type_next(self):
        if self._line_idx >= len(self._lines):
            self.after(400, self.on_complete)
            return
        line = self._lines[self._line_idx]
        self.text.config(state="normal")
        if self._char_idx == 0 and self._line_idx > 0:
            self.text.insert("end", "\n")
        if self._char_idx < len(line):
            self.text.insert("end", line[self._char_idx])
            self.text.see("end")
            self._char_idx += 1
            self.text.config(state="disabled")
            self.after(config.BOOT_TYPE_DELAY_MS, self._type_next)
        else:
            self._char_idx = 0
            self._line_idx += 1
            self.text.config(state="disabled")
            self.after(20, self._type_next)


# ---------------------------------------------------------------------------
# Shared helpers for app windows
# ---------------------------------------------------------------------------
def _style_window(win, title, w=560, h=420):
    win.title(title)
    win.geometry(f"{w}x{h}")
    win.configure(bg=Theme.PANEL_BG)
    return win


def _output_box(parent):
    box = scrolledtext.ScrolledText(
        parent, bg=Theme.BG, fg=Theme.GREEN, insertbackground=Theme.GREEN,
        font=Theme.FONT_MONO, borderwidth=0, highlightthickness=1,
        highlightbackground=Theme.DIM_GREEN, wrap="word",
    )
    box.pack(fill="both", expand=True, padx=8, pady=8)
    box.config(state="disabled")
    return box


def _append(box, text, tag_color=None):
    box.config(state="normal")
    box.insert("end", text + "\n")
    box.see("end")
    box.config(state="disabled")


# ---------------------------------------------------------------------------
# Terminal
# ---------------------------------------------------------------------------
class TerminalWindow(tk.Toplevel):
    def __init__(self, master, system):
        super().__init__(master)
        _style_window(self, "Genesis Terminal", 640, 440)
        self.system = system  # dict of shared kernel/ai objects

        self.output = _output_box(self)
        _append(self.output, "Genesis OS terminal. Type 'help' for commands.")

        entry_frame = tk.Frame(self, bg=Theme.PANEL_BG)
        entry_frame.pack(fill="x", padx=8, pady=(0, 8))
        tk.Label(entry_frame, text=">", bg=Theme.PANEL_BG, fg=Theme.AMBER,
                  font=Theme.FONT_MONO).pack(side="left")
        self.entry = tk.Entry(
            entry_frame, bg=Theme.BG, fg=Theme.GREEN, insertbackground=Theme.GREEN,
            font=Theme.FONT_MONO, borderwidth=0, highlightthickness=1,
            highlightbackground=Theme.DIM_GREEN,
        )
        self.entry.pack(side="left", fill="x", expand=True, padx=6)
        self.entry.bind("<Return>", self._on_enter)
        self.entry.focus_set()

    def _on_enter(self, _event):
        cmd_line = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd_line:
            return
        _append(self.output, f"> {cmd_line}")
        self._run(cmd_line)

    def _run(self, cmd_line):
        parts = cmd_line.split()
        cmd, args = parts[0].lower(), parts[1:]
        disk = self.system["disk"]
        cpu = self.system["cpu"]
        net = self.system["neural"]
        diag = self.system["diagnostics"]

        try:
            if cmd == "help":
                _append(self.output,
                        "commands: help, ls, cat <path>, write <path> <text>, "
                        "run <inline asm ; separated>, neuralstat, train [n], "
                        "grow, scan, repair, clear, exit")
            elif cmd == "ls":
                for p in disk.list_dir():
                    _append(self.output, p)
            elif cmd == "cat":
                _append(self.output, disk.read_file(args[0]))
            elif cmd == "write":
                path = args[0]
                content = " ".join(args[1:])
                disk.write_file(path, content)
                _append(self.output, f"wrote {len(content)} bytes to {path}")
            elif cmd == "run":
                src = " ".join(args).replace(";", "\n")
                lines_out = []
                cpu2 = cpu
                cpu2.output_fn = lambda t: lines_out.append(t)
                cpu2.load(src)
                cpu2.run()
                for line in lines_out:
                    _append(self.output, line)
                _append(self.output, f"registers: {cpu2.registers}")
            elif cmd == "neuralstat":
                _append(self.output,
                        f"generation={net.generation} hidden={net.hidden_size} "
                        f"steps={net.training_steps} valid={net.is_valid()} "
                        f"last_loss={(net.history[-1] if net.history else 'n/a')}")
            elif cmd == "train":
                n = int(args[0]) if args else 128
                bits, path = net.generate_training_bit_sequence(length=n, rng_seed=None)
                losses = net.train_on_sequence(bits)
                net.save()
                _append(self.output, f"trained on {n} self-generated bits -> {path.name}")
                _append(self.output, f"final loss: {losses[-1]:.4f}")
            elif cmd == "grow":
                net.add_hidden_neuron()
                net.save()
                _append(self.output, f"grew network -> hidden_size={net.hidden_size} generation={net.generation}")
            elif cmd == "scan":
                report = diag.scan()
                _append(self.output, f"healthy={report.healthy} issues={report.issues}")
            elif cmd == "repair":
                report = diag.scan()
                diag.attempt_repair(report)
                _append(self.output, f"repairs={report.repairs}")
            elif cmd == "clear":
                self.output.config(state="normal")
                self.output.delete("1.0", "end")
                self.output.config(state="disabled")
            elif cmd == "exit":
                self.destroy()
            else:
                _append(self.output, f"unknown command: {cmd}")
        except Exception as exc:  # noqa: BLE001
            _append(self.output, f"error: {exc}")


# ---------------------------------------------------------------------------
# Neural Monitor
# ---------------------------------------------------------------------------
class NeuralMonitorWindow(tk.Toplevel):
    def __init__(self, master, system):
        super().__init__(master)
        _style_window(self, "Neural Monitor", 520, 420)
        self.system = system
        self.net = system["neural"]

        self.stats = tk.Label(self, justify="left", anchor="w", bg=Theme.PANEL_BG,
                               fg=Theme.AMBER, font=Theme.FONT_MONO)
        self.stats.pack(fill="x", padx=10, pady=10)

        self.canvas = tk.Canvas(self, bg=Theme.BG, height=180, highlightthickness=1,
                                 highlightbackground=Theme.DIM_GREEN)
        self.canvas.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        btns = tk.Frame(self, bg=Theme.PANEL_BG)
        btns.pack(fill="x", padx=10, pady=(0, 10))
        for label, cmd in [
            ("Train on new sequence", self._train),
            ("Grow neuron", self._grow),
            ("Save checkpoint", self._save),
        ]:
            tk.Button(btns, text=label, command=cmd, bg=Theme.PANEL_BG, fg=Theme.GREEN,
                      activebackground=Theme.DIM_GREEN, font=Theme.FONT_MONO,
                      relief="flat", borderwidth=1, highlightbackground=Theme.DIM_GREEN
                      ).pack(side="left", padx=4)

        self._refresh()

    def _train(self):
        bits, _path = self.net.generate_training_bit_sequence(length=128)
        self.net.train_on_sequence(bits)
        self.net.save()
        self._refresh()

    def _grow(self):
        self.net.add_hidden_neuron()
        self.net.save()
        self._refresh()

    def _save(self):
        self.net.save()
        self._refresh()

    def _refresh(self):
        n = self.net
        last_loss = f"{n.history[-1]:.4f}" if n.history else "n/a"
        self.stats.config(
            text=(f"generation:      {n.generation}\n"
                  f"hidden neurons:  {n.hidden_size}\n"
                  f"training steps:  {n.training_steps}\n"
                  f"last loss:       {last_loss}\n"
                  f"checkpoint valid: {n.is_valid()}")
        )
        self.canvas.delete("all")
        history = n.history[-100:]
        if len(history) > 1:
            w = int(self.canvas["width"]) if self.canvas["width"] else 480
            h = 180
            max_loss = max(history) or 1.0
            step_x = max(w / max(len(history) - 1, 1), 1)
            points = []
            for i, loss in enumerate(history):
                x = i * step_x
                y = h - (loss / max_loss) * (h - 10) - 5
                points.extend([x, y])
            if len(points) >= 4:
                self.canvas.create_line(*points, fill=Theme.GREEN, width=2)
        self.after(2000, self._refresh)


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------
class DiagnosticsWindow(tk.Toplevel):
    def __init__(self, master, system):
        super().__init__(master)
        _style_window(self, "Diagnostics", 560, 420)
        self.system = system

        btns = tk.Frame(self, bg=Theme.PANEL_BG)
        btns.pack(fill="x", padx=10, pady=10)
        tk.Button(btns, text="Run Scan", command=self._scan, bg=Theme.PANEL_BG,
                  fg=Theme.GREEN, activebackground=Theme.DIM_GREEN, font=Theme.FONT_MONO,
                  relief="flat", borderwidth=1, highlightbackground=Theme.DIM_GREEN
                  ).pack(side="left", padx=4)
        tk.Button(btns, text="Attempt Repair", command=self._repair, bg=Theme.PANEL_BG,
                  fg=Theme.AMBER, activebackground=Theme.DIM_GREEN, font=Theme.FONT_MONO,
                  relief="flat", borderwidth=1, highlightbackground=Theme.DIM_GREEN
                  ).pack(side="left", padx=4)

        self.output = _output_box(self)
        self._last_report = None

    def _scan(self):
        report = self.system["diagnostics"].scan()
        self._last_report = report
        self.output.config(state="normal")
        self.output.delete("1.0", "end")
        self.output.config(state="disabled")
        _append(self.output, f"healthy: {report.healthy}")
        for issue in report.issues:
            _append(self.output, f"  [{issue['severity']}] {issue['subsystem']}: {issue['problem']}")
        if not report.issues:
            _append(self.output, "  no issues found.")

    def _repair(self):
        if self._last_report is None:
            self._scan()
        diag = self.system["diagnostics"]
        diag.attempt_repair(self._last_report)
        for rep in self._last_report.repairs:
            _append(self.output, f"  repair[{rep['subsystem']}]: {rep['action']} -> {rep['result']}")


# ---------------------------------------------------------------------------
# File Manager
# ---------------------------------------------------------------------------
class FileManagerWindow(tk.Toplevel):
    def __init__(self, master, system):
        super().__init__(master)
        _style_window(self, "File Manager", 640, 440)
        self.system = system
        self.disk = system["disk"]

        paned = tk.Frame(self, bg=Theme.PANEL_BG)
        paned.pack(fill="both", expand=True, padx=8, pady=8)

        left = tk.Frame(paned, bg=Theme.PANEL_BG, width=200)
        left.pack(side="left", fill="y")
        self.listbox = tk.Listbox(
            left, bg=Theme.BG, fg=Theme.GREEN, font=Theme.FONT_MONO,
            highlightthickness=1, highlightbackground=Theme.DIM_GREEN,
            selectbackground=Theme.DIM_GREEN,
        )
        self.listbox.pack(fill="both", expand=True)
        self.listbox.bind("<<ListboxSelect>>", self._on_select)

        right = tk.Frame(paned, bg=Theme.PANEL_BG)
        right.pack(side="left", fill="both", expand=True, padx=(8, 0))
        self.viewer = _output_box(right)

        self._refresh_list()

    def _refresh_list(self):
        self.listbox.delete(0, "end")
        for p in self.disk.list_dir():
            self.listbox.insert("end", p)

    def _on_select(self, _event):
        sel = self.listbox.curselection()
        if not sel:
            return
        path = self.listbox.get(sel[0])
        content = self.disk.read_file(path)
        self.viewer.config(state="normal")
        self.viewer.delete("1.0", "end")
        self.viewer.insert("end", content)
        self.viewer.config(state="disabled")


# ---------------------------------------------------------------------------
# Desktop shell
# ---------------------------------------------------------------------------
class Desktop(tk.Frame):
    APPS = [
        ("Terminal", TerminalWindow),
        ("Neural Monitor", NeuralMonitorWindow),
        ("Diagnostics", DiagnosticsWindow),
        ("File Manager", FileManagerWindow),
    ]

    def __init__(self, master, system):
        super().__init__(master, bg=Theme.BG)
        self.system = system

        header = tk.Label(
            self, text="GENESIS OS", bg=Theme.BG, fg=Theme.AMBER,
            font=Theme.FONT_TITLE,
        )
        header.pack(pady=(24, 4))
        sub = tk.Label(
            self, text="virtual desktop  //  phase 1", bg=Theme.BG, fg=Theme.DIM_GREEN,
            font=Theme.FONT_MONO,
        )
        sub.pack(pady=(0, 24))

        icons = tk.Frame(self, bg=Theme.BG)
        icons.pack()
        for label, window_cls in self.APPS:
            btn = tk.Button(
                icons, text=label, width=18, height=3,
                command=lambda wc=window_cls: wc(self.winfo_toplevel(), self.system),
                bg=Theme.PANEL_BG, fg=Theme.GREEN, activebackground=Theme.DIM_GREEN,
                activeforeground=Theme.AMBER, font=Theme.FONT_MONO, relief="flat",
                borderwidth=1, highlightbackground=Theme.DIM_GREEN,
            )
            btn.pack(side="left", padx=10, pady=10)

        taskbar = tk.Frame(self, bg=Theme.PANEL_BG, height=28)
        taskbar.pack(side="bottom", fill="x")
        tk.Label(
            taskbar, text=" Genesis OS ready.", bg=Theme.PANEL_BG, fg=Theme.DIM_GREEN,
            font=Theme.FONT_MONO, anchor="w",
        ).pack(side="left")


def launch(system, boot_lines):
    """Entry point called by boot.py. `system` is a dict of live kernel/ai
    objects; `boot_lines` is the text already produced by BIOS + kernel init."""
    root = tk.Tk()
    root.title("Genesis OS")
    root.geometry("900x600")
    root.configure(bg=Theme.BG)

    container = tk.Frame(root, bg=Theme.BG)
    container.pack(fill="both", expand=True)

    def show_desktop():
        for child in container.winfo_children():
            child.destroy()
        Desktop(container, system).pack(fill="both", expand=True)

    boot_screen = BootScreen(container, boot_lines, on_complete=show_desktop)
    boot_screen.pack(fill="both", expand=True)

    root.mainloop()
