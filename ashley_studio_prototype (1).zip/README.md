# Ashley AI Studio — Extension Prototype

This zip contains: your original `ashley_ai_studio.py` (one small patch applied,
see below), three new standalone modules, and this integration guide.

## What's in here

```
ashley_ai_studio.py          <- your file, one small fix applied (see below)
ashley_studio_extensions/
    draft_verify.py           <- draft/verify (speculative-decoding-style) engine
    ollama_blobs.py           <- local Ollama model inventory scanner
    virtual_desktop.py        <- "kernel" -> Virtual Desktop terminology + wrapper
    RAG_AUDIT.md              <- concrete audit of VectorIndex/KnowledgeGraph
README.md                     <- this file
```

## 1. The one patch already applied to `ashley_ai_studio.py`

`LLMBridge.chat()` had `"num_predict": 512` hardcoded — this was your known
pending issue (short/cut-off responses). It's now `self.num_predict = 2048`,
set in `__init__`, so you can change it in one place or per-instance
(`shell.llm.num_predict = 4096`) instead of editing the request payload.

## 2. Draft/Verify engine (`draft_verify.py`)

Implements the intern/boss workflow you described: a fast drafter model
writes, a verifier model scores it (accuracy/coherence/code_quality/
efficiency/overall) and either publishes, requests a revision, or rejects
outright, looping up to `MAX_CYCLES` times. Nothing returns until the
verifier's score clears `PUBLISH_THRESHOLD` or cycles run out.

Wire it in wherever `LLMBridge` is already used, e.g. inside `AshleyShell`:

```python
from ashley_studio_extensions.draft_verify import DraftVerifyEngine

engine = DraftVerifyEngine(
    backend=self.llm,                 # your existing LLMBridge instance
    drafter_model="phi3",             # small/fast — the "intern"
    verifier_model="mistral",         # bigger — the "boss/publisher"
)
report = engine.publish("Write a function that reverses a linked list")
print(report.final_text, report.published, report.cycles_used)
```

**Read the note at the bottom of that file** before you assume this is
token-level speculative decoding — it's a chunk-level approximation that
gets you the actual behavior you described (draft → check → revise →
publish) using APIs Ollama actually exposes today. True parallel-token
speculative decoding needs raw logit access; the file explains the two real
paths to that (Ollama's `/v1` OpenAI-compatible endpoint, or llama.cpp's
native `--model-draft` flag) if you want to chase it later.

## 3. Ollama blob/manifest scanner (`ollama_blobs.py`)

```python
from ashley_studio_extensions.ollama_blobs import OllamaBlobScanner

scanner = OllamaBlobScanner()   # auto-detects ~/.ollama/models, or pass root=
print(scanner.summary())
```

Run this **on your own machine** (it needs your actual `.ollama` folder,
which isn't present in this sandbox — I tested it here against a Linux path
and confirmed it degrades cleanly when the folder's missing, but the real
output will only show up when you run it against your Windows
`C:\Users\wills\.ollama\models`).

Important reality check baked into the file's docstring: blobs are frozen
GGUF weights, not something you scan to "train" a model. This tool gives you
inventory (which models, what size, which blobs are present/missing) for
your `ModelRouter` to pick from — it is not a training data source.

## 4. Virtual Desktop layer (`virtual_desktop.py`)

Your only literal "kernel" references were Windows' `kernel32.dll` calls in
`_win_bootstrap()` — those have to keep that exact name, they're OS API
lookups. What actually wanted renaming was the conceptual "thing that
decides which front-end to boot." That's now an explicit `VirtualDesktop`
class with registered "workspaces" (gui/shell/web), replacing an implicit
if/elif in `main()`:

```python
from ashley_studio_extensions.virtual_desktop import build_default_desktop

vd = build_default_desktop(launch_gui, launch_web, AshleyShell)
vd.open(args.mode or "gui", default_model=args.model)
```

## 5. RAG audit (`RAG_AUDIT.md`)

Concrete gaps found in `VectorIndex`/`KnowledgeGraph`, ranked by actual
impact, with the specific next build called out (chunk-level indexing reusing
your existing AST scanner, mtime-based re-index skipping, and graph-hop
expansion joining `KnowledgeGraph` edges onto vector search hits).

## Suggested build order from here
1. Drop the three new modules next to `ashley_ai_studio.py`, confirm imports
   don't collide with your in-progress `ashley_studio/` package refactor.
2. Run `ollama_blobs.py` standalone on your machine to confirm the manifest
   parser matches your actual folder layout (Ollama's on-disk format has
   changed between versions — worth a sanity check before depending on it).
3. Wire `DraftVerifyEngine` into one command path in `AshleyShell` (not the
   whole app at once) and test with two real local models.
4. Tackle `RAG_AUDIT.md` item 1 (chunking) — everything else in that file
   builds on top of it.
5. Swap `main()`'s launch-mode dispatch over to `VirtualDesktop` once the
   above are stable — it's a pure refactor, no behavior change, so do it last
   when you're not simultaneously debugging new features.
