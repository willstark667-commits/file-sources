"""
Thin Ollama client using only the standard library (urllib) -- no
extra pip dependency required just to talk to a local Ollama server.

Used for two things in this project:
  1. Chat responses (the actual "intelligence" behind the persona).
  2. As a lightweight "management" pass over scan/training results --
     asking the model to summarize what a batch of files are about,
     or to give a one-line status readout of the network's progress.

If Ollama isn't running (or the model isn't pulled), every call fails
soft and returns a clear explanatory string instead of raising into
the GUI.
"""

import json
import time
import urllib.request
import urllib.error

from . import config


class OllamaError(Exception):
    pass


def _post(path, payload, timeout=30):
    url = config.OLLAMA_HOST.rstrip("/") + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        raise OllamaError(f"can't reach Ollama at {config.OLLAMA_HOST} ({e}). "
                           f"Is `ollama serve` running, and is '{config.OLLAMA_MODEL}' pulled?") from e


def is_available():
    try:
        req = urllib.request.Request(config.OLLAMA_HOST.rstrip("/") + "/api/tags")
        with urllib.request.urlopen(req, timeout=2):
            return True
    except Exception:
        return False


def list_models_detailed():
    """Detects what Ollama models are actually pulled on this machine --
    the real answer to 'does Ollama have any models'. Returns [] if
    Ollama isn't running or nothing's pulled, never raises."""
    try:
        req = urllib.request.Request(config.OLLAMA_HOST.rstrip("/") + "/api/tags")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        out = []
        for m in data.get("models", []):
            details = m.get("details", {}) or {}
            size_bytes = m.get("size", 0) or 0
            out.append({
                "name": m.get("name", ""), "size_gb": round(size_bytes / (1024 ** 3), 2),
                "parameter_size": details.get("parameter_size", "?"),
                "quantization": details.get("quantization_level", "?"),
                "family": details.get("family", "?"),
            })
        return out
    except Exception:
        return []


def list_models():
    return [m["name"] for m in list_models_detailed()]


_warmed_models = set()


def warm_up(model=None, timeout=60):
    """Sends a 1-token throwaway request so the model is already loaded
    in memory before the person's first real message -- this is the
    concrete fix for 'first message feels slow, later ones don't': the
    cold-load cost (reading the model file into RAM/VRAM) gets paid here
    instead of during the person's first real chat turn."""
    model = model or config.OLLAMA_MODEL
    if model in _warmed_models:
        return True
    try:
        _post("/api/chat", {
            "model": model, "messages": [{"role": "user", "content": "hi"}],
            "stream": False, "options": {"num_predict": 1},
        }, timeout=timeout)
        _warmed_models.add(model)
        return True
    except OllamaError:
        return False


def _resolve_model(requested):
    """Auto-falls back to whatever's actually pulled if the configured
    default isn't installed, instead of just failing -- matches the old
    monolith's behavior, which is why chats there didn't silently break
    just because config.OLLAMA_MODEL didn't match what was pulled."""
    available = list_models()
    if not available:
        return requested  # let the real request fail with a clear error
    if requested in available:
        return requested
    for name in available:  # tolerate "llama3" matching "llama3:latest"
        if name.split(":")[0] == requested.split(":")[0]:
            return name
    return available[0]


def chat(messages, model=None, system=None, keep_alive="30m"):
    """messages: list of {"role": "user"/"assistant", "content": str}
    Returns the assistant's reply text, or a clear fallback string.
    keep_alive defaults to 30 minutes (Ollama's own default is 5) so a
    normal back-and-forth conversation doesn't keep paying the cold-load
    cost every time you pause to think."""
    requested = model or config.OLLAMA_MODEL
    model = _resolve_model(requested)
    payload_messages = []
    if system:
        payload_messages.append({"role": "system", "content": system})
    payload_messages.extend(messages)

    try:
        result = _post("/api/chat", {
            "model": model,
            "messages": payload_messages,
            "stream": False,
            "keep_alive": keep_alive,
        })
        return result.get("message", {}).get("content", "").strip() or "(empty response from Ollama)"
    except OllamaError as e:
        return f"[Ollama unavailable] {e}"


def chat_stream(messages, model=None, system=None, keep_alive="30m"):
    """Same as chat(), but yields text chunks as they arrive. Streaming
    doesn't make total generation faster, but it fixes the *perceived*
    slowness -- words appear as they're generated instead of a frozen
    wait -- which is very likely part of what 'feels slower now' is
    actually about if the old version streamed and this one didn't."""
    requested = model or config.OLLAMA_MODEL
    model = _resolve_model(requested)
    payload_messages = []
    if system:
        payload_messages.append({"role": "system", "content": system})
    payload_messages.extend(messages)

    url = config.OLLAMA_HOST.rstrip("/") + "/api/chat"
    data = json.dumps({"model": model, "messages": payload_messages, "stream": True,
                       "keep_alive": keep_alive}).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            for raw_line in resp:
                line = raw_line.decode("utf-8", errors="ignore").strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                chunk = obj.get("message", {}).get("content", "")
                if chunk:
                    yield chunk
    except urllib.error.URLError as e:
        yield f"[Ollama unavailable] can't reach {config.OLLAMA_HOST} ({e})"


def summarize(text, instruction="Summarize this in one or two sentences.", model=None):
    """Used as the 'management system' pass -- e.g. summarizing what a
    node's batch of assigned files are about."""
    model = model or config.OLLAMA_MODEL
    try:
        result = _post("/api/generate", {
            "model": model,
            "prompt": f"{instruction}\n\n{text}",
            "stream": False,
        })
        return result.get("response", "").strip() or "(no summary produced)"
    except OllamaError as e:
        return f"[Ollama unavailable] {e}"


# The real speed levers for local Ollama inference, in rough order of impact:
#   1. num_gpu (GPU layer offload) -- if a model doesn't fully fit in VRAM,
#      Ollama splits it CPU/GPU, and the CPU portion is 10-50x slower per
#      layer. Check `ollama ps` while a model is loaded to see the split.
#   2. Model size/quantization -- a 7B Q4 model is dramatically faster than
#      a 13B Q8 model. This is a model *choice*, not something this code can
#      fix -- quantization trades a little accuracy for a lot of speed/memory.
#   3. keep_alive -- Ollama unloads an idle model after 5 minutes by default,
#      so the next message pays the full cold-load cost again. Raise this if
#      you're chatting in bursts.
#   4. num_ctx -- larger context = more memory + slower per-token generation.
#      Don't set it bigger than you actually need.
#   5. num_thread -- CPU thread count for the CPU-side portion; usually best
#      left at physical core count.
# None of these are things Python code can change on the server -- they're
# request-level options sent to Ollama's API. benchmark() below measures the
# *actual* result on your hardware instead of guessing.
def benchmark(model=None, prompt="Write one sentence.", num_predict=100):
    """Round-trip timing using Ollama's own reported token/duration fields
    -- run once as a warm-up (first call always includes model load time),
    then again and keep the second result for a fair tokens/sec number."""
    model = model or config.OLLAMA_MODEL
    payload = {
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
        "options": {"num_predict": num_predict, "temperature": 0.0},
    }
    try:
        start = time.time()
        result = _post("/api/chat", payload, timeout=180)
        elapsed = time.time() - start
        eval_count = result.get("eval_count", 0)
        eval_duration_ns = result.get("eval_duration", 0)
        tokens_per_sec = (eval_count / (eval_duration_ns / 1e9)) if eval_duration_ns else None
        return {
            "model": model, "wall_time_s": round(elapsed, 2),
            "tokens_generated": eval_count,
            "tokens_per_sec": round(tokens_per_sec, 1) if tokens_per_sec else None,
            "load_duration_s": round(result.get("load_duration", 0) / 1e9, 2),
        }
    except OllamaError as e:
        return {"error": str(e)}
