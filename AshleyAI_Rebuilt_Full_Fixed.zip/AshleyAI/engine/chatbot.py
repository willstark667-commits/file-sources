from engine.parser import parse_message
from engine.response import generate_response
from database.database import save_chat_message
from tools.logger import log_info

class ChatBot:
    def __init__(self):
        self.name = "Ashley"
    
    def respond(self, user_message):
        log_info(f"User: {user_message}")
        parse_message(user_message)
        
        response = generate_response(user_message)
        
        save_chat_message("User", user_message)
        save_chat_message(self.name, response)
        
        log_info(f"Ashley: {response}")
        return response