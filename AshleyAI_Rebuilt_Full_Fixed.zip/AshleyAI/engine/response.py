from database.database import search_words
from engine.nlp import nlp
from engine.probability import prob_engine

def generate_response(message):
    """Enhanced response with NLP and probability."""
    msg_lower = message.lower().strip()
    
    # NLP Analysis
    words = message.split()
    pos_info = {w: nlp.detect_pos(w) for w in words}
    tense = nlp.detect_tense(message)
    entities = nlp.detect_entities(message)
    
    if any(g in msg_lower for g in ['hello', 'hi', 'hey']):
        return "Hello! How can I help you today?"
    elif any(q in msg_lower for q in ['how are you', 'how r u']):
        return "I'm doing well, thanks for asking! And you?"
    elif '?' in message:
        next_word = prob_engine.predict_next(words[-1] if words else 'you')
        return f"That's an interesting question about {next_word}. Let me think..."
    elif any(w in msg_lower for w in ['thank', 'thanks']):
        return "You're welcome!"
    else:
        words_db = search_words(msg_lower[:10])
        if words_db:
            return f"I see you mentioned {words_db[0]['word']} ({pos_info.get(words[0], 'unknown')}). {tense.capitalize()} tense detected."
        return "I'm still learning new patterns. Tell me more about your day!"