import re

class NLPProcessor:
    def __init__(self):
        self.pos_tags = {
            'noun': ['person', 'place', 'thing', 'dog', 'cat', 'house', 'car', 'name', 'friend'],
            'verb': ['run', 'jump', 'like', 'is', 'are', 'was', 'will', 'go', 'see'],
            'adj': ['big', 'small', 'blue', 'happy', 'fast', 'good', 'bad'],
            'pronoun': ['i', 'you', 'he', 'she', 'it', 'we', 'they'],
        }
    
    def detect_pos(self, word):
        word = word.lower()
        for tag, examples in self.pos_tags.items():
            if word in examples:
                return tag
        return 'unknown'
    
    def detect_tense(self, sentence):
        sentence_lower = sentence.lower()
        if re.search(r'\b(will|going to|tomorrow|future)\b', sentence_lower):
            return 'future'
        elif re.search(r'\b(was|were|ed|yesterday|past)\b', sentence_lower):
            return 'past'
        return 'present'
    
    def detect_entities(self, text):
        text_lower = text.lower()
        entities = {'colors': [], 'persons': [], 'places': [], 'things': []}
        colors = ['blue', 'red', 'green', 'yellow', 'black', 'white']
        for c in colors:
            if c in text_lower:
                entities['colors'].append(c)
        # Simple person/place detection
        if 'i am' in text_lower or 'my name' in text_lower:
            entities['persons'].append('user')
        return entities

nlp = NLPProcessor()