import math
from collections import Counter

class VectorMemory:
    """
    A lightweight, pure-Python Vector Memory module for semantic search.
    Uses Term Frequency-Inverse Document Frequency (TF-IDF) and Cosine Similarity
    to find the most relevant training data or memory snippets.
    """
    def __init__(self):
        self.documents = []  # List of strings (memories/training data)
        self.vocab = set()
        self.document_vectors = []

    def add_document(self, text):
        self.documents.append(text)
        words = self._tokenize(text)
        self.vocab.update(words)
        self._recalculate_vectors()

    def _tokenize(self, text):
        # Simple tokenizer: lowercase and alphanumeric only
        import re
        return re.findall(r'\w+', text.lower())

    def _compute_tf(self, words):
        tf = Counter(words)
        total_words = len(words)
        return {word: count / total_words for word, count in tf.items()}

    def _compute_idf(self):
        idf = {}
        total_docs = len(self.documents)
        for word in self.vocab:
            containing_docs = sum(1 for doc in self.documents if word in self._tokenize(doc))
            idf[word] = math.log((total_docs + 1) / (containing_docs + 1)) + 1
        return idf

    def _recalculate_vectors(self):
        if not self.documents:
            return
        idf = self._compute_idf()
        self.document_vectors = []
        for doc in self.documents:
            words = self._tokenize(doc)
            tf = self._compute_tf(words)
            vector = {word: tf.get(word, 0) * idf.get(word, 0) for word in self.vocab}
            self.document_vectors.append(vector)

    def _cosine_similarity(self, vec1, vec2):
        intersection = set(vec1.keys()) & set(vec2.keys())
        numerator = sum([vec1[x] * vec2[x] for x in intersection])
        
        sum1 = sum([vec1[x]**2 for x in vec1.keys()])
        sum2 = sum([vec2[x]**2 for x in vec2.keys()])
        denominator = math.sqrt(sum1) * math.sqrt(sum2)
        
        if not denominator:
            return 0.0
        return float(numerator) / denominator

    def search(self, query, top_k=3):
        if not self.documents:
            return []
            
        query_words = self._tokenize(query)
        idf = self._compute_idf()
        tf = self._compute_tf(query_words)
        query_vector = {word: tf.get(word, 0) * idf.get(word, 0) for word in self.vocab}
        
        scores = []
        for idx, doc_vector in enumerate(self.document_vectors):
            score = self._cosine_similarity(query_vector, doc_vector)
            scores.append((score, self.documents[idx]))
            
        # Sort by highest score
        scores.sort(key=lambda x: x[0], reverse=True)
        return scores[:top_k]