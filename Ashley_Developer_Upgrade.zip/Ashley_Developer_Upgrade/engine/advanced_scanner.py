import os
import time
import json

class AdvancedScanner:
    """
    Scans the imports folder for training data.
    Features: ETA calculation, progress bar, and checkpoint saving.
    """
    def __init__(self, imports_dir, checkpoint_file="training_checkpoint.json"):
        self.imports_dir = imports_dir
        self.checkpoint_file = checkpoint_file
        self.processed_files = self._load_checkpoint()

    def _load_checkpoint(self):
        if os.path.exists(self.checkpoint_file):
            with open(self.checkpoint_file, 'r') as f:
                return json.load(f)
        return []

    def _save_checkpoint(self):
        with open(self.checkpoint_file, 'w') as f:
            json.dump(self.processed_files, f)

    def scan_and_train(self):
        files_to_process = []
        for root, _, files in os.walk(self.imports_dir):
            for file in files:
                file_path = os.path.join(root, file)
                if file_path not in self.processed_files:
                    files_to_process.append(file_path)

        total_files = len(files_to_process)
        if total_files == 0:
            print("No new files to train on.")
            return

        print(f"Found {total_files} new files for training.")
        start_time = time.time()

        for i, file_path in enumerate(files_to_process):
            self._process_file(file_path)
            self.processed_files.append(file_path)
            
            # Calculate progress and ETA
            progress = (i + 1) / total_files
            elapsed_time = time.time() - start_time
            eta = (elapsed_time / progress) - elapsed_time
            
            self._draw_progress_bar(progress, eta)
            
            # Save checkpoint every 10 files
            if (i + 1) % 10 == 0:
                self._save_checkpoint()

        self._save_checkpoint()
        print("\nTraining complete!")

    def _process_file(self, file_path):
        # Simulate file processing (reading, tokenizing, saving to DB)
        time.sleep(0.5) # Simulated delay

    def _draw_progress_bar(self, progress, eta):
        bar_length = 40
        filled_length = int(bar_length * progress)
        bar = '=' * filled_length + '-' * (bar_length - filled_length)
        percent = progress * 100
        print(f'\r[{bar}] {percent:.1f}% | ETA: {eta:.1f}s', end='', flush=True)