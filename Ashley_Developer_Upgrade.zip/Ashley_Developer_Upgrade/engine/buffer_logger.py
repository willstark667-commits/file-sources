import os
import datetime

class QueryLogger:
    """
    Logs user queries, system responses, and maintains a short-term buffer.
    Useful for generating reports and analyzing AI performance.
    """
    def __init__(self, log_dir="logs"):
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.buffer = []
        self.max_buffer_size = 100
        self.current_log_file = os.path.join(self.log_dir, f"session_{datetime.date.today().strftime('%Y%m%d')}.log")

    def log_interaction(self, user_query, ai_response, route_used="general"):
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_entry = {
            "timestamp": timestamp,
            "route": route_used,
            "query": user_query,
            "response": ai_response
        }
        
        # Add to buffer
        self.buffer.append(log_entry)
        if len(self.buffer) > self.max_buffer_size:
            self.buffer.pop(0)
            
        # Write to file
        with open(self.current_log_file, 'a') as f:
            f.write(f"[{timestamp}] [{route_used.upper()}]\n")
            f.write(f"User: {user_query}\n")
            f.write(f"Ashley: {ai_response}\n")
            f.write("-" * 40 + "\n")

    def generate_report(self):
        report_path = os.path.join(self.log_dir, f"report_{datetime.date.today().strftime('%Y%m%d')}.txt")
        with open(report_path, 'w') as f:
            f.write("=== Ashley AI Daily Report ===\n")
            f.write(f"Total interactions in buffer: {len(self.buffer)}\n\n")
            
            route_counts = {}
            for entry in self.buffer:
                route = entry['route']
                route_counts[route] = route_counts.get(route, 0) + 1
                
            f.write("Route Usage:\n")
            for route, count in route_counts.items():
                f.write(f"- {route}: {count}\n")
                
        return report_path