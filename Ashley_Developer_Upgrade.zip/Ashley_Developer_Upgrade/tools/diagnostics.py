import ast
import traceback
import sys
import os

class CodeDiagnostic:
    """
    Analyzes Python code for syntax errors, bugs, and provides diagnostic reports.
    Helps Ashley act as a coding assistant.
    """
    def __init__(self):
        pass

    def check_syntax(self, code_string):
        """Parses code into an AST to catch syntax errors before running."""
        try:
            ast.parse(code_string)
            return {
                "status": "success", 
                "message": "No syntax errors detected. Code is structurally valid."
            }
        except SyntaxError as e:
            error_msg = f"Syntax Error on line {e.lineno}, offset {e.offset}:\n"
            error_msg += f"{e.text}\n" if e.text else ""
            error_msg += (" " * (e.offset - 1 if e.offset else 0)) + "^\n"
            error_msg += str(e.msg)
            return {
                "status": "error",
                "message": error_msg
            }

    def analyze_project(self, project_dir):
        """Scans a directory for Python files and checks them all."""
        report = []
        for root, _, files in os.walk(project_dir):
            for file in files:
                if file.endswith(".py"):
                    file_path = os.path.join(root, file)
                    with open(file_path, 'r', encoding='utf-8') as f:
                        code = f.read()
                    result = self.check_syntax(code)
                    if result["status"] == "error":
                        report.append(f"File: {file_path}\n{result['message']}\n")
        
        if not report:
            return "Project Analysis Complete: All Python files passed syntax checks."
        return "Project Analysis Complete: Errors Found\n" + "-"*40 + "\n" + "\n".join(report)