import tkinter as tk
from tkinter import scrolledtext
import sys

class ConsoleRedirector:
    """Redirects standard output (print statements) to a Tkinter Text widget."""
    def __init__(self, text_widget):
        self.text_widget = text_widget

    def write(self, string):
        self.text_widget.configure(state='normal')
        self.text_widget.insert(tk.END, string)
        self.text_widget.see(tk.END)
        self.text_widget.configure(state='disabled')

    def flush(self):
        pass

class DeveloperConsole(tk.Frame):
    """
    A Tkinter widget that acts as an embedded developer terminal.
    Allows Ashley to output logs, training progress, and diagnostic reports directly in the GUI.
    """
    def __init__(self, parent, *args, **kwargs):
        super().__init__(parent, *args, **kwargs)
        
        # Console Output Area
        self.console_output = scrolledtext.ScrolledText(self, wrap=tk.WORD, bg="black", fg="#00FF00", font=("Consolas", 10))
        self.console_output.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        self.console_output.configure(state='disabled')
        
        # Console Input Area
        self.console_input = tk.Entry(self, bg="#1E1E1E", fg="#00FF00", font=("Consolas", 10), insertbackground="white")
        self.console_input.pack(fill=tk.X, padx=5, pady=(0, 5))
        self.console_input.bind("<Return>", self._handle_input)
        
        # Redirect stdout
        sys.stdout = ConsoleRedirector(self.console_output)
        
        print("Ashley AI Developer Console Initialized.")
        print("Type '/help' for developer commands.")

    def _handle_input(self, event):
        command = self.console_input.get()
        self.console_input.delete(0, tk.END)
        
        print(f"> {command}")
        
        if command == "/help":
            print("Available commands: /clear, /status, /train, /diagnostics")
        elif command == "/clear":
            self.console_output.configure(state='normal')
            self.console_output.delete(1.0, tk.END)
            self.console_output.configure(state='disabled')
        elif command == "/status":
            print("System Status: Online | VENV: Active | Router: Ready")
        else:
            print(f"Unknown command: {command}")