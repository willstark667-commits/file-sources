import os
import sys
import subprocess
import venv

def is_venv():
    return hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)

def create_and_activate_venv():
    venv_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "venv")
    
    if not os.path.exists(venv_dir):
        print("Creating virtual environment...")
        venv.create(venv_dir, with_pip=True)
    
    # Determine the path to the python executable inside the venv
    if os.name == 'nt':
        python_executable = os.path.join(venv_dir, "Scripts", "python.exe")
    else:
        python_executable = os.path.join(venv_dir, "bin", "python")
        
    return python_executable

def install_requirements(python_executable):
    req_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "requirements.txt")
    if os.path.exists(req_file):
        print("Installing dependencies...")
        subprocess.check_call([python_executable, "-m", "pip", "install", "-r", req_file])
    else:
        print("No requirements.txt found. Skipping dependency installation.")

if __name__ == "__main__":
    print("--- Ashley AI Auto-Setup ---")
    if not is_venv():
        print("Not running in a virtual environment. Setting one up...")
        venv_python = create_and_activate_venv()
        install_requirements(venv_python)
        print(f"\nSetup complete! Please run Ashley using the virtual environment Python:\n{venv_python} Ashley.py")
    else:
        print("Already running inside a virtual environment.")
        install_requirements(sys.executable)
        print("Dependencies are up to date.")