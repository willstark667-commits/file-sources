"""
generate.py - image and video generation tools built entirely from local,
deterministic code (no external model weights or network calls).

Included:
  - generate_gradient / generate_noise: basic procedural image generation
  - generate_diffusion_demo: a toy, purely illustrative visualization of the
    idea behind diffusion models (start from noise, iteratively move toward
    structure). It is NOT a trained generative model.
  - augment_duplicate: standard data-augmentation (flip/rotate/jitter/noise)
    to expand a training dataset from one source image
  - images_to_video: assembles a sequence of images into an .mp4

For real photorealistic text-to-image/video generation, plug in an external
model (see ARCHITECTURE.md for integration points) — that is out of scope
for this lightweight, dependency-free module.
"""

import os
import cv2
import numpy as np
from PIL import Image


def generate_gradient(width, height, c1=(20, 20, 40), c2=(255, 140, 0)):
    arr = np.zeros((height, width, 3), dtype=np.uint8)
    ramp = np.linspace(0, 1, height).reshape(-1, 1)
    for i in range(3):
        arr[:, :, i] = (c1[i] + (c2[i] - c1[i]) * ramp).astype(np.uint8)
    return Image.fromarray(arr, "RGB")


def generate_noise(width, height, smooth=0.0, seed=None):
    rng = np.random.default_rng(seed)
    arr = rng.integers(0, 256, (height, width, 3), dtype=np.uint8)
    if smooth > 0:
        arr = cv2.GaussianBlur(arr, (0, 0), smooth)
    return Image.fromarray(arr, "RGB")


def generate_diffusion_demo(width, height, steps=8, seed=None):
    """
    Illustrative only: renders `steps` frames moving from pure random noise
    toward a smooth gradient "target", getting progressively less noisy and
    less blurred each step - a visual metaphor for the noise -> structure
    direction real diffusion models learn to reverse. Useful as a teaching
    aid or as raw frames for images_to_video(), not as an actual generator.
    """
    rng = np.random.default_rng(seed)
    target = np.array(generate_gradient(width, height)).astype(np.float32)
    noise = rng.integers(0, 256, (height, width, 3)).astype(np.float32)

    frames = []
    for step in range(steps):
        t = step / (steps - 1) if steps > 1 else 1.0
        blended = noise * (1 - t) + target * t
        frame = np.clip(blended, 0, 255).astype(np.uint8)
        remaining_noise = max(0.0, (1 - t)) * 6
        if remaining_noise > 0.3:
            frame = cv2.GaussianBlur(frame, (0, 0), remaining_noise)
        frames.append(Image.fromarray(frame, "RGB"))
    return frames


def augment_duplicate(path, out_dir, n=5, prefix="aug", seed=None):
    """
    Creates n visually-similar-but-varied copies of one source image using
    standard augmentation: horizontal flip, small rotation, brightness /
    contrast jitter, and light gaussian noise. This is the technique used
    to expand a small training set — it is not identity mimicry of a real
    person, just pixel-level transforms of the same file.
    """
    os.makedirs(out_dir, exist_ok=True)
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"could not read image: {path}")
    h, w = img.shape[:2]
    rng = np.random.default_rng(seed)
    outputs = []

    for i in range(n):
        out = img.copy()
        if rng.random() > 0.5:
            out = cv2.flip(out, 1)
        angle = rng.uniform(-12, 12)
        matrix = cv2.getRotationMatrix2D((w / 2, h / 2), angle, 1.0)
        out = cv2.warpAffine(out, matrix, (w, h), borderMode=cv2.BORDER_REFLECT)
        alpha = rng.uniform(0.85, 1.15)   # contrast
        beta = rng.uniform(-15, 15)       # brightness
        out = cv2.convertScaleAbs(out, alpha=alpha, beta=beta)
        if rng.random() > 0.5:
            noise = rng.normal(0, 6, out.shape)
            out = np.clip(out.astype(np.int16) + noise, 0, 255).astype(np.uint8)

        out_path = os.path.join(out_dir, f"{prefix}_{i}_{os.path.basename(path)}")
        cv2.imwrite(out_path, out)
        outputs.append(out_path)

    return outputs


def images_to_video(image_paths, out_path, fps=12):
    if not image_paths:
        raise ValueError("no images provided")
    first = cv2.imread(image_paths[0])
    if first is None:
        raise ValueError(f"could not read first frame: {image_paths[0]}")
    h, w = first.shape[:2]
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    writer = cv2.VideoWriter(out_path, fourcc, fps, (w, h))
    for p in image_paths:
        frame = cv2.imread(p)
        if frame is None:
            continue
        if frame.shape[:2] != (h, w):
            frame = cv2.resize(frame, (w, h))
        writer.write(frame)
    writer.release()
    return out_path
