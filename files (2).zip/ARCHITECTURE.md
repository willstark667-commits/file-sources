# Image / Video Studio — Architecture & Mind Map

## What's actually implemented here (local, no external model weights, no network calls)

```
                              +--------------------+
                              |  dashboard.html    |
                              |  (upload / grid /  |
                              |   detail / tools)  |
                              +---------+----------+
                                        |
                                        v
+----------+   upload    +-------------------------+   store   +-------------+
|  library |  <--------  |          app.py          | --------> | workspace.db|
| (files)  |             |  (Flask relay layer)     |           |  (SQLite)   |
+----------+             +----+------------+---------+           +-------------+
                               |            |
                    analyze / detect     generate / augment
                               |            |
                        +------v-----+  +---v---------+
                        | analysis.py |  | generate.py |
                        +------------+  +-------------+
```

## Pipeline (the "array / relay / cycles / loops" you asked about)

Every image that enters the system — uploaded, generated, or augmented —
goes through the same loop in `app.py::_analyze_and_store`:

```
for each incoming image:
    1. save to disk (library/ or generated/)          <- array of files on disk
    2. analysis.analyze_image()   -> stats + quality score
    3. analysis.detect_features() -> array of detection boxes
    4. db.insert_image() / db.insert_detections()      <- relay result into the dataset
    5. dashboard grid re-fetches /library               <- cycle repeats on every refresh
```

Batch operations (augmenting one image into N duplicates, building a video
from a list of ids) are the same loop run N times, relaying each output back
through the same analyze → store cycle so every generated/augmented file is
just as searchable and taggable as an uploaded one.

## Detection & recognition (implemented)

- **Method:** OpenCV Haar cascade classifiers — a sliding-window pattern
  detector, not a neural network. Fast, CPU-only, no model download beyond
  what ships with `opencv-python`.
- **What it finds:** face, eye, mouth (via the smile cascade) regions as
  bounding boxes. Ear detection is wired up but only activates if
  `opencv-contrib-python`'s extra cascade data is present — it's a
  *detector* (finds a box), not a *recognizer* (does not identify who
  someone is).
- **Overlay:** `analysis.draw_overlay()` draws the boxes plus an x/y pixel
  coordinate grid directly onto the image (the "image graph grid").
- **Knowledge graph:** the dashboard's detail view renders a small
  face → {eye, eye, mouth, ear} node graph on a `<canvas>` from the same
  detection list — a visual summary of what was found, not a persisted
  graph database.

## Quality / artifact scoring (implemented)

- **Sharpness:** Laplacian variance of the grayscale image — a standard,
  cheap focus/blur heuristic. Low variance ≈ blurry / compressed artifacts.
- **Resolution:** raw width × height, normalized against 1080p.
- **Quality score:** `0.4 * resolution_score + 0.6 * sharpness_score`, a
  transparent formula (see `analysis.quality_score`) — not a learned model,
  easy to retune.
- **Color:** average BGR converted to a hex dominant color, plus an 8×8×8
  color histogram used as a feature **vector** for similarity search.

## Search — vectors, heuristics, probability (implemented)

`app.py::search_similar` takes an image's color-histogram vector and ranks
every other image in the workspace by **cosine similarity** (a 0–1
probability-like score). It's a heuristic nearest-neighbor search, not a
learned embedding model — swap in a CNN feature extractor here if you want
semantic ("looks like the same scene") rather than color-based similarity.

## Generation (implemented, procedural — no trained model)

| Function | What it does |
|---|---|
| `generate_gradient` | linear color gradient, pure array math |
| `generate_noise` | random RGB noise, optional Gaussian smoothing |
| `generate_diffusion_demo` | **illustrative only** — blends from random noise to a gradient target over N steps, getting less noisy each frame. Visualizes the *direction* diffusion models learn to reverse (noise → structure); it is not a trained diffusion model and won't produce photorealistic images. |
| `augment_duplicate` | flip / rotate / brightness-contrast jitter / gaussian noise — standard **data augmentation** for expanding a training set from one source image (this is the safe, standard interpretation of "generate near-identical images for training") |
| `images_to_video` | OpenCV `VideoWriter`, assembles any image sequence into an `.mp4` |

## Generation methods & models (background, for context — not all implemented)

- **CNNs** — the backbone of most image classifiers/feature extractors;
  could replace the color-histogram search above with real semantic search.
- **GANs** (generator + discriminator trained adversarially) — classic
  photorealistic image synthesis, e.g. StyleGAN.
- **VAEs** (variational autoencoders) — learn a compressed latent space you
  can sample from; often used as the compression stage inside modern
  diffusion pipelines (latent diffusion).
- **Diffusion models** (DDPM, latent diffusion, e.g. Stable Diffusion) —
  train a network to reverse a fixed noising process; today's dominant
  method for text-to-image and text-to-video. `generate_diffusion_demo()`
  is a hand-built cartoon of the *noise → image* direction only.
- **Style transfer** — CNN-based re-rendering of one image in another's
  style.
- **Classical CV** (this project's actual detection stack) — Haar
  cascades, SIFT/ORB descriptors, color histograms: fast, interpretable,
  no training data or GPU required.

## Plugging in a real trained model (integration point, not included)

The studio doesn't bundle any pretrained generative model — that's a large,
separately-licensed dependency (multi-GB weights, usually a GPU). To add
one:

1. Add `diffusers` + `torch` (+ `transformers` for text prompts) to
   `requirements.txt`.
2. Add a route like `POST /generate/prompt` in `app.py` that loads a
   pipeline (`StableDiffusionPipeline.from_pretrained(...)`) once at
   startup and calls it with the user's **prompt/token string**, saving the
   result into `generated/` and running it through the *same*
   `_analyze_and_store` loop everything else uses.
3. Everything downstream (database, dashboard grid, detection overlay,
   search, video assembly) already works with anything that lands in
   `generated/` — no other changes needed.

## Organizing / categorizing / sorting (implemented)

- **Sort:** by newest, quality score, sharpness, size, or filename
  (`/library?sort=...`).
- **Categorize:** free-text comma-separated tags per image, filterable
  (`/library?tag=...`).
- **Dataset/workspace:** `workspace.db` (SQLite) is the single source of
  truth — every image's stats, detections, and tags live there, independent
  of the dashboard.

## Settings & options

Currently exposed in the UI: output width/height for generation, diffusion
demo step count, augmentation count, video fps, sort order, tag filter.
Everything else (cascade parameters, quality-score weights, grid spacing)
is a constant at the top of `analysis.py` / `generate.py` — deliberately
simple config, not a settings database, so it's easy to read and change.

## Requirements

See `requirements.txt`. Core: `flask`, `pillow`, `numpy`, `opencv-python`,
`pywebview`. Optional extensions are listed but not installed by default.

## Build plan / roadmap

- [x] Phase 1 — library, upload, detection, quality scoring, overlay grid,
      knowledge graph, tagging, sorting, similarity search, procedural
      generation, augmentation, video assembly (this delivery).
- [ ] Phase 2 — swap color-histogram search for a real CNN embedding.
- [ ] Phase 3 — plug in a trained diffusion/GAN backend behind
      `/generate/prompt` for actual text-to-image generation.
- [ ] Phase 4 — sketch/outline tools (freehand canvas → image-to-image
      guidance) once a real generative backend exists to condition on it.
