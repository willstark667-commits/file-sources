#!/usr/bin/env python3
"""
launch_studio.py - opens the Image / Video Studio in a native pywebview
window, same pattern as ../shell.py: start a local server in a background
thread, then point a webview window at it.

Usage:
    python launch_studio.py [--port 5057]

Install dependencies first:
    pip install -r requirements.txt
"""

import argparse
import sys
import threading
import time

import app as studio_app


def main():
    parser = argparse.ArgumentParser(description="Launch the Image / Video Studio in a native window.")
    parser.add_argument("--port", type=int, default=5057)
    parser.add_argument("--width", type=int, default=1320)
    parser.add_argument("--height", type=int, default=860)
    parser.add_argument("--no-window", action="store_true",
                         help="Just run the server (open http://127.0.0.1:PORT manually in a browser)")
    args = parser.parse_args()

    t = threading.Thread(target=studio_app.run, kwargs={"port": args.port}, daemon=True)
    t.start()
    time.sleep(0.8)

    url = f"http://127.0.0.1:{args.port}/"
    if args.no_window:
        print(f"Studio running at {url} (Ctrl+C to stop)")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            return

    try:
        import webview
    except ImportError:
        sys.exit("pywebview is not installed.\nInstall it with:\n    pip install pywebview")

    webview.create_window("Image / Video Studio", url, width=args.width, height=args.height, min_size=(700, 500))
    webview.start()


if __name__ == "__main__":
    main()
