"""
db.py - the "workspace" / dataset layer.

A tiny SQLite database that tracks every image the studio knows about
(library uploads, generated images, augmented duplicates) plus every
detection found in each one (face / eye / mouth / ear boxes).
"""

import os
import sqlite3
import time

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "workspace.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS images (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    path TEXT NOT NULL,
    width INTEGER,
    height INTEGER,
    size_bytes INTEGER,
    format TEXT,
    quality_score REAL,
    sharpness REAL,
    dominant_color TEXT,
    tags TEXT DEFAULT '',
    source TEXT DEFAULT 'upload',
    created_at REAL
);
CREATE TABLE IF NOT EXISTS detections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    image_id INTEGER,
    kind TEXT,
    x INTEGER, y INTEGER, w INTEGER, h INTEGER,
    confidence REAL,
    FOREIGN KEY(image_id) REFERENCES images(id)
);
"""


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def insert_image(meta):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO images
           (filename, path, width, height, size_bytes, format, quality_score,
            sharpness, dominant_color, tags, source, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            meta["filename"], meta["path"], meta["width"], meta["height"],
            meta["size_bytes"], meta["format"], meta["quality_score"],
            meta["sharpness"], meta["dominant_color"], meta.get("tags", ""),
            meta.get("source", "upload"), time.time(),
        ),
    )
    conn.commit()
    image_id = cur.lastrowid
    conn.close()
    return image_id


def insert_detections(image_id, detections):
    if not detections:
        return
    conn = get_conn()
    conn.executemany(
        "INSERT INTO detections (image_id, kind, x, y, w, h, confidence) VALUES (?,?,?,?,?,?,?)",
        [(image_id, d["kind"], d["x"], d["y"], d["w"], d["h"], d.get("confidence", 1.0)) for d in detections],
    )
    conn.commit()
    conn.close()


def list_images(sort_by="created_at", order="desc", tag_filter=None):
    allowed = {"created_at", "quality_score", "width", "height", "size_bytes", "filename", "sharpness"}
    if sort_by not in allowed:
        sort_by = "created_at"
    order = "DESC" if str(order).lower() == "desc" else "ASC"
    conn = get_conn()
    if tag_filter:
        rows = conn.execute(
            f"SELECT * FROM images WHERE tags LIKE ? ORDER BY {sort_by} {order}",
            (f"%{tag_filter}%",),
        ).fetchall()
    else:
        rows = conn.execute(f"SELECT * FROM images ORDER BY {sort_by} {order}").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_image(image_id):
    conn = get_conn()
    row = conn.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_detections(image_id):
    conn = get_conn()
    rows = conn.execute("SELECT * FROM detections WHERE image_id=?", (image_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_tags(image_id, tags):
    conn = get_conn()
    conn.execute("UPDATE images SET tags=? WHERE id=?", (tags, image_id))
    conn.commit()
    conn.close()


def delete_image(image_id):
    conn = get_conn()
    conn.execute("DELETE FROM detections WHERE image_id=?", (image_id,))
    conn.execute("DELETE FROM images WHERE id=?", (image_id,))
    conn.commit()
    conn.close()


def stats_summary():
    conn = get_conn()
    row = conn.execute(
        "SELECT COUNT(*) AS n, AVG(quality_score) AS avg_q, SUM(size_bytes) AS total_bytes FROM images"
    ).fetchone()
    conn.close()
    return dict(row)
