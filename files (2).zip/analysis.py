"""
analysis.py - image detection, recognition, and quality scoring.

Everything here is generic feature DETECTION (finding where a face, eye,
mouth, or ear shaped region is in the frame via OpenCV Haar cascades) --
not identity recognition of any specific person. Detections are boxes,
not names.
"""

import os
import cv2
import numpy as np
from PIL import Image

CASCADE_DIR = cv2.data.haarcascades
FACE_CASCADE = cv2.CascadeClassifier(CASCADE_DIR + "haarcascade_frontalface_default.xml")
EYE_CASCADE = cv2.CascadeClassifier(CASCADE_DIR + "haarcascade_eye.xml")
SMILE_CASCADE = cv2.CascadeClassifier(CASCADE_DIR + "haarcascade_smile.xml")

# Ear cascades ship in opencv_contrib's extra data, not the core package,
# so they may not be present. Detection degrades gracefully if missing.
_EAR_PATH = CASCADE_DIR + "haarcascade_mcs_leftear.xml"
if os.path.exists(_EAR_PATH):
    EAR_CASCADE = cv2.CascadeClassifier(_EAR_PATH)
    HAS_EAR = not EAR_CASCADE.empty()
else:
    EAR_CASCADE = None
    HAS_EAR = False


def basic_stats(path):
    img = Image.open(path)
    return {
        "width": img.width,
        "height": img.height,
        "format": img.format or os.path.splitext(path)[1].lstrip(".").upper(),
        "size_bytes": os.path.getsize(path),
        "mode": img.mode,
    }


def sharpness_score(gray):
    """Laplacian variance - a standard cheap blur/focus heuristic. Higher = sharper."""
    return float(cv2.Laplacian(gray, cv2.CV_64F).var())


def dominant_color(bgr_img):
    small = cv2.resize(bgr_img, (32, 32))
    avg = small.reshape(-1, 3).mean(axis=0)  # BGR
    return "#{:02x}{:02x}{:02x}".format(int(avg[2]), int(avg[1]), int(avg[0]))


def quality_score(width, height, sharpness):
    """0-100 heuristic blending resolution and sharpness. Not a learned metric —
    a transparent weighted formula, easy to retune in one place."""
    res_score = min(100.0, (width * height) / (1920 * 1080) * 100.0)
    sharp_score = min(100.0, sharpness / 5.0)
    return round(res_score * 0.4 + sharp_score * 0.6, 1)


def analyze_image(path):
    bgr = cv2.imread(path)
    if bgr is None:
        raise ValueError(f"could not read image: {path}")
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    stats = basic_stats(path)
    sharp = sharpness_score(gray)
    return {
        **stats,
        "sharpness": round(sharp, 2),
        "quality_score": quality_score(stats["width"], stats["height"], sharp),
        "dominant_color": dominant_color(bgr),
    }


def detect_features(path):
    """Returns a flat list of {kind, x, y, w, h, confidence} boxes.
    kind is one of: face, eye, mouth, ear."""
    bgr = cv2.imread(path)
    if bgr is None:
        return []
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    detections = []

    faces = FACE_CASCADE.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40))
    for (x, y, w, h) in faces:
        detections.append({"kind": "face", "x": int(x), "y": int(y), "w": int(w), "h": int(h), "confidence": 1.0})
        roi = gray[y:y + h, x:x + w]

        eyes = EYE_CASCADE.detectMultiScale(roi, scaleFactor=1.1, minNeighbors=8)
        for (ex, ey, ew, eh) in eyes:
            if ey > h * 0.6:  # skip false positives low in the face (mouth area)
                continue
            detections.append({"kind": "eye", "x": int(x + ex), "y": int(y + ey), "w": int(ew), "h": int(eh),
                                "confidence": 0.9})

        lower = roi[int(h * 0.5):, :]
        smiles = SMILE_CASCADE.detectMultiScale(lower, scaleFactor=1.7, minNeighbors=20)
        for (sx, sy, sw, sh) in smiles:
            detections.append({"kind": "mouth", "x": int(x + sx), "y": int(y + h * 0.5 + sy), "w": int(sw),
                                "h": int(sh), "confidence": 0.7})

    if HAS_EAR:
        ears = EAR_CASCADE.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5)
        for (ux, uy, uw, uh) in ears:
            detections.append({"kind": "ear", "x": int(ux), "y": int(uy), "w": int(uw), "h": int(uh),
                                "confidence": 0.5})

    return detections


_COLORS = {"face": (0, 255, 255), "eye": (0, 255, 0), "mouth": (0, 140, 255), "ear": (255, 0, 255)}


def draw_overlay(path, detections, out_path, grid_step=50):
    """Draws detection boxes + an x/y coordinate grid over the image — the
    'image graph grid' overlay used by the dashboard's detail view."""
    img = cv2.imread(path)
    if img is None:
        raise ValueError(f"could not read image: {path}")
    h, w = img.shape[:2]

    for gx in range(0, w, grid_step):
        cv2.line(img, (gx, 0), (gx, h), (55, 55, 55), 1)
        cv2.putText(img, str(gx), (gx + 2, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (140, 140, 140), 1)
    for gy in range(0, h, grid_step):
        cv2.line(img, (0, gy), (w, gy), (55, 55, 55), 1)
        cv2.putText(img, str(gy), (2, gy + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.32, (140, 140, 140), 1)

    for d in detections:
        c = _COLORS.get(d["kind"], (255, 255, 255))
        cv2.rectangle(img, (d["x"], d["y"]), (d["x"] + d["w"], d["y"] + d["h"]), c, 2)
        cv2.putText(img, d["kind"], (d["x"], max(10, d["y"] - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.45, c, 1)

    cv2.imwrite(out_path, img)
    return out_path


def color_histogram_vector(path, bins=8):
    """A cheap feature vector for similarity search (used by /search in app.py)."""
    img = cv2.imread(path)
    hist = cv2.calcHist([img], [0, 1, 2], None, [bins, bins, bins], [0, 256] * 3)
    return cv2.normalize(hist, hist).flatten()
