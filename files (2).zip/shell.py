#!/usr/bin/env python3
"""
shell.py - Universal pywebview shell.

Point it at almost anything and it will figure out how to show it in a
native window:

  * a folder of html/css/js/json/csv files (a static web app)          -> wraps it in a
    canvas boot-loader page, then iframes it
  * a python program (single .py file or a project folder)             -> detects its
    imports/dependencies/wheels/hooks, runs it, and streams its stdout
    into a live console panel inside the shell
  * a project that already has its own shell (existing shell.py,
    Electron, Tauri, etc.)                                             -> reports what
    it found and, unless told otherwise, launches that shell directly
    instead of re-wrapping it

Usage:
    python shell.py <path> [options]

Examples:
    python shell.py ./my-web-app
    python shell.py ./my-web-app/index.html
    python shell.py my_script.py
    python shell.py ./my-python-project
    python shell.py ./my-python-project --install-missing
    python shell.py ./electron-app --force-convert

Install dependency first:
    pip install pywebview
"""

import argparse
import json
import os
import subprocess
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import detect
import build_shell


# ---------------------------------------------------------------------------
# Local server that runs a python program and exposes its live stdout/stderr
# ---------------------------------------------------------------------------

class ProgramRunner:
    def __init__(self, script_path, cwd):
        self.script_path = script_path
        self.cwd = cwd
        self.output_lines = []
        self.lock = threading.Lock()
        self.proc = None
        self.returncode = None

    def start(self):
        self.proc = subprocess.Popen(
            [sys.executable, "-u", self.script_path],
            cwd=self.cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        for line in self.proc.stdout:
            with self.lock:
                self.output_lines.append(line.rstrip("\n"))
        self.proc.wait()
        with self.lock:
            self.returncode = self.proc.returncode

    def snapshot(self):
        with self.lock:
            return {
                "output": "\n".join(self.output_lines),
                "running": self.returncode is None,
                "pid": self.proc.pid if self.proc else None,
                "returncode": self.returncode,
            }


def make_output_handler(runner):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            if self.path.startswith("/output"):
                body = json.dumps(runner.snapshot()).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404)
                self.end_headers()

    return Handler


def start_output_server(runner):
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_output_handler(runner))
    port = server.server_address[1]
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return port


# ---------------------------------------------------------------------------
# Existing-shell launching
# ---------------------------------------------------------------------------

def launch_existing_shell(detection):
    root = detection["root"]
    hits = {h["file"] for h in detection["existing_shell"]}

    if "shell.py" in hits:
        print(f"Existing pywebview shell found: {os.path.join(root, 'shell.py')}")
        subprocess.run([sys.executable, "shell.py"], cwd=root)
        return True

    if os.path.exists(os.path.join(root, "package.json")):
        print(f"Existing Electron/Tauri project found in {root}. Launching `npm start`...")
        subprocess.run(["npm", "start"], cwd=root)
        return True

    print("Existing shell detected but no known way to launch it automatically.")
    return False


# ---------------------------------------------------------------------------
# Missing-dependency handling
# ---------------------------------------------------------------------------

def install_missing(detection, use_wheels=True):
    missing = detection.get("missing_dependencies", [])
    if not missing:
        return
    wheels = {os.path.splitext(os.path.basename(w))[0].split("-")[0].lower(): w for w in detection.get("wheels", [])}
    for pkg in missing:
        wheel = wheels.get(pkg.lower())
        if use_wheels and wheel:
            target = os.path.join(detection["root"], wheel)
            print(f"Installing {pkg} from local wheel {wheel} ...")
            subprocess.run([sys.executable, "-m", "pip", "install", target])
        else:
            print(f"Installing {pkg} from PyPI ...")
            subprocess.run([sys.executable, "-m", "pip", "install", pkg])


# ---------------------------------------------------------------------------
# Startup menu (used when no target is given on the command line)
# ---------------------------------------------------------------------------

def prompt_menu():
    print("=" * 44)
    print("  pywebview SHELL")
    print("=" * 44)
    print("  1) Load an HTML file / web project")
    print("  2) Load a Python file / program")
    print("  3) Quit")
    print("-" * 44)

    while True:
        choice = input("Select an option [1-3]: ").strip()
        if choice == "3":
            sys.exit(0)
        if choice in ("1", "2"):
            break
        print("Please enter 1, 2, or 3.")

    kind = "html" if choice == "1" else "python"
    prompt_label = "Path to .html file or folder: " if kind == "html" else "Path to .py file or project folder: "

    while True:
        path = input(prompt_label).strip().strip('"').strip("'")
        if path and os.path.exists(path):
            return path
        print(f"Not found: {path!r} — try again.")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Universal pywebview shell for html apps and python programs.")
    parser.add_argument("target", nargs="?", default=None,
                         help="Path to an html file/folder, a python script/project, or an app folder. "
                              "If omitted, a menu will ask you to choose.")
    parser.add_argument("--title", default=None)
    parser.add_argument("--width", type=int, default=1100)
    parser.add_argument("--height", type=int, default=760)
    parser.add_argument("--install-missing", action="store_true",
                         help="pip install any missing python dependencies detected before running")
    parser.add_argument("--force-convert", action="store_true",
                         help="Wrap the target in the canvas HTML shell even if an existing shell was found")
    parser.add_argument("--debug", action="store_true")
    args = parser.parse_args()

    if args.target is None:
        args.target = prompt_menu()

    if not os.path.exists(args.target):
        sys.exit(f"Error: target not found: {args.target}")

    print(f"Scanning {args.target} ...")
    result = detect.scan_target(args.target)
    print(json.dumps({k: v for k, v in result.items() if k != "assets"}, indent=2))

    if result["has_existing_shell"] and not args.force_convert:
        launched = launch_existing_shell(result)
        if launched:
            return
        print("Falling back to generating a new html shell...\n")

    poll_url = None
    if result["type"] == "python_program":
        if args.install_missing:
            install_missing(result)
        entry_path = os.path.join(result["root"], result["entry"])
        runner = ProgramRunner(entry_path, result["root"])
        runner.start()
        port = start_output_server(runner)
        poll_url = f"http://127.0.0.1:{port}/output"
        print(f"Running {result['entry']} — output server on {poll_url}")

    tmp_dir = tempfile.mkdtemp(prefix="pyshell_")
    out_html = os.path.join(tmp_dir, "shell.html")
    build_shell.generate_html(result, out_html, poll_url=poll_url)

    try:
        import webview
    except ImportError:
        sys.exit("pywebview is not installed.\nInstall it with:\n    pip install pywebview")

    title = args.title or os.path.basename(os.path.normpath(args.target))

    webview.create_window(title, f"file://{out_html}", width=args.width, height=args.height, min_size=(400, 300))
    webview.start(debug=args.debug)


if __name__ == "__main__":
    main()
