"""
app.py - the studio's backend/relay layer.

Serves the dashboard, accepts uploads into library/, runs analysis +
detection on every image that enters the system (uploaded, generated, or
augmented), stores results in the workspace database, and exposes the
generation/augmentation/video/search tools as JSON endpoints the dashboard
calls.
"""

import os
import time
import numpy as np
from flask import Flask, request, jsonify, send_from_directory, render_template

import db
import analysis
import generate

BASE = os.path.dirname(os.path.abspath(__file__))
LIBRARY = os.path.join(BASE, "library")
GENERATED = os.path.join(BASE, "generated")
OVERLAYS = os.path.join(BASE, "overlays")
for d in (LIBRARY, GENERATED, OVERLAYS):
    os.makedirs(d, exist_ok=True)

db.init_db()

app = Flask(__name__, template_folder=os.path.join(BASE, "templates"))
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64MB upload cap


def _unique_path(directory, filename):
    base, ext = os.path.splitext(filename)
    path = os.path.join(directory, filename)
    n = 1
    while os.path.exists(path):
        path = os.path.join(directory, f"{base}_{n}{ext}")
        n += 1
    return path


def _analyze_and_store(path, filename, source="upload"):
    stats = analysis.analyze_image(path)
    image_id = db.insert_image({
        "filename": filename, "path": path,
        "width": stats["width"], "height": stats["height"],
        "size_bytes": stats["size_bytes"], "format": stats["format"],
        "quality_score": stats["quality_score"], "sharpness": stats["sharpness"],
        "dominant_color": stats["dominant_color"], "source": source,
    })
    detections = analysis.detect_features(path)
    db.insert_detections(image_id, detections)
    return image_id, stats, detections


# --- pages ------------------------------------------------------------

@app.route("/")
def index():
    return render_template("dashboard.html")


# --- library / upload ---------------------------------------------------

@app.route("/upload", methods=["POST"])
def upload():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify({"error": "no file provided"}), 400
    path = _unique_path(LIBRARY, f.filename)
    f.save(path)
    try:
        image_id, stats, detections = _analyze_and_store(path, os.path.basename(path))
    except ValueError as e:
        os.remove(path)
        return jsonify({"error": str(e)}), 400
    return jsonify({"id": image_id, "stats": stats, "detections": detections})


@app.route("/library")
def library():
    sort_by = request.args.get("sort", "created_at")
    order = request.args.get("order", "desc")
    tag_filter = request.args.get("tag") or None
    return jsonify(db.list_images(sort_by, order, tag_filter))


@app.route("/summary")
def summary():
    return jsonify(db.stats_summary())


@app.route("/image/<int:image_id>")
def get_image_file(image_id):
    meta = db.get_image(image_id)
    if not meta:
        return "not found", 404
    return send_from_directory(os.path.dirname(meta["path"]), os.path.basename(meta["path"]))


@app.route("/overlay/<int:image_id>")
def overlay(image_id):
    meta = db.get_image(image_id)
    if not meta:
        return "not found", 404
    detections = db.get_detections(image_id)
    out_path = os.path.join(OVERLAYS, f"{image_id}.jpg")
    analysis.draw_overlay(meta["path"], detections, out_path)
    return send_from_directory(OVERLAYS, f"{image_id}.jpg")


@app.route("/detections/<int:image_id>")
def detections_route(image_id):
    return jsonify(db.get_detections(image_id))


@app.route("/tag/<int:image_id>", methods=["POST"])
def tag(image_id):
    tags = (request.json or {}).get("tags", "")
    db.update_tags(image_id, tags)
    return jsonify({"ok": True})


@app.route("/delete/<int:image_id>", methods=["POST"])
def delete(image_id):
    db.delete_image(image_id)
    return jsonify({"ok": True})


# --- similarity search (vectors + heuristics) ---------------------------

@app.route("/search/<int:image_id>")
def search_similar(image_id):
    meta = db.get_image(image_id)
    if not meta:
        return jsonify([])
    target_vec = analysis.color_histogram_vector(meta["path"])
    results = []
    for other in db.list_images():
        if other["id"] == image_id:
            continue
        vec = analysis.color_histogram_vector(other["path"])
        denom = (np.linalg.norm(target_vec) * np.linalg.norm(vec)) + 1e-8
        sim = float(np.dot(target_vec, vec) / denom)  # cosine similarity, 0-1 probability-like score
        results.append({"id": other["id"], "filename": other["filename"], "similarity": round(sim, 4)})
    results.sort(key=lambda r: -r["similarity"])
    return jsonify(results[:8])


# --- generation -----------------------------------------------------------

@app.route("/generate/gradient", methods=["POST"])
def gen_gradient():
    body = request.json or {}
    w, h = int(body.get("width", 512)), int(body.get("height", 512))
    img = generate.generate_gradient(w, h)
    filename = f"gradient_{int(time.time()*1000)}.png"
    path = os.path.join(GENERATED, filename)
    img.save(path)
    image_id, stats, _ = _analyze_and_store(path, filename, source="generated:gradient")
    return jsonify({"id": image_id, "stats": stats})


@app.route("/generate/noise", methods=["POST"])
def gen_noise():
    body = request.json or {}
    w, h = int(body.get("width", 512)), int(body.get("height", 512))
    smooth = float(body.get("smooth", 0))
    img = generate.generate_noise(w, h, smooth)
    filename = f"noise_{int(time.time()*1000)}.png"
    path = os.path.join(GENERATED, filename)
    img.save(path)
    image_id, stats, _ = _analyze_and_store(path, filename, source="generated:noise")
    return jsonify({"id": image_id, "stats": stats})


@app.route("/generate/diffusion_demo", methods=["POST"])
def gen_diffusion():
    body = request.json or {}
    w, h = int(body.get("width", 384)), int(body.get("height", 384))
    steps = max(2, min(30, int(body.get("steps", 8))))
    frames = generate.generate_diffusion_demo(w, h, steps)
    stamp = int(time.time() * 1000)
    paths = []
    for i, frame in enumerate(frames):
        filename = f"diffusion_{stamp}_{i}.png"
        path = os.path.join(GENERATED, filename)
        frame.save(path)
        paths.append(path)
        _analyze_and_store(path, filename, source="generated:diffusion_demo")
    video_name = f"diffusion_{stamp}.mp4"
    generate.images_to_video(paths, os.path.join(GENERATED, video_name), fps=4)
    return jsonify({"frames": len(paths), "video": video_name})


@app.route("/augment/<int:image_id>", methods=["POST"])
def augment(image_id):
    meta = db.get_image(image_id)
    if not meta:
        return jsonify({"error": "not found"}), 404
    n = max(1, min(20, int((request.json or {}).get("n", 5))))
    outputs = generate.augment_duplicate(meta["path"], LIBRARY, n=n)
    ids = []
    for p in outputs:
        iid, _, _ = _analyze_and_store(p, os.path.basename(p), source=f"augment:{image_id}")
        ids.append(iid)
    return jsonify({"created": ids})


@app.route("/video/from_library", methods=["POST"])
def video_from_library():
    body = request.json or {}
    ids = body.get("ids", [])
    fps = int(body.get("fps", 12))
    paths = [db.get_image(i)["path"] for i in ids if db.get_image(i)]
    if not paths:
        return jsonify({"error": "no valid image ids"}), 400
    out_name = f"library_video_{int(time.time()*1000)}.mp4"
    generate.images_to_video(paths, os.path.join(GENERATED, out_name), fps=fps)
    return jsonify({"video": out_name})


@app.route("/generated/<path:filename>")
def generated_file(filename):
    return send_from_directory(GENERATED, filename)


def run(port=5057, debug=False):
    app.run(host="127.0.0.1", port=port, debug=debug, use_reloader=False)


if __name__ == "__main__":
    run(debug=True)
