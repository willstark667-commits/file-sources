# NanoBrain — miniature internal neural network prototype

A small, honest, actually-running prototype of the "internal neural
network agent" concept: a handful of neuron-nodes, each with its own
tiny storage folder and vectors, wired into a chain, trained in two
phases (node-local, then joint), driven from a CRT-style Tkinter shell.

## What this is
- A **few nodes** (3–8), each with its own ID, a handful of vectors,
  and its own folder of small files under `data/node_XXX/`.
- A **non-destructive file scanner** (`scan`) that indexes a directory
  (metadata + short preview only — it never edits or moves anything).
- A tiny **toy learning task** (next-bit prediction) so training and
  loss are real and observable, not simulated.
- A **two-phase training loop**: `pretrain` (each node trains alone)
  then `train` (the whole chain trains jointly) — matching the
  original design's node-local-then-global idea.
- Node count that can scale with scanned file count
  (`Network.sized_for_file_count`).

## What this deliberately is not (yet)
- Not a language model — it doesn't understand text, it predicts a
  toy bit sequence. Wiring in Ollama for real language/reasoning is a
  next step, not done here.
- Not scanning your whole PC — `scan` only looks at `workspace/` by
  default (or a path you give it), and only reads metadata.
- Not doing real RAG yet — the scanner/index is the foundation a RAG
  layer would sit on top of.

## Running it
```bash
python3 launcher.py
```
Standard library only — nothing to `pip install` for this prototype
(see `requirements.txt` for what gets added as it grows).

## Shell commands
```
status              network status / maturity %
nodes               list nodes: confidence, vectors, file counts
scan [path]          scan a directory (default: ./workspace), read-only
search <keyword>     search the last scan's index
pretrain             phase 1: each node trains independently
train                phase 2: joint training across the chain
predict <0|1>        feed a bit through the trained chain
grow                 add one more node (up to 8)
save / load          checkpoint to/from data/network_checkpoint.json
clear / exit
```

## Layout
```
NanoBrain/
├── launcher.py
├── requirements.txt
├── nanobrain/
│   ├── config.py     # all paths anchored to __file__, not cwd
│   ├── neuron.py      # the node: vectors, weight/bias, own file folder
│   ├── network.py      # wiring + two-phase training + status/maturity
│   ├── scanner.py       # non-destructive file indexer
│   └── gui.py            # Tkinter CRT shell
├── data/            (created at runtime: per-node folders + checkpoint)
├── workspace/        (created at runtime: default scan target)
└── logs/
```
