#!/usr/bin/env python3
"""
NanoBrain launcher.

Run with:
    python3 launcher.py

This project uses only the Python standard library (tkinter included),
so there is nothing to auto-install for the base prototype -- this
launcher checks that anyway and prints a clear message if tkinter is
missing (some minimal Linux Python installs omit it), rather than
crashing with a confusing traceback.
"""

import sys
import os
import subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_tkinter():
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        return False


def try_install_tkinter():
    """tkinter can't be pip-installed -- it's a system package. Tell the
    user the real fix instead of pretending pip can solve it."""
    print("tkinter is not available in this Python installation.")
    print("It ships with Python but some minimal Linux installs split it out.")
    print("Install it with your system package manager, e.g.:")
    print("  Debian/Ubuntu:  sudo apt-get install python3-tk")
    print("  Fedora:         sudo dnf install python3-tkinter")
    print("  macOS/Windows python.org installers include it already.")


def main():
    if not check_tkinter():
        try_install_tkinter()
        sys.exit(1)

    from nanobrain import config
    config.ensure_dirs()

    from nanobrain.gui import run
    run()


if __name__ == "__main__":
    main()
