"""
A Neuron here is deliberately more than a plain weight-and-bias unit --
per the original design, each node acts like a small independent unit:
it has its own ID, its own small set of vectors, its own weights/bias,
and its own folder on disk where it keeps a handful of files. Nodes can
be asked to look through their own folder independently before the
whole network is trained jointly.

This is a genuinely tiny prototype: a handful of nodes, a handful of
vectors and files each -- not a claim that this scales to "all the
data on your PC." That scaling idea is real (spawn more nodes for more
data) but here it's implemented as one honest, small, working example.
"""

import os
import json
import random

from . import config


def _rand_vector(size=4):
    return [round(random.uniform(-1, 1), 4) for _ in range(size)]


class Neuron:
    """One neural node: a mini self-contained unit."""

    def __init__(self, node_id, num_vectors=None, storage_root=None):
        self.id = node_id
        self.num_vectors = num_vectors or random.randint(*config.VECTORS_PER_NODE)
        self.vectors = [_rand_vector() for _ in range(self.num_vectors)]
        self.weight = random.uniform(-0.5, 0.5)
        self.bias = random.uniform(-0.1, 0.1)
        self.confidence = 0.5  # adjusted by self-evaluation over time
        self.activation_log = []  # recent activations, for the GUI monitor

        self.folder = os.path.join(storage_root or config.DATA_DIR, f"node_{self.id:03d}")
        os.makedirs(self.folder, exist_ok=True)
        self._ensure_own_files()

    # -- each node organizes a small independent storage of its own ---------
    def _ensure_own_files(self):
        """Give the node its own small set of files to track, per the
        'each node has 5 to 50 files for organization' idea -- scaled
        down to a sane handful for this prototype."""
        n_files = random.randint(*config.FILES_PER_NODE_STORAGE)
        existing = [f for f in os.listdir(self.folder) if f.startswith("note_")]
        for i in range(len(existing), n_files):
            path = os.path.join(self.folder, f"note_{i:02d}.json")
            if not os.path.exists(path):
                with open(path, "w") as fh:
                    json.dump({"node_id": self.id, "slot": i, "tag": None}, fh)

    def list_own_files(self):
        return sorted(os.listdir(self.folder))

    # -- core compute ---------------------------------------------------
    def activate(self, x: float) -> float:
        """Simple weighted activation with a tanh squash."""
        z = self.weight * x + self.bias
        out = _tanh(z)
        self.activation_log.append(round(out, 4))
        if len(self.activation_log) > 20:
            self.activation_log.pop(0)
        return out

    def nudge(self, error: float, lr: float):
        """One manual gradient-descent-style update step (no autograd
        framework -- this is a from-scratch toy update rule)."""
        self.weight -= lr * error
        self.bias -= lr * error * 0.5
        # confidence tracks recent performance as a moving average,
        # so it can rise again as the node improves rather than only decaying
        target_conf = max(0.0, min(1.0, 1.0 - abs(error)))
        self.confidence = 0.9 * self.confidence + 0.1 * target_conf

    # -- persistence ------------------------------------------------------
    def to_dict(self):
        return {
            "id": self.id,
            "weight": self.weight,
            "bias": self.bias,
            "confidence": self.confidence,
            "num_vectors": self.num_vectors,
            "vectors": self.vectors,
        }

    @classmethod
    def from_dict(cls, d, storage_root=None):
        n = cls(d["id"], num_vectors=d["num_vectors"], storage_root=storage_root)
        n.weight = d["weight"]
        n.bias = d["bias"]
        n.confidence = d["confidence"]
        n.vectors = d["vectors"]
        return n


def _tanh(z):
    # pure-python tanh, no numpy required
    import math
    return math.tanh(z)
