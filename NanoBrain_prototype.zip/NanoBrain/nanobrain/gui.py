"""
Simple Tk shell: dark background, amber/green monospace text, a single
terminal-style window. Talks to the Network and scanner modules
directly -- no web server, no extra processes.
"""

import tkinter as tk
from tkinter import scrolledtext
import threading

from . import config
from .network import Network
from . import scanner

BG = "#0a0f0a"
FG = "#33ff66"       # phosphor green
ACCENT = "#ffb000"   # amber
FONT = ("Consolas", 12)


class NanoBrainShell(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NanoBrain :: internal neural network shell")
        self.configure(bg=BG)
        self.geometry("900x600")

        self.net = Network(num_nodes=config.MIN_NODES)

        self.output = scrolledtext.ScrolledText(
            self, bg=BG, fg=FG, insertbackground=FG, font=FONT,
            wrap="word", borderwidth=0, highlightthickness=0
        )
        self.output.pack(fill="both", expand=True, padx=8, pady=(8, 0))
        self.output.tag_configure("accent", foreground=ACCENT)
        self.output.configure(state="disabled")

        entry_frame = tk.Frame(self, bg=BG)
        entry_frame.pack(fill="x", padx=8, pady=8)

        prompt = tk.Label(entry_frame, text=">", bg=BG, fg=ACCENT, font=FONT)
        prompt.pack(side="left")

        self.entry = tk.Entry(entry_frame, bg=BG, fg=FG, insertbackground=FG,
                               font=FONT, borderwidth=0, highlightthickness=1,
                               highlightbackground=FG, highlightcolor=ACCENT)
        self.entry.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.entry.bind("<Return>", self._on_enter)
        self.entry.focus_set()

        self._print_banner()

    # -- output helpers ----------------------------------------------------
    def _print(self, text, tag=None):
        self.output.configure(state="normal")
        self.output.insert("end", text + "\n", tag or ())
        self.output.see("end")
        self.output.configure(state="disabled")

    def _print_banner(self):
        self._print("=" * 60, "accent")
        self._print("  NANOBRAIN -- miniature internal neural network shell")
        self._print("=" * 60, "accent")
        self._print(f"  nodes: {len(self.net.nodes)}  |  data dir: {config.DATA_DIR}")
        self._print("  type 'help' for commands\n")

    # -- command handling ----------------------------------------------------
    def _on_enter(self, event=None):
        cmd = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd:
            return
        self._print(f"> {cmd}", "accent")
        threading.Thread(target=self._dispatch, args=(cmd,), daemon=True).start()

    def _dispatch(self, cmd):
        parts = cmd.split(maxsplit=1)
        name = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""

        handlers = {
            "help": self._cmd_help,
            "status": self._cmd_status,
            "nodes": self._cmd_nodes,
            "scan": self._cmd_scan,
            "search": self._cmd_search,
            "pretrain": self._cmd_pretrain,
            "train": self._cmd_train,
            "predict": self._cmd_predict,
            "grow": self._cmd_grow,
            "save": self._cmd_save,
            "load": self._cmd_load,
            "clear": self._cmd_clear,
            "exit": self._cmd_exit,
            "quit": self._cmd_exit,
        }
        handler = handlers.get(name)
        if handler is None:
            self._print(f"unknown command: {name}  (try 'help')")
            return
        handler(arg)

    def _cmd_help(self, arg):
        self._print(
            "commands:\n"
            "  status              show network status / maturity %\n"
            "  nodes               list nodes, their confidence, and file counts\n"
            "  scan [path]         scan a directory (default: ./workspace) -- read-only\n"
            "  search <keyword>    search the last scan's index by filename/preview\n"
            "  pretrain            phase 1: train each node independently\n"
            "  train               phase 2: joint training across all nodes\n"
            "  predict <0|1>       feed a bit through the trained chain\n"
            "  grow                add one more node (up to max)\n"
            "  save / load         checkpoint the network to/from data/\n"
            "  clear               clear the screen\n"
            "  exit                quit\n"
        )

    def _cmd_status(self, arg):
        s = self.net.status()
        self._print(
            f"generation: {s['generation']}   training_steps: {s['training_steps']}\n"
            f"nodes: {s['nodes']}   avg_confidence: {s['avg_confidence']}\n"
            f"last_loss: {s['last_loss']}   maturity: {s['maturity_pct']}%"
        )

    def _cmd_nodes(self, arg):
        for n in self.net.nodes:
            files = n.list_own_files()
            self._print(
                f"  node {n.id:03d}  weight={n.weight:+.3f}  bias={n.bias:+.3f}  "
                f"confidence={n.confidence:.2f}  vectors={n.num_vectors}  files={len(files)}"
            )

    def _cmd_scan(self, arg):
        path = arg.strip() or None
        self._print("scanning (read-only, no files will be modified)...")
        records = scanner.scan_directory(path)
        self._print(f"indexed {len(records)} files.")
        sized = Network.sized_for_file_count(len(records))
        self._print(f"(for reference: a network sized to this data would use {len(sized.nodes)} nodes)")

    def _cmd_search(self, arg):
        if not arg:
            self._print("usage: search <keyword>")
            return
        hits = scanner.search_keyword(arg)
        if not hits:
            self._print("no matches.")
            return
        for h in hits[:20]:
            self._print(f"  {h['filename']}  ({h['size_bytes']} bytes)  {h['path']}")

    def _cmd_pretrain(self, arg):
        self._print("phase 1: pretraining each node independently...")
        report = self.net.pretrain_nodes_independently()
        for node_id, loss in report.items():
            self._print(f"  node {node_id:03d} local_loss={loss}")
        self._print("pretraining complete.")

    def _cmd_train(self, arg):
        self._print("phase 2: joint training across the chain...")
        avg_loss = self.net.train_joint()
        self._print(f"generation {self.net.generation}  avg_loss={avg_loss:.5f}")

    def _cmd_predict(self, arg):
        try:
            bit = int(arg.strip())
        except ValueError:
            self._print("usage: predict <0|1>")
            return
        out = self.net.predict_next(bit)
        self._print(f"input={bit}  ->  raw_output={out:.4f}  (rounds to {1 if out > 0 else 0})")

    def _cmd_grow(self, arg):
        node = self.net.grow()
        if node is None:
            self._print(f"already at max nodes ({config.MAX_NODES}).")
        else:
            self._print(f"spawned node {node.id:03d} with {node.num_vectors} vectors.")

    def _cmd_save(self, arg):
        path = self.net.save()
        self._print(f"checkpoint saved: {path}")

    def _cmd_load(self, arg):
        try:
            self.net = Network.load()
            self._print("checkpoint loaded.")
        except FileNotFoundError:
            self._print("no checkpoint found yet -- run 'save' first.")

    def _cmd_clear(self, arg):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.configure(state="disabled")

    def _cmd_exit(self, arg):
        self.destroy()


def run():
    config.ensure_dirs()
    app = NanoBrainShell()
    app.mainloop()
