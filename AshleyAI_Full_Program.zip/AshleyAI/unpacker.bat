@echo off
echo ================================================
echo     Ashley AI Unpacker & Launcher
echo ================================================
echo.

:: Check if 7-Zip is installed or use built-in
if exist "%ProgramFiles%\7-Zip\7z.exe" (
    echo Using 7-Zip...
    "%ProgramFiles%\7-Zip\7z.exe" x AshleyAI_Phase1.zip -oPhase1 -y
    "%ProgramFiles%\7-Zip\7z.exe" x AshleyAI_Phase2.zip -oPhase2 -y
    "%ProgramFiles%\7-Zip\7z.exe" x AshleyAI_Phase3.zip -oPhase3 -y
    "%ProgramFiles%\7-Zip\7z.exe" x AshleyAI_With_DLC1.zip -oDLC1 -y
) else (
    echo Using Windows built-in expand...
    mkdir Phase1 2>nul
    mkdir Phase2 2>nul
    mkdir Phase3 2>nul
    mkdir DLC1 2>nul
    echo Note: For full ZIP extraction, please use 7-Zip or right-click Extract All.
)

echo.
echo Unpacking completed!
echo.
echo Available Folders:
echo   - Phase1, Phase2, Phase3, DLC1
echo.
echo To run Ashley:
echo   cd DLC1\AshleyAI
echo   python Ashley.py
echo.
pause