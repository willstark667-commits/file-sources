#!/bin/bash
echo "Setting up Ashley AI Environment..."
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
echo "Setup complete. Run 'source venv/bin/activate' then 'python main.py'"
