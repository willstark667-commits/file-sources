import subprocess

class ToolRouter:
    """Bridges Ashley to external apps, terminal, and agent-browser."""
    def __init__(self):
        self.available_tools = ["browser", "terminal"]

    def route_command(self, tool_name, command):
        if tool_name not in self.available_tools:
            return f"Error: Tool '{tool_name}' not recognized."
        
        if tool_name == "browser":
            return self._run_browser(command)
        elif tool_name == "terminal":
            return self._run_terminal(command)
            
    def _run_browser(self, url):
        """Uses agent-browser for web navigation and scraping."""
        cmd = f"npx -y agent-browser --headed --session ashley-session open {url}"
        try:
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return res.stdout
        except Exception as e:
            return str(e)

    def _run_terminal(self, cmd):
        """Executes safe terminal commands."""
        try:
            res = subprocess.run(cmd, shell=True, capture_output=True, text=True)
            return res.stdout
        except Exception as e:
            return str(e)
