import json
import os
from datetime import datetime

class MemoryManager:
    """Handles Short-Term and Long-Term Persistent Memory for Ashley."""
    def __init__(self, data_dir="ashley_program/data"):
        self.data_dir = data_dir
        self.short_term = []
        self.long_term_file = os.path.join(data_dir, "long_term_memory.json")
        os.makedirs(data_dir, exist_ok=True)
        if not os.path.exists(self.long_term_file):
            with open(self.long_term_file, 'w') as f:
                json.dump([], f)

    def add_memory(self, role, content, tags=None):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "role": role,
            "content": content,
            "tags": tags or []
        }
        self.short_term.append(entry)
        if len(self.short_term) > 50:  # Keep short term context window manageable
            self.short_term.pop(0)
        self._save_long_term(entry)

    def _save_long_term(self, entry):
        with open(self.long_term_file, 'r+') as f:
            data = json.load(f)
            data.append(entry)
            f.seek(0)
            json.dump(data, f, indent=4)

    def search_memory(self, query):
        """Basic semantic/keyword search. Can be upgraded to Vector Embeddings."""
        with open(self.long_term_file, 'r') as f:
            data = json.load(f)
        results = [m for m in data if query.lower() in m['content'].lower()]
        return results
