import random

class LearningEngine:
    """Handles Mutation, Scoring, Epochs, and Self-Improvement."""
    def __init__(self):
        self.epoch = 0
        self.mutation_rate = 0.01
        self.weights = {
            "creativity": 0.5,
            "logic": 0.8,
            "empathy": 0.6,
            "syntax_strictness": 0.9
        }

    def evaluate_response(self, response_text):
        """Heuristic scoring of generated content."""
        score = len(response_text) * 0.05 + random.uniform(0, 2)
        return min(score, 10.0)

    def train_epoch(self, interactions_count):
        """Simulates backpropagation and weight adjustment over time."""
        self.epoch += 1
        for key in self.weights:
            mutation = random.uniform(-self.mutation_rate, self.mutation_rate)
            self.weights[key] = max(0.0, min(1.0, self.weights[key] + mutation))
        return {"epoch": self.epoch, "new_weights": self.weights}
