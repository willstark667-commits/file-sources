from flask import Flask, render_template, request, jsonify
import os

app = Flask(__name__, template_folder="templates", static_folder="static")
core_system = None  # Will be injected by main.py

@app.route("/")
def index():
    return render_template("index.html", name=core_system['name'])

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    if not user_input:
        return jsonify({"error": "Empty message"}), 400
    
    response = core_system['process_input'](user_input)
    return jsonify({"response": response})

def start_web_ui(core, port=5000):
    global core_system
    core_system = core
    print(f"Starting {core['name']} Web UI on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=False)
