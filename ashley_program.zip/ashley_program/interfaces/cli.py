class AshleyCLI:
    """Terminal Command Line Interface for Ashley."""
    def __init__(self, core_system):
        self.core = core_system

    def start(self):
        print("="*50)
        print(f"   {self.core['name']} Omni AI - Terminal Shell")
        print("="*50)
        print("Type 'exit' or 'quit' to shutdown.")
        
        while True:
            try:
                user_input = input("\n[User] > ")
                if user_input.lower() in ['exit', 'quit']:
                    print(f"[{self.core['name']}] Shutting down. Goodbye.")
                    break
                
                # Process input through core
                response = self.core['process_input'](user_input)
                print(f"[{self.core['name']}] > {response}")
                
            except KeyboardInterrupt:
                print(f"\n[{self.core['name']}] Force quit detected. Goodbye.")
                break
