import argparse
import sys
from core.memory import MemoryManager
from core.learning import LearningEngine
from core.voice import VoiceModule
from core.tools import ToolRouter
from interfaces.cli import AshleyCLI
from web.app import start_web_ui

class AshleyOmniSystem:
    def __init__(self):
        self.name = "Ashley"
        self.memory = MemoryManager()
        self.learning = LearningEngine()
        self.voice = VoiceModule()
        self.tools = ToolRouter()
        
        # Initial boot sequence
        self.memory.add_memory("system", "Ashley Omni System Boot Sequence Initiated.")
        
    def process_input(self, user_input):
        """Main processing loop for Ashley."""
        self.memory.add_memory("user", user_input)
        
        # 1. Check for tool commands (e.g., /browser search query)
        if user_input.startswith("/browser"):
            cmd = user_input.replace("/browser", "").strip()
            result = self.tools.route_command("browser", cmd)
            response = f"Browser Output:\n{result}"
            
        elif user_input.startswith("/terminal"):
            cmd = user_input.replace("/terminal", "").strip()
            result = self.tools.route_command("terminal", cmd)
            response = f"Terminal Output:\n{result}"
            
        else:
            # 2. Standard NLP / Logic processing (Simulated)
            # In a full deployment, this hooks into the local LLM or API
            response = f"I have processed your request: '{user_input}'. My current logic weight is {self.learning.weights['logic']:.2f}."
            
            # 3. Self-Learning & Scoring
            score = self.learning.evaluate_response(response)
            self.learning.train_epoch(1)
            
            # 4. Voice Hook (Optional)
            self.voice.text_to_speech(response)
            
        self.memory.add_memory("ai", response)
        return response

    def get_core_dict(self):
        return {
            "name": self.name,
            "process_input": self.process_input
        }

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ashley Omni AI System")
    parser.add_argument("--mode", choices=["cli", "web"], default="cli", help="Interface mode to launch")
    parser.add_argument("--port", type=int, default=5000, help="Port for Web UI")
    args = parser.parse_args()

    system = AshleyOmniSystem()
    core_dict = system.get_core_dict()

    if args.mode == "cli":
        cli = AshleyCLI(core_dict)
        cli.start()
    elif args.mode == "web":
        start_web_ui(core_dict, port=args.port)
