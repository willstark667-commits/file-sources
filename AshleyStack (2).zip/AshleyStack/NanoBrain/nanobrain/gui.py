"""
Tk shell, now three tabs:
  - Shell:      the command console from before, extended
  - Network:    2D visualizer -- circles for nodes, lines for connections,
                glow when active, fading when idle
  - Chat:       chatbox + history, routed through Ollama with the Ashley
                persona as system prompt, plus file upload/attachments

Dark background, amber/green monospace -- consistent CRT aesthetic
across all three tabs.
"""

import os
import time
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog

from . import config
from .network import Network
from . import scanner
from . import ollama_bridge
from .persona import Persona, KeywordTracker
from .chat import ChatHistory
from .voice import VoiceEngine
from .agents import build_default_hierarchy
from .os_bridge import GenesisOSBridge

BG = "#0a0f0a"
PANEL_BG = "#0e140e"
FG = "#33ff66"
ACCENT = "#ffb000"
DIM = "#1c6b34"
FONT = ("Consolas", 12)
FONT_SMALL = ("Consolas", 10)


class NanoBrainShell(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NanoBrain :: Ashley internal neural network")
        self.configure(bg=BG)
        self.geometry("1040x680")

        self.net = Network(num_nodes=config.MIN_NODES)
        self.persona = Persona.load_or_create_ashley()
        self.keywords = KeywordTracker(keywords=self.persona.keywords)
        self.chat_history = ChatHistory()
        self.voice = VoiceEngine()
        self.agents, self.agent_workspace = build_default_hierarchy()
        self.os_bridge = GenesisOSBridge()

        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL_BG, foreground=FG, padding=(12, 6))
        style.map("TNotebook.Tab", background=[("selected", DIM)])

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True)

        self.shell_tab = tk.Frame(self.tabs, bg=BG)
        self.network_tab = tk.Frame(self.tabs, bg=BG)
        self.chat_tab = tk.Frame(self.tabs, bg=BG)

        self.tabs.add(self.shell_tab, text="Shell")
        self.tabs.add(self.network_tab, text="Network")
        self.tabs.add(self.chat_tab, text="Chat — Ashley")

        self._build_shell_tab()
        self._build_network_tab()
        self._build_chat_tab()

        self._print_banner()
        self._redraw_network()

    # ======================================================================
    # SHELL TAB
    # ======================================================================
    def _build_shell_tab(self):
        self.output = scrolledtext.ScrolledText(
            self.shell_tab, bg=BG, fg=FG, insertbackground=FG, font=FONT,
            wrap="word", borderwidth=0, highlightthickness=0
        )
        self.output.pack(fill="both", expand=True, padx=8, pady=(8, 0))
        self.output.tag_configure("accent", foreground=ACCENT)
        self.output.configure(state="disabled")

        entry_frame = tk.Frame(self.shell_tab, bg=BG)
        entry_frame.pack(fill="x", padx=8, pady=8)
        tk.Label(entry_frame, text=">", bg=BG, fg=ACCENT, font=FONT).pack(side="left")
        self.entry = tk.Entry(entry_frame, bg=BG, fg=FG, insertbackground=FG,
                               font=FONT, borderwidth=0, highlightthickness=1,
                               highlightbackground=FG, highlightcolor=ACCENT)
        self.entry.pack(side="left", fill="x", expand=True, padx=(6, 0))
        self.entry.bind("<Return>", self._on_enter)
        self.entry.focus_set()

    def _print(self, text, tag=None):
        # shell commands run in a background thread (see _dispatch below),
        # and Tk widgets aren't safe to touch directly off the main thread
        # -- self.after(0, ...) hands the actual update back to the GUI
        # thread's event loop, which is the standard safe pattern for this.
        self.after(0, self._print_now, text, tag)

    def _print_now(self, text, tag=None):
        self.output.configure(state="normal")
        self.output.insert("end", text + "\n", tag or ())
        self.output.see("end")
        self.output.configure(state="disabled")

    def _print_banner(self):
        self._print("=" * 64, "accent")
        self._print("  NANOBRAIN -- Ashley / Cortana / Generic internal agent hierarchy")
        self._print("=" * 64, "accent")
        self._print(f"  nodes: {len(self.net.nodes)}  |  ollama: {'reachable' if ollama_bridge.is_available() else 'not reachable'}")
        self._print(f"  agents: {list(self.agents.keys())}  |  genesisOS bridge: {'available' if self.os_bridge.available else 'not found'}")
        self._print(f"  voice: {self.voice.status_text()}")
        self._print("  type 'help' for commands\n")

    def _on_enter(self, event=None):
        cmd = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not cmd:
            return
        self._print(f"> {cmd}", "accent")
        threading.Thread(target=self._dispatch, args=(cmd,), daemon=True).start()

    def _dispatch(self, cmd):
        parts = cmd.split(maxsplit=1)
        name = parts[0].lower()
        arg = parts[1] if len(parts) > 1 else ""
        handlers = {
            "help": self._cmd_help, "status": self._cmd_status, "nodes": self._cmd_nodes,
            "scan": self._cmd_scan, "search": self._cmd_search, "autogrow": self._cmd_autogrow,
            "pretrain": self._cmd_pretrain, "train": self._cmd_train, "predict": self._cmd_predict,
            "grow": self._cmd_grow, "save": self._cmd_save, "load": self._cmd_load,
            "keywords": self._cmd_keywords, "addkeyword": self._cmd_addkeyword,
            "voice": self._cmd_voice, "clear": self._cmd_clear, "exit": self._cmd_exit, "quit": self._cmd_exit,
            "agents": self._cmd_agents, "think": self._cmd_think, "whiteboard": self._cmd_whiteboard,
            "osbridge": self._cmd_osbridge,
        }
        handler = handlers.get(name)
        if handler is None:
            self._print(f"unknown command: {name}  (try 'help')")
            return
        handler(arg)

    def _cmd_help(self, arg):
        self._print(
            "commands:\n"
            "  status                 network status / maturity %\n"
            "  nodes                  list nodes: confidence, files, grokked\n"
            "  scan [path]            read-only scan + index a directory\n"
            "  search <keyword>       search the scan index\n"
            "  autogrow               scan workspace, predict node count + ETA, grow + pretrain one at a time\n"
            "  pretrain               phase 1 (all nodes independently, no per-file division)\n"
            "  train                  phase 2 joint training\n"
            "  predict <0|1>          feed a bit through the chain\n"
            "  grow                   add a single node\n"
            "  save / load            checkpoint the network\n"
            "  keywords               show Ashley-keyword tracker report\n"
            "  addkeyword <word>      track a new keyword\n"
            "  voice [on|off]         toggle voice, show status\n"
            "  agents                 status of the Ashley/Cortana/Generic agent hierarchy\n"
            "  think                  run one global-workspace thinking cycle across all agents\n"
            "  whiteboard             show the workspace's current working-memory buffer\n"
            "  osbridge               show GenesisOS bridge status (available if sibling GenesisOS/ dir found)\n"
            "  clear / exit\n"
        )

    def _cmd_status(self, arg):
        s = self.net.status()
        self._print(f"generation: {s['generation']}  steps: {s['training_steps']}  nodes: {s['nodes']}\n"
                     f"avg_confidence: {s['avg_confidence']}  last_loss: {s['last_loss']}  maturity: {s['maturity_pct']}%")

    def _cmd_nodes(self, arg):
        for n in self.net.nodes:
            self._print(f"  node {n.id:03d}  w={n.weight:+.3f} b={n.bias:+.3f} conf={n.confidence:.2f} "
                        f"vectors={n.num_vectors} own_files={len(n.list_own_files())} assigned={len(n.assigned_files)}")
        self._redraw_network()

    def _cmd_scan(self, arg):
        path = arg.strip() or None
        self._print("scanning (read-only)...")
        records = scanner.scan_directory(path)
        self._print(f"indexed {len(records)} files.")
        for r in records:
            if r.get("preview"):
                hits = self.keywords.scan_text(r["preview"] + " " + r["filename"], source=r["path"])
                if hits:
                    self._print(f"  keyword hit in {r['filename']}: {hits}", "accent")

    def _cmd_search(self, arg):
        if not arg:
            self._print("usage: search <keyword>")
            return
        hits = scanner.search_keyword(arg)
        if not hits:
            self._print("no matches.")
            return
        for h in hits[:20]:
            self._print(f"  {h['filename']}  ({h['size_bytes']} bytes)  {h['path']}")

    def _cmd_autogrow(self, arg):
        self._print("scanning workspace to predict node requirements...")
        records = scanner.scan_directory()
        pred = Network.predict_nodes_and_eta(len(records))
        self._print(f"files: {len(records)}  ->  predicted nodes: {pred['predicted_nodes']}  "
                    f"est. ETA: {pred['eta_seconds']}s")

        def on_created(node):
            self._print(f"  [+] spawned node {node.id:03d} ({len(self.net.nodes)}/{pred['predicted_nodes']})", "accent")
            self._redraw_network()

        self.net.generate_nodes_incrementally(pred["predicted_nodes"], on_node_created=on_created)

        self._print("dividing scanned files across nodes...")
        counts = self.net.divide_files_across_nodes(records)
        for nid, c in counts.items():
            self._print(f"  node {nid:03d} assigned {c} file(s)")

        self._print("pretraining nodes one at a time...")

        def on_node_done(node, report):
            grok_note = " (grokked)" if report["grokked"] else ""
            self._print(f"  node {node.id:03d} done: final_loss={report['final_loss']}"
                        f" files_trained_on={report['files_trained_on']}{grok_note}")
            self._redraw_network(active_node=node.id)

        self.net.pretrain_nodes_sequentially(on_node_done=on_node_done)
        self._print("autogrow + pretrain complete. run 'train' next for joint fine-tuning.")

    def _cmd_pretrain(self, arg):
        self._print("phase 1: pretraining each node independently...")
        report = self.net.pretrain_nodes_independently()
        for node_id, loss in report.items():
            self._print(f"  node {node_id:03d} local_loss={loss}")

    def _cmd_train(self, arg):
        self._print("phase 2: joint training...")
        avg_loss = self.net.train_joint()
        self._print(f"generation {self.net.generation}  avg_loss={avg_loss:.5f}")
        self._redraw_network()

    def _cmd_predict(self, arg):
        try:
            bit = int(arg.strip())
        except ValueError:
            self._print("usage: predict <0|1>")
            return
        out = self.net.predict_next(bit)
        self._print(f"input={bit}  ->  raw_output={out:.4f}  (rounds to {1 if out > 0 else 0})")
        self._redraw_network(pulse=True)

    def _cmd_grow(self, arg):
        node = self.net.grow()
        if node is None:
            self._print(f"already at max nodes ({config.MAX_NODES}).")
        else:
            self._print(f"spawned node {node.id:03d} with {node.num_vectors} vectors.")
        self._redraw_network()

    def _cmd_save(self, arg):
        self._print(f"checkpoint saved: {self.net.save()}")

    def _cmd_load(self, arg):
        try:
            self.net = Network.load()
            self._print("checkpoint loaded.")
            self._redraw_network()
        except FileNotFoundError:
            self._print("no checkpoint found yet -- run 'save' first.")

    def _cmd_keywords(self, arg):
        report = self.keywords.report()
        if not report:
            self._print("no keyword hits yet -- run 'scan' or chat about Ashley/persona topics first.")
            return
        for kw, v in report.items():
            self._print(f"  '{kw}': {v['count']} hit(s), last seen {v['last_seen']}")

    def _cmd_addkeyword(self, arg):
        if not arg:
            self._print("usage: addkeyword <word or phrase>")
            return
        self.keywords.add_keyword(arg)
        self.persona.add_keyword(arg)
        self.persona.save()
        self._print(f"tracking new keyword: '{arg.strip().lower()}'")

    def _cmd_voice(self, arg):
        arg = arg.strip().lower()
        if arg == "on" and not self.voice.live:
            self.voice.toggle()
        elif arg == "off" and self.voice.live:
            self.voice.toggle()
        self._print(f"voice: {self.voice.status_text()}")

    def _cmd_clear(self, arg):
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.configure(state="disabled")

    def _cmd_exit(self, arg):
        self.destroy()

    def _cmd_agents(self, arg):
        for name, agent in self.agents.items():
            s = agent.status()
            self._print(f"  {name}: nodes={s['nodes']} maturity={s['maturity_pct']}% "
                        f"inbox={s['inbox_size']}  traits={s['persona_traits']}")

    def _cmd_think(self, arg):
        self._print("running one global-workspace cycle (each agent proposes, one broadcasts)...")
        for name, agent in self.agents.items():
            out, sal = agent.think_and_propose()
            self._print(f"  {name} proposed: output={out:.4f} salience={sal:.3f}")
        winners = self.agent_workspace.run_cycle()
        if winners:
            for w in winners:
                self._print(f"  >>> broadcast winner: {w.source}  (salience={w.salience:.3f})", "accent")
        else:
            self._print("  no winner this cycle.")

    def _cmd_whiteboard(self, arg):
        items = self.agent_workspace.whiteboard()
        if not items:
            self._print("whiteboard is empty -- run 'think' a few times first.")
            return
        for it in items:
            self._print(f"  [{it['source']}] salience={it['salience']:.3f} content={it['content']}")

    def _cmd_osbridge(self, arg):
        s = self.os_bridge.status()
        self._print(f"  available: {s['available']}  path: {s['genesis_os_path']}")
        if not s["available"]:
            self._print(f"  ({s['last_error'] or 'GenesisOS not found as a sibling directory'})")
        else:
            self._print(f"  fs_mounted: {s['fs_mounted']}  -- exact ops (file I/O, asm) can now be invoked from here")

    # ======================================================================
    # NETWORK VISUALIZER TAB (2D: circles + lines, glow on activity)
    # ======================================================================
    def _build_network_tab(self):
        top = tk.Frame(self.network_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=6)
        tk.Label(top, text="2D node graph -- circles are nodes, lines are connections, glow = active",
                 bg=BG, fg=DIM, font=FONT_SMALL).pack(side="left")

        btns = tk.Frame(self.network_tab, bg=BG)
        btns.pack(fill="x", padx=8)
        tk.Button(btns, text="Add Node", command=self._btn_add_node, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        tk.Button(btns, text="Pulse / Predict", command=self._btn_pulse, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        tk.Button(btns, text="Refresh", command=self._redraw_network, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="left")

        self.canvas = tk.Canvas(self.network_tab, bg=BG, highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=8, pady=8)

    def _btn_add_node(self):
        self.net.grow()
        self._redraw_network()

    def _btn_pulse(self):
        self.net.predict_next(1)
        self._redraw_network(pulse=True)

    def _redraw_network(self, active_node=None, pulse=False):
        # same cross-thread concern as _print -- canvas drawing must
        # happen on the main thread, so schedule it via after()
        self.after(0, self._redraw_network_now, active_node, pulse)

    def _redraw_network_now(self, active_node=None, pulse=False):
        if not hasattr(self, "canvas"):
            return
        self.canvas.delete("all")
        self.update_idletasks()
        w = max(self.canvas.winfo_width(), 400)
        h = max(self.canvas.winfo_height(), 300)

        nodes = self.net.nodes
        n = len(nodes)
        if n == 0:
            return

        # simple left-to-right layered layout (chain = layers, since this
        # prototype's network is a chain of nodes; each node is its own layer)
        margin = 60
        spacing = (w - 2 * margin) / max(1, n - 1) if n > 1 else 0
        positions = []
        for i in range(n):
            x = margin + i * spacing if n > 1 else w / 2
            y = h / 2
            positions.append((x, y))

        # connections (lines) -- chain, matches the actual signal path
        for i in range(n - 1):
            x1, y1 = positions[i]
            x2, y2 = positions[i + 1]
            self.canvas.create_line(x1, y1, x2, y2, fill=DIM, width=2)

        # nodes (circles) -- glow (brighter/larger) if active or high confidence
        radius_base = 22
        for i, node in enumerate(nodes):
            x, y = positions[i]
            is_active = pulse or (active_node is not None and node.id == active_node)
            glow = node.confidence if node.confidence else 0.3
            radius = radius_base + (10 if is_active else 0)
            color = ACCENT if is_active else _blend(DIM, FG, glow)

            if is_active:
                self.canvas.create_oval(x - radius - 8, y - radius - 8, x + radius + 8, y + radius + 8,
                                         outline=ACCENT, width=1)
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                     fill=color, outline=FG, width=1)
            self.canvas.create_text(x, y, text=str(node.id), fill=BG, font=FONT_SMALL)
            self.canvas.create_text(x, y + radius + 14, text=f"conf {node.confidence:.2f}",
                                     fill=DIM, font=("Consolas", 8))

    # ======================================================================
    # CHAT TAB
    # ======================================================================
    def _build_chat_tab(self):
        top = tk.Frame(self.chat_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=(8, 0))
        tk.Label(top, text=f"chatting with {self.persona.name}", bg=BG, fg=ACCENT, font=FONT).pack(side="left")
        self.voice_label = tk.Label(top, text=self.voice.status_text(), bg=BG, fg=DIM, font=FONT_SMALL)
        self.voice_label.pack(side="right")
        tk.Button(top, text="Toggle Voice", command=self._toggle_voice, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="right", padx=8)

        self.chat_box = scrolledtext.ScrolledText(
            self.chat_tab, bg=BG, fg=FG, insertbackground=FG, font=FONT,
            wrap="word", borderwidth=0, highlightthickness=0
        )
        self.chat_box.pack(fill="both", expand=True, padx=8, pady=8)
        self.chat_box.tag_configure("user", foreground=ACCENT)
        self.chat_box.tag_configure("assistant", foreground=FG)
        self.chat_box.configure(state="disabled")

        for msg in self.chat_history.recent():
            self._append_chat(msg["role"], msg["content"], persist=False)

        bottom = tk.Frame(self.chat_tab, bg=BG)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        tk.Button(bottom, text="Attach File", command=self._attach_file, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="left")
        self.chat_entry = tk.Entry(bottom, bg=BG, fg=FG, insertbackground=FG, font=FONT,
                                    borderwidth=0, highlightthickness=1,
                                    highlightbackground=FG, highlightcolor=ACCENT)
        self.chat_entry.pack(side="left", fill="x", expand=True, padx=8)
        self.chat_entry.bind("<Return>", self._on_chat_enter)
        tk.Button(bottom, text="Send", command=self._on_chat_enter, bg=PANEL_BG, fg=FG,
                  activebackground=DIM, borderwidth=0).pack(side="left")

    def _append_chat(self, role, content, persist=True):
        try:
            self.chat_box.configure(state="normal")
            speaker = self.persona.name if role == "assistant" else "you"
            self.chat_box.insert("end", f"{speaker}: ", "user" if role == "user" else "assistant")
            self.chat_box.insert("end", content + "\n\n")
            self.chat_box.see("end")
            self.chat_box.configure(state="disabled")
        except tk.TclError:
            pass  # window was closed while a background reply was in flight
        if persist:
            self.chat_history.add(role, content)
        self.keywords.scan_text(content, source=f"chat:{role}:{time.strftime('%H:%M:%S')}")

    def _on_chat_enter(self, event=None):
        text = self.chat_entry.get().strip()
        if not text:
            return
        self.chat_entry.delete(0, "end")
        self._append_chat("user", text)
        threading.Thread(target=self._get_assistant_reply, args=(text,), daemon=True).start()

    def _get_assistant_reply(self, user_text):
        if ollama_bridge.is_available():
            reply = ollama_bridge.chat(
                self.chat_history.as_ollama_messages(),
                system=self.persona.system_prompt(),
            )
        else:
            # fallback: route the message through the toy network + a
            # plain acknowledgement, so chat still "does something" even
            # without Ollama running
            signal = sum(ord(c) for c in user_text) % 2
            net_out = self.net.predict_next(signal)
            reply = (f"[Ollama not reachable -- this is the fallback path, not real language "
                     f"understanding] my internal chain read your message as signal={signal} "
                     f"and produced raw_output={net_out:.4f}. Start `ollama serve` with "
                     f"'{config.OLLAMA_MODEL}' pulled for a real reply.")
        self.after(0, self._append_chat, "assistant", reply)
        if self.voice.live:
            self.voice.speak(reply)

    def _toggle_voice(self):
        live = self.voice.toggle()
        self.voice_label.configure(text=self.voice.status_text())
        self._append_chat("assistant", f"voice is now {'LIVE' if live else 'off'}.", persist=False)

    def _attach_file(self):
        path = filedialog.askopenfilename()
        if not path:
            return
        name = os.path.basename(path)
        dest_dir = config.UPLOADS_DIR
        os.makedirs(dest_dir, exist_ok=True)
        dest = os.path.join(dest_dir, name)
        try:
            with open(path, "rb") as src, open(dest, "wb") as dst:
                dst.write(src.read())
        except OSError as e:
            self._append_chat("assistant", f"couldn't attach {name}: {e}", persist=False)
            return
        self._append_chat("user", f"[attached file: {name}]")
        preview = ""
        try:
            with open(dest, "r", errors="ignore") as fh:
                preview = fh.read(300)
        except OSError:
            pass
        hits = self.keywords.scan_text(name + " " + preview, source=dest)
        note = f" (keyword hits: {hits})" if hits else ""
        self._append_chat("assistant", f"got it -- stored under data/uploads/{name}, indexed for search.{note}",
                          persist=False)


def run():
    config.ensure_dirs()
    app = NanoBrainShell()
    app.mainloop()


def _blend(hex1, hex2, t):
    """Linear-blend two #rrggbb colors by t in [0,1] -- used for the
    confidence-based glow color on nodes."""
    t = max(0.0, min(1.0, t))
    c1 = tuple(int(hex1[i:i+2], 16) for i in (1, 3, 5))
    c2 = tuple(int(hex2[i:i+2], 16) for i in (1, 3, 5))
    blended = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
    return "#%02x%02x%02x" % blended
