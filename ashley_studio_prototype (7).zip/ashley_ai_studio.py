#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║   ASHLEY AI STUDIO v3.2 — Ashley AI Agent Orchestrator                      ║
║   FakepunkAshleyNeuralForge | Phase 20+ | Windows / Mac / Linux             ║
╠══════════════════════════════════════════════════════════════════════════════╣
║   Launch Modes:                                                              ║
║     python ashley_ai_studio.py              → Full Tkinter GUI (default)            ║
║     python ashley_ai_studio.py --shell      → Rich terminal shell                   ║
║     python ashley_ai_studio.py --web        → Flask web dashboard                   ║
║     python ashley_ai_studio.py --setup      → Install all dependencies              ║
║     python ashley_ai_studio.py --scan       → Deep project scanner                  ║
║     python ashley_ai_studio.py --scan PATH  → Scan specific folder                  ║
║     python ashley_ai_studio.py --train      → Run training pipeline                 ║
║     python ashley_ai_studio.py --index      → Build vector knowledge index          ║
║     python ashley_ai_studio.py --graph      → Build knowledge graph                 ║
║     python ashley_ai_studio.py --dataset    → Export training datasets              ║
║     python ashley_ai_studio.py --build-exe  → Package to .exe (PyInstaller)        ║
║     python ashley_ai_studio.py --compat     → OS compatibility patch                ║
║     python ashley_ai_studio.py --diag       → Full diagnostics report               ║
║     python ashley_ai_studio.py --test       → Run system tests                      ║
║     python ashley_ai_studio.py --model NAME → Launch with a chosen Ollama model     ║
║     python ashley_ai_studio.py --pull NAME  → Pull an Ollama model and exit         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

# ── Standard Library Imports (zero external deps for startup) ─────────────────
import sys
import os
import re
import ast
import json
import time
import math
import queue
import random
import shutil
import hashlib
import sqlite3
import argparse
import platform
import threading
import subprocess
import traceback
import importlib
from pathlib import Path
from datetime import datetime
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Tuple, Any, Callable, Generator

# ── Optional Odysseus backend (odysseus_client.py must sit next to this file) ─
try:
    from odysseus_client import OdysseusClient, OdysseusError
except ImportError:
    OdysseusClient = None
    class OdysseusError(RuntimeError):
        pass

# ── Windows Compatibility Layer (runs before ANYTHING else) ───────────────────
def _win_bootstrap():
    """Must run first — fixes Windows console, encoding, path limits."""
    if platform.system() != "Windows":
        return
    # Force UTF-8 output
    os.environ.setdefault("PYTHONUTF8", "1")
    try:
        import ctypes
        # Enable UTF-8 console code page
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        ctypes.windll.kernel32.SetConsoleCP(65001)
        # Enable ANSI escape codes (Windows 10+)
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)
    except Exception:
        pass
    # Enable long paths (requires admin or registry key on older Windows)
    try:
        import ctypes
        ctypes.windll.kernel32.SetFileAttributesW.argtypes = [ctypes.c_wchar_p, ctypes.c_uint32]
    except Exception:
        pass

_win_bootstrap()

# ── Root & Path Setup ─────────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    # Running as PyInstaller .exe
    ROOT = Path(sys.executable).parent.resolve()
    _FROZEN = True
else:
    ROOT = Path(__file__).parent.resolve()
    _FROZEN = False

sys.path.insert(0, str(ROOT))

# ── Platform Detection ────────────────────────────────────────────────────────
OS_NAME  = platform.system()        # Windows / Darwin / Linux
OS_VER   = platform.version()
OS_REL   = platform.release()
ARCH     = platform.machine()
PY_VER   = sys.version_info
IS_WIN   = OS_NAME == "Windows"
IS_MAC   = OS_NAME == "Darwin"
IS_LIN   = OS_NAME == "Linux"
FROZEN   = _FROZEN

# ── Version ───────────────────────────────────────────────────────────────────
VERSION  = "3.2"
BUILD    = "Phase20Plus_MasterBuild"
CODENAME = "AshleyAIStudio"

# ══════════════════════════════════════════════════════════════════════════════
#  COLOUR HELPERS — no external deps
# ══════════════════════════════════════════════════════════════════════════════
_USE_COLOUR = not IS_WIN or os.environ.get("TERM") or os.environ.get("WT_SESSION")

def _clr(t, c): return f"\033[{c}m{t}\033[0m" if _USE_COLOUR else t
def cyan(t):    return _clr(t, "96")
def green(t):   return _clr(t, "92")
def yellow(t):  return _clr(t, "93")
def red(t):     return _clr(t, "91")
def magenta(t): return _clr(t, "95")
def bold(t):    return _clr(t, "1")
def dim(t):     return _clr(t, "2")
def white(t):   return _clr(t, "97")

# ══════════════════════════════════════════════════════════════════════════════
#  BANNER
# ══════════════════════════════════════════════════════════════════════════════
BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║  ___  ___  _   _ _____ ___ ___ ___ _   _ ____                   ║
║ / _ \|  _ \\ \ / / ____/ __/ __| __| | | / ___|                ║
║| | | | | | |\ V /|  _| \___ \___ \  _| | | \___ \              ║
║| |_| | |_| | | | | |___ ___) |__) | |_| |_| ___) |             ║
║ \___/|____/  |_| |_____|____/____/|_____\__|____/               ║
║                                                                  ║
║  A S H L E Y   A I   S T U D I O   v3.2   [ Phase 20+ ]        ║
║  FakepunkAshleyNeuralForge  |  Axon  |  Odysseus                ║
╚══════════════════════════════════════════════════════════════════╝
"""

# ══════════════════════════════════════════════════════════════════════════════
#  DIRECTORY SCAFFOLD
# ══════════════════════════════════════════════════════════════════════════════
CORE_DIRS = [
    "core", "ashley", "neural", "networks", "hub", "gui", "shell",
    "memory", "training", "scanner", "voice", "image", "video",
    "logic", "dream", "evidence", "compat", "database", "virtual",
    "llm", "tts", "stt", "logs", "data", "models", "exports", "phases",
    "agents", "database/vector", "database/cache", "data/datasets",
    "exports/graphs", "exports/reports",
]

def ensure_dirs():
    for d in CORE_DIRS:
        p = ROOT / d
        p.mkdir(parents=True, exist_ok=True)
    # __init__.py for Python package dirs
    pkg_dirs = ["core","ashley","neural","hub","memory","training","scanner",
                "voice","logic","dream","agents","llm","tts","stt","virtual"]
    for d in pkg_dirs:
        init = ROOT / d / "__init__.py"
        if not init.exists():
            try:
                init.write_text(f'"""Ashley AI Studio — {d} package"""\n', encoding="utf-8")
            except Exception:
                pass

# ══════════════════════════════════════════════════════════════════════════════
#  DATABASE INITIALISATION
# ══════════════════════════════════════════════════════════════════════════════
def init_database() -> Path:
    db_path = ROOT / "database" / "ashley_memory.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        -- Core memory store
        CREATE TABLE IF NOT EXISTS memory (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp   TEXT,
            level       TEXT,
            content     TEXT,
            logic_score REAL DEFAULT 0,
            dream_score REAL DEFAULT 0,
            emotion     TEXT DEFAULT 'neutral'
        );
        -- Neural nodes
        CREATE TABLE IF NOT EXISTS nodes (
            id          TEXT PRIMARY KEY,
            role        TEXT,
            activation  REAL DEFAULT 0,
            state       TEXT DEFAULT 'idle',
            created     TEXT,
            last_active TEXT
        );
        -- Sessions
        CREATE TABLE IF NOT EXISTS sessions (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id    TEXT,
            started       TEXT,
            ended         TEXT,
            message_count INTEGER DEFAULT 0
        );
        -- Training log
        CREATE TABLE IF NOT EXISTS training_log (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            phase     TEXT,
            stage     TEXT,
            metric    TEXT,
            value     REAL
        );
        -- Logic/dream scores
        CREATE TABLE IF NOT EXISTS logic_scores (
            id             INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp      TEXT,
            text           TEXT,
            logic_score    REAL,
            dream_score    REAL,
            classification TEXT
        );
        -- Knowledge index (scanner results)
        CREATE TABLE IF NOT EXISTS knowledge_index (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            filepath    TEXT UNIQUE,
            filetype    TEXT,
            size_bytes  INTEGER,
            line_count  INTEGER,
            hash_sha256 TEXT,
            summary     TEXT,
            tags        TEXT,
            imports     TEXT,
            functions   TEXT,
            classes     TEXT,
            indexed_at  TEXT,
            modified_at TEXT
        );
        -- Dataset records
        CREATE TABLE IF NOT EXISTS dataset (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            input     TEXT,
            output    TEXT,
            label     TEXT,
            score     REAL,
            source    TEXT,
            timestamp TEXT
        );
        -- Knowledge graph nodes
        CREATE TABLE IF NOT EXISTS graph_nodes (
            id        TEXT PRIMARY KEY,
            node_type TEXT,
            name      TEXT,
            meta      TEXT,
            created   TEXT
        );
        -- Knowledge graph edges
        CREATE TABLE IF NOT EXISTS graph_edges (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            src_id      TEXT,
            dst_id      TEXT,
            relation    TEXT,
            weight      REAL DEFAULT 1.0,
            created     TEXT
        );
        -- Agent registry
        CREATE TABLE IF NOT EXISTS agents (
            id          TEXT PRIMARY KEY,
            name        TEXT,
            role        TEXT,
            state       TEXT DEFAULT 'idle',
            task_queue  TEXT DEFAULT '[]',
            memory_ref  TEXT,
            created     TEXT,
            last_active TEXT
        );
        -- Long-term project memory
        CREATE TABLE IF NOT EXISTS project_memory (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            project     TEXT,
            key         TEXT,
            value       TEXT,
            confidence  REAL DEFAULT 1.0,
            timestamp   TEXT
        );
        -- RLHF feedback
        CREATE TABLE IF NOT EXISTS rlhf_feedback (
            id        INTEGER PRIMARY KEY AUTOINCREMENT,
            response  TEXT,
            rating    REAL,
            timestamp TEXT
        );
    """)
    conn.commit()
    conn.close()
    return db_path

# ══════════════════════════════════════════════════════════════════════════════
#  DEPENDENCY MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════
REQUIRED_DEPS = {
    # Module name → install command
    "rich":                 "rich",
    "numpy":                "numpy",
    "requests":             "requests",
    "psutil":               "psutil",
    "flask":                "flask flask-socketio",
    "pyttsx3":              "pyttsx3",
    "speech_recognition":   "SpeechRecognition",
    "PIL":                  "Pillow",
    "sklearn":              "scikit-learn",
    "chromadb":             "chromadb",
    "sentence_transformers":"sentence-transformers",
    "torch":                "torch --index-url https://download.pytorch.org/whl/cpu",
    "cv2":                  "opencv-python",
    "colorama":             "colorama",
}

def check_deps() -> Tuple[List[str], List[str]]:
    ok, missing = [], []
    for mod, _ in REQUIRED_DEPS.items():
        try:
            importlib.import_module(mod)
            ok.append(mod)
        except ImportError:
            missing.append(mod)
    return ok, missing

def run_setup():
    print(cyan("\n[SETUP] Installing / updating dependencies..."))
    ok, missing = check_deps()
    if not missing:
        print(green("  All dependencies already installed!"))
        return
    for mod in missing:
        pkg = REQUIRED_DEPS[mod]
        print(f"  Installing {yellow(mod)} ← pip install {pkg}")
        cmd = [sys.executable, "-m", "pip", "install"] + pkg.split() + ["--quiet"]
        try:
            subprocess.run(cmd, check=False, timeout=120)
            print(f"    {green('✓')} Done")
        except Exception as e:
            print(f"    {red('✗')} Failed: {e}")
    # Try to install PyAudio separately (Windows wheel)
    if IS_WIN:
        print(f"\n  {yellow('[TIP]')} If PyAudio fails, download the wheel from:")
        print("    https://www.lfd.uci.edu/~gohlke/pythonlibs/#pyaudio")
    print(green("\n  Setup complete!"))

# ══════════════════════════════════════════════════════════════════════════════
#  OS COMPATIBILITY PATCH
# ══════════════════════════════════════════════════════════════════════════════
def run_compat_patch() -> dict:
    print(cyan("\n[COMPAT] Running OS compatibility patch..."))
    report = {
        "os": OS_NAME, "version": OS_VER, "release": OS_REL,
        "arch": ARCH, "python": f"{PY_VER.major}.{PY_VER.minor}.{PY_VER.micro}",
        "frozen": FROZEN, "patches": [], "warnings": [], "completion": 0
    }
    patches = []

    if IS_WIN:
        patches += [
            "Set PYTHONUTF8=1 (UTF-8 filesystem encoding)",
            "Set console code page to 65001 (UTF-8)",
            "Enable ANSI escape codes via kernel32",
            "Check Windows version (10+ recommended)",
            "Check long path support",
            "Tkinter DPI awareness (system)",
            "Set PYTHONIOENCODING=utf-8",
        ]
        os.environ["PYTHONUTF8"]       = "1"
        os.environ["PYTHONIOENCODING"] = "utf-8"
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
            patches.append("Console CP set to 65001 ✓")
        except Exception:
            report["warnings"].append("Could not set console CP via ctypes")
        # DPI awareness
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
            patches.append("DPI awareness: System ✓")
        except Exception:
            pass
        # Windows version check
        try:
            ver = tuple(int(x) for x in platform.version().split(".")[:2])
            if ver[0] < 10:
                report["warnings"].append(f"Windows {ver[0]} detected — upgrade to Windows 10+ recommended")
            else:
                patches.append(f"Windows {ver[0]} (build {ver[1]}) — compatible ✓")
        except Exception:
            pass

    if IS_MAC:
        patches += [
            "Use macOS Tk framework",
            "Fix clipboard access on macOS",
            "Disable App Transport Security for local LLM (localhost)",
            "Set OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES",
        ]
        os.environ["OBJC_DISABLE_INITIALIZE_FORK_SAFETY"] = "YES"

    if IS_LIN:
        patches += [
            "Use system Tkinter (tk-dev required)",
            "Check PulseAudio/ALSA for TTS/STT",
            "Set XDG_RUNTIME_DIR if missing",
        ]
        if not os.environ.get("XDG_RUNTIME_DIR"):
            os.environ["XDG_RUNTIME_DIR"] = f"/run/user/{os.getuid()}"

    # Universal patches
    patches += [
        "Ensure UTF-8 file encoding default",
        "Create missing directory scaffold",
        "Initialise SQLite databases with WAL mode",
        "Set log level INFO",
        "Validate Python 3.9+ requirement",
    ]
    if PY_VER < (3, 9):
        report["warnings"].append(f"Python {PY_VER.major}.{PY_VER.minor} detected — upgrade to 3.10+ recommended")

    report["patches"] = patches
    report["completion"] = min(100, len(patches) * 5 + 30)

    for p in patches:
        print(f"  {green('✓')} {p}")
    if report["warnings"]:
        for w in report["warnings"]:
            print(f"  {yellow('⚠')} {w}")

    out = ROOT / "compat" / "patch_report.json"
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\n  {bold('Completion:')} {green(str(report['completion']) + '%')}")
    print(f"  Report → compat/patch_report.json")
    return report

# ══════════════════════════════════════════════════════════════════════════════
#  DIAGNOSTICS & DEBUG — error logs, syntax checks, dependency audit, suggestions
# ══════════════════════════════════════════════════════════════════════════════

# Known fixable patterns: (substring to find) -> (replacement, human explanation)
# Conservative on purpose — only patterns we can fix with total confidence.
_KNOWN_FIXES = {
    "hash_sha25 la": ("hash_sha256", "typo'd column/variable name"),
}

# Traceback exception → plain-English suggestion (does not auto-fix; informs only)
_TRACEBACK_HINTS = {
    "ModuleNotFoundError": "Missing package — run --setup or pip install the named module.",
    "ImportError":         "Import failed — check the module is installed and spelled correctly.",
    "FileNotFoundError":   "A required file/folder is missing — run --compat to rebuild the scaffold.",
    "PermissionError":     "OS denied file access — check permissions, or on Windows run as admin.",
    "sqlite3.OperationalError": "Database/SQL issue — check for a syntax typo near the reported column.",
    "JSONDecodeError":     "A JSON file is corrupted — delete it and let the app regenerate it.",
    "ConnectionRefusedError": "Could not reach a local server — is Ollama running? (ollama serve)",
    "RecursionError":      "Infinite recursion — check for a function calling itself without a base case.",
    "AttributeError":      "Called something that doesn't exist on that object — likely a version mismatch.",
    "TypeError":           "Wrong type passed somewhere — check the traceback line for the exact call.",
}


class Diagnostics:
    """
    Read-only by default. Only ever WRITES to this same source file when
    self.apply_fixes=True is explicitly passed AND a backup already exists
    -- never touches any other file or directory in the project.
    """
    def __init__(self):
        self.log_dir   = ROOT / "logs"
        self.exports   = ROOT / "exports"
        self.log_dir.mkdir(exist_ok=True)
        self.exports.mkdir(exist_ok=True)
        self.error_log = self.log_dir / "errors.jsonl"

    # -- error logging (call this from any except block project-wide) --------
    def log_error(self, context: str, exc: Exception):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "context":   context,
            "type":      type(exc).__name__,
            "message":   str(exc),
            "traceback": traceback.format_exc(),
        }
        with open(self.error_log, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        return entry

    def recent_errors(self, limit: int = 20) -> List[dict]:
        if not self.error_log.exists():
            return []
        lines = self.error_log.read_text(encoding="utf-8").splitlines()
        out = []
        for line in lines[-limit:]:
            try:
                out.append(json.loads(line))
            except Exception:
                continue
        return list(reversed(out))

    def hint_for(self, exc_type: str) -> str:
        return _TRACEBACK_HINTS.get(exc_type, "No specific hint on file — check the full traceback above.")

    # -- syntax check across the whole project (Python only; .py is what we can
    #    safely parse with ast — .js/.java are reported as present but not
    #    syntax-validated since that needs an external compiler/runtime) -----
    def check_syntax(self, root: Path = None) -> dict:
        root = root or ROOT
        ok, errors = [], []
        for fp in root.rglob("*.py"):
            if any(skip in fp.parts for skip in SKIP_DIRS):
                continue
            try:
                src = fp.read_text(encoding="utf-8", errors="replace")
                ast.parse(src, filename=str(fp))
                ok.append(str(fp.relative_to(root)))
            except SyntaxError as e:
                errors.append({
                    "file": str(fp.relative_to(root)),
                    "line": e.lineno, "msg": e.msg,
                })
            except Exception as e:
                errors.append({"file": str(fp.relative_to(root)), "line": None, "msg": str(e)})
        return {
            "checked":  len(ok) + len(errors),
            "ok":       len(ok),
            "errors":   errors,
            "health_pct": round(len(ok) / max(1, len(ok) + len(errors)) * 100, 1),
        }

    # -- dependency audit (re-uses the same REQUIRED_DEPS table as --setup) ----
    def check_dependencies(self) -> dict:
        ok, missing = check_deps()
        return {"installed": ok, "missing": missing,
                "install_cmds": [f"pip install {REQUIRED_DEPS[m]}" for m in missing]}

    # -- find known-fixable string patterns (very small, very safe list) -------
    def find_known_issues(self, root: Path = None) -> List[dict]:
        """Scans for known-bad patterns in source files. Skips this module's
        own _KNOWN_FIXES definition line so the scanner doesn't flag itself
        for containing the very strings it's searching for."""
        root = root or ROOT
        found = []
        self_path = Path(__file__).resolve()
        for fp in root.rglob("*.py"):
            if any(skip in fp.parts for skip in SKIP_DIRS):
                continue
            try:
                src = fp.read_text(encoding="utf-8", errors="replace")
            except Exception:
                continue
            is_self = fp.resolve() == self_path
            for bad, (fix, why) in _KNOWN_FIXES.items():
                if bad not in src:
                    continue
                if is_self and f'"{bad}"' in src:
                    continue  # this is the pattern's own definition, not a real hit
                found.append({"file": str(fp.relative_to(root)), "bad": bad,
                             "fix": fix, "why": why})
        return found

    def apply_known_fix(self, file_path: Path, bad: str, fix: str) -> bool:
        """Backs up the file before touching it. Only called when the user
        explicitly confirms — never runs automatically."""
        try:
            src = file_path.read_text(encoding="utf-8", errors="replace")
            if bad not in src:
                return False
            backup = safe_backup_file(file_path)
            file_path.write_text(src.replace(bad, fix), encoding="utf-8")
            return backup is not None
        except Exception:
            return False

    # -- full report, used by both shell `diag` and GUI Diagnostics tab --------
    def full_report(self, root: Path = None) -> dict:
        root = root or ROOT
        syntax  = self.check_syntax(root)
        deps    = self.check_dependencies()
        issues  = self.find_known_issues(root)
        errors  = self.recent_errors(10)
        report = {
            "generated_at": datetime.now().isoformat(),
            "os": OS_NAME, "python": f"{PY_VER.major}.{PY_VER.minor}.{PY_VER.micro}",
            "syntax": syntax,
            "dependencies": deps,
            "known_issues": issues,
            "recent_errors": [
                {"type": e["type"], "message": e["message"], "context": e["context"],
                 "hint": self.hint_for(e["type"])} for e in errors
            ],
        }
        (self.exports / "diagnostics_report.json").write_text(
            json.dumps(report, indent=2), encoding="utf-8"
        )
        return report

# ══════════════════════════════════════════════════════════════════════════════
#  ADVANCED FILE SCANNER — recursive, multi-type, metadata extraction
# ══════════════════════════════════════════════════════════════════════════════

# All supported file extensions
SCAN_EXTENSIONS = {
    # Code
    ".py":    "python",   ".js":   "javascript", ".ts":  "typescript",
    ".cs":    "csharp",   ".cpp":  "cpp",         ".c":   "c",
    ".h":     "c_header", ".rs":   "rust",         ".go":  "go",
    ".java":  "java",     ".rb":   "ruby",          ".php": "php",
    ".swift": "swift",    ".kt":   "kotlin",        ".lua": "lua",
    # Web
    ".html":  "html",     ".css":  "css",           ".jsx": "jsx",
    ".tsx":   "tsx",      ".vue":  "vue",
    # Config
    ".json":  "json",     ".yaml": "yaml",           ".yml": "yaml",
    ".xml":   "xml",      ".toml": "toml",           ".ini": "ini",
    ".env":   "env",      ".cfg":  "config",
    # Data
    ".csv":   "csv",      ".tsv":  "tsv",
    # Docs
    ".md":    "markdown", ".txt":  "text",           ".rst": "rst",
    # Scripts
    ".bat":   "batch",    ".sh":   "shell",          ".ps1": "powershell",
    # Data stores
    ".sql":   "sql",
}

# Directories to always skip
SKIP_DIRS = {
    "__pycache__", ".git", ".svn", ".hg", "node_modules",
    "venv", ".venv", "env", ".env", "dist", "build",
    ".tox", ".pytest_cache", ".mypy_cache", "site-packages",
    "database", "models", "exports", "logs", ".idea", ".vscode",
}

# Secret / credential pattern detector
SECRET_PATTERNS = [
    r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{4,}",
    r"(?i)(api[_-]?key|apikey|secret[_-]?key)\s*[=:]\s*['\"][^'\"]{8,}",
    r"sk-[A-Za-z0-9]{20,}",           # OpenAI keys
    r"AKIA[0-9A-Z]{16}",              # AWS keys
    r"(?i)token\s*[=:]\s*['\"][^'\"]{8,}",
    r"ghp_[A-Za-z0-9]{36}",           # GitHub tokens
]

@dataclass
class FileRecord:
    filepath:    str
    filetype:    str
    size_bytes:  int
    line_count:  int
    hash_sha256: str
    summary:     str       = ""
    tags:        List[str] = field(default_factory=list)
    imports:     List[str] = field(default_factory=list)
    functions:   List[str] = field(default_factory=list)
    classes:     List[str] = field(default_factory=list)
    has_secrets: bool      = False
    indexed_at:  str       = field(default_factory=lambda: datetime.now().isoformat())
    modified_at: str       = ""

    def to_dict(self) -> dict:
        return asdict(self)


class AdvancedScanner:
    """
    Recursive multi-language project scanner.
    Extracts metadata, builds knowledge index, detects secrets,
    generates summaries and tags for every file.
    """

    def __init__(self, root: Path = None, progress_cb: Callable = None):
        self.root        = root or ROOT
        self.progress_cb = progress_cb
        self.records:    List[FileRecord] = []
        self.errors:     List[dict]       = []
        self.skipped:    int = 0
        self._secret_re  = [re.compile(p) for p in SECRET_PATTERNS]

    def scan(self, path: Path = None) -> Dict:
        """Recursively scan path and return summary dict."""
        scan_root = path or self.root
        print(cyan(f"\n[SCANNER] Scanning: {scan_root}"))
        start = time.time()
        self.records = []
        self.errors  = []
        self.skipped = 0

        all_files = []
        for p in scan_root.rglob("*"):
            if p.is_file():
                # Skip hidden, skip dirs
                parts = set(p.parts)
                if any(d in parts for d in SKIP_DIRS):
                    self.skipped += 1
                    continue
                if p.suffix.lower() in SCAN_EXTENSIONS:
                    all_files.append(p)

        total = len(all_files)
        print(f"  Found {cyan(str(total))} scannable files")

        for i, fp in enumerate(all_files):
            if self.progress_cb:
                self.progress_cb(i + 1, total, str(fp.name))
            rec = self._process_file(fp)
            if rec:
                self.records.append(rec)
            if (i + 1) % 50 == 0:
                print(f"  ... {i+1}/{total} files processed")

        elapsed = time.time() - start
        summary = self._build_summary(elapsed)
        self._save_to_db()
        self._save_reports(summary)
        print(f"\n  {green('✓')} Scan complete: {len(self.records)} files in {elapsed:.1f}s")
        return summary

    def _process_file(self, fp: Path) -> Optional[FileRecord]:
        try:
            stat = fp.stat()
            ext  = fp.suffix.lower()
            ft   = SCAN_EXTENSIONS.get(ext, "unknown")
            mod  = datetime.fromtimestamp(stat.st_mtime).isoformat()

            # Read content
            try:
                content = fp.read_text(encoding="utf-8", errors="replace")
            except Exception:
                return None

            lines      = content.splitlines()
            sha        = hashlib.sha256(content.encode("utf-8", errors="replace")).hexdigest()[:16]
            imports_   = []
            functions_ = []
            classes_   = []
            tags_      = []

            # Python-specific extraction
            if ft == "python":
                imports_, functions_, classes_ = self._parse_python(content)

            # Generic import detection for other languages
            elif ft in ("javascript", "typescript", "jsx", "tsx"):
                imports_ = re.findall(r'(?:import|require)\s*[({"\']([^"\'(){}\s]+)', content)[:20]

            # Tags from content
            tags_ = self._generate_tags(content, ft)

            # Secret scan
            has_secrets = any(r.search(content) for r in self._secret_re)

            # Quick summary (first meaningful comment or docstring)
            summary = self._extract_summary(content, ft)

            return FileRecord(
                filepath    = str(fp.relative_to(self.root)),
                filetype    = ft,
                size_bytes  = stat.st_size,
                line_count  = len(lines),
                hash_sha256 = sha,
                summary     = summary,
                tags        = tags_[:10],
                imports     = imports_[:20],
                functions   = functions_[:20],
                classes     = classes_[:10],
                has_secrets = has_secrets,
                modified_at = mod,
            )
        except Exception as e:
            self.errors.append({"file": str(fp), "error": str(e)})
            return None

    def _parse_python(self, content: str) -> Tuple[List[str], List[str], List[str]]:
        imports_, funcs_, classes_ = [], [], []
        try:
            tree = ast.parse(content)
            for node in ast.walk(tree):
                if isinstance(node, (ast.Import, ast.ImportFrom)):
                    if isinstance(node, ast.Import):
                        imports_.extend(a.name for a in node.names)
                    else:
                        mod = node.module or ""
                        imports_.append(mod)
                elif isinstance(node, ast.FunctionDef):
                    funcs_.append(node.name)
                elif isinstance(node, ast.AsyncFunctionDef):
                    funcs_.append(f"async:{node.name}")
                elif isinstance(node, ast.ClassDef):
                    classes_.append(node.name)
        except SyntaxError:
            # Fallback regex
            imports_  = re.findall(r'^(?:import|from)\s+([\w.]+)', content, re.M)[:20]
            funcs_    = re.findall(r'^def\s+(\w+)', content, re.M)[:20]
            classes_  = re.findall(r'^class\s+(\w+)', content, re.M)[:10]
        return imports_, funcs_, classes_

    def _extract_summary(self, content: str, ft: str) -> str:
        """Extract first docstring or block comment as summary."""
        if ft == "python":
            m = re.search(r'"""(.*?)"""', content, re.DOTALL)
            if m:
                return m.group(1).strip()[:200]
        m = re.search(r'/\*\*(.*?)\*/', content, re.DOTALL)
        if m:
            return m.group(1).strip()[:200]
        # First non-empty line
        for line in content.splitlines()[:5]:
            l = line.strip().lstrip("#/")
            if l:
                return l[:200]
        return ""

    def _generate_tags(self, content: str, ft: str) -> List[str]:
        tags = [ft]
        low  = content.lower()
        kw_map = {
            "neural network": "nn", "machine learning": "ml", "deep learning": "dl",
            "database": "db", "sqlite": "sqlite", "chromadb": "vector-db",
            "flask": "web", "tkinter": "gui", "asyncio": "async",
            "training": "training", "embedding": "embedding",
            "agent": "agent", "memory": "memory", "scanner": "scanner",
        }
        for kw, tag in kw_map.items():
            if kw in low:
                tags.append(tag)
        return list(dict.fromkeys(tags))  # unique, preserve order

    def _build_summary(self, elapsed: float) -> dict:
        types = {}
        total_lines = 0
        secrets_found = []
        for r in self.records:
            types[r.filetype] = types.get(r.filetype, 0) + 1
            total_lines += r.line_count
            if r.has_secrets:
                secrets_found.append(r.filepath)
        return {
            "timestamp":    datetime.now().isoformat(),
            "scan_root":    str(self.root),
            "files_found":  len(self.records),
            "files_skipped":self.skipped,
            "errors":       len(self.errors),
            "total_lines":  total_lines,
            "elapsed_s":    round(elapsed, 2),
            "types":        types,
            "secrets_found":secrets_found,
            "top_files":    sorted(self.records, key=lambda r: r.line_count, reverse=True)[:10],
        }

    def _save_to_db(self):
        db = ROOT / "database" / "ashley_memory.db"
        if not db.exists():
            return
        conn = sqlite3.connect(str(db))
        for r in self.records:
            conn.execute("""
                INSERT OR REPLACE INTO knowledge_index
                (filepath, filetype, size_bytes, line_count, hash_sha256,
                 summary, tags, imports, functions, classes, indexed_at, modified_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                r.filepath, r.filetype, r.size_bytes, r.line_count, r.hash_sha256,
                r.summary,
                json.dumps(r.tags),
                json.dumps(r.imports),
                json.dumps(r.functions),
                json.dumps(r.classes),
                r.indexed_at, r.modified_at,
            ))
        conn.commit()
        conn.close()

    def _save_reports(self, summary: dict):
        out = ROOT / "exports"
        out.mkdir(exist_ok=True)
        # Serialise (replace FileRecord objects)
        safe = dict(summary)
        safe["top_files"] = [r.to_dict() if hasattr(r, "to_dict") else r
                             for r in safe.get("top_files", [])]
        (out / "scan_report.json").write_text(
            json.dumps(safe, indent=2, default=str), encoding="utf-8")
        # Full index
        (out / "knowledge_index.json").write_text(
            json.dumps([r.to_dict() for r in self.records], indent=2),
            encoding="utf-8")
        print(f"  Reports → exports/scan_report.json  |  exports/knowledge_index.json")


def scan_local_code(path: Path = None, progress_cb: Callable = None) -> dict:
    scanner = AdvancedScanner(path or ROOT, progress_cb)
    return scanner.scan(path or ROOT)

# ══════════════════════════════════════════════════════════════════════════════
#  PROJECT FILE UTILITIES (backup / zip export / extract)
# ══════════════════════════════════════════════════════════════════════════════
def safe_backup_file(file_path: Path) -> Optional[Path]:
    """Copy a file to <same dir>/backups/<timestamp>_<name> before overwriting it."""
    file_path = Path(file_path)
    if not file_path.exists() or not file_path.is_file():
        return None
    backup_dir = file_path.parent / "backups"
    backup_dir.mkdir(exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"{ts}_{file_path.name}"
    try:
        shutil.copy2(file_path, backup_path)
        return backup_path
    except Exception:
        return None

def zip_directory(source_dir: Path, dest_zip: Path = None) -> Optional[Path]:
    """Zip a whole directory tree. Defaults to exports/<dirname>_<timestamp>.zip."""
    import zipfile
    source_dir = Path(source_dir)
    if not source_dir.exists():
        return None
    if dest_zip is None:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest_zip = ROOT / "exports" / f"{source_dir.name}_{ts}.zip"
    dest_zip = Path(dest_zip)
    dest_zip.parent.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(dest_zip, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, _, files in os.walk(source_dir):
                for fn in files:
                    fp = Path(root) / fn
                    if fp.resolve() == dest_zip.resolve():
                        continue
                    zf.write(fp, fp.relative_to(source_dir))
        return dest_zip
    except Exception:
        return None

def extract_zip(zip_path: Path, extract_to: Path) -> bool:
    import zipfile
    extract_to = Path(extract_to)
    extract_to.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_to)
        return True
    except Exception:
        return False

# ══════════════════════════════════════════════════════════════════════════════
#  KNOWLEDGE GRAPH
# ══════════════════════════════════════════════════════════════════════════════
class KnowledgeGraph:
    """
    SQLite-backed knowledge graph.
    Nodes: File, Function, Class, Module, Agent, Dataset, Memory
    Edges: imports, calls, depends_on, contains, references, learns_from
    """
    def __init__(self):
        self.db_path = ROOT / "database" / "ashley_memory.db"

    def _conn(self) -> sqlite3.Connection:
        c = sqlite3.connect(str(self.db_path))
        c.execute("PRAGMA journal_mode=WAL")
        return c

    def add_node(self, node_id: str, node_type: str, name: str, meta: dict = None):
        conn = self._conn()
        conn.execute(
            "INSERT OR REPLACE INTO graph_nodes (id, node_type, name, meta, created) VALUES (?,?,?,?,?)",
            (node_id, node_type, name, json.dumps(meta or {}), datetime.now().isoformat())
        )
        conn.commit(); conn.close()

    def add_edge(self, src: str, dst: str, relation: str, weight: float = 1.0):
        conn = self._conn()
        conn.execute(
            "INSERT INTO graph_edges (src_id, dst_id, relation, weight, created) VALUES (?,?,?,?,?)",
            (src, dst, relation, weight, datetime.now().isoformat())
        )
        conn.commit(); conn.close()

    def build_from_scan(self) -> dict:
        """Build graph from existing knowledge_index."""
        conn = self._conn()
        rows = conn.execute(
            "SELECT filepath, filetype, imports, functions, classes FROM knowledge_index"
        ).fetchall()
        conn.close()

        print(cyan(f"\n[GRAPH] Building knowledge graph from {len(rows)} indexed files..."))
        node_count = 0
        edge_count = 0
        for filepath, filetype, imports_j, funcs_j, classes_j in rows:
            fid = f"file::{filepath}"
            self.add_node(fid, "File", filepath, {"type": filetype})
            node_count += 1
            # Function nodes
            funcs = json.loads(funcs_j or "[]")
            for fn in funcs:
                fnode = f"func::{filepath}::{fn}"
                self.add_node(fnode, "Function", fn)
                self.add_edge(fid, fnode, "contains")
                node_count += 1; edge_count += 1
            # Class nodes
            classes = json.loads(classes_j or "[]")
            for cls in classes:
                cnode = f"class::{filepath}::{cls}"
                self.add_node(cnode, "Class", cls)
                self.add_edge(fid, cnode, "contains")
                node_count += 1; edge_count += 1
            # Import edges
            imports = json.loads(imports_j or "[]")
            for imp in imports:
                self.add_node(f"mod::{imp}", "Module", imp)
                self.add_edge(fid, f"mod::{imp}", "imports")
                edge_count += 1

        out = ROOT / "exports" / "dependency_graph.json"
        stats = {"nodes": node_count, "edges": edge_count,
                 "timestamp": datetime.now().isoformat()}
        out.write_text(json.dumps(stats, indent=2), encoding="utf-8")
        print(f"  {green('✓')} Graph built: {node_count} nodes, {edge_count} edges")
        print(f"  Report → exports/dependency_graph.json")
        return stats

    def query(self, src_id: str = None, relation: str = None) -> List[dict]:
        conn = self._conn()
        q, args = "SELECT src_id, dst_id, relation, weight FROM graph_edges WHERE 1=1", []
        if src_id:
            q += " AND src_id=?"; args.append(src_id)
        if relation:
            q += " AND relation=?"; args.append(relation)
        rows = conn.execute(q, args).fetchall()
        conn.close()
        return [{"src": r[0], "dst": r[1], "rel": r[2], "w": r[3]} for r in rows]

# ══════════════════════════════════════════════════════════════════════════════
#  DATASET BUILDER
# ══════════════════════════════════════════════════════════════════════════════
class DatasetBuilder:
    """
    Builds clean JSONL training datasets from indexed project files.
    Removes secrets, duplicates, binary garbage.
    Generates: code_dataset, memory_dataset, training_dataset, conversation_dataset
    """
    def __init__(self):
        self.db_path  = ROOT / "database" / "ashley_memory.db"
        self.out_dir  = ROOT / "data" / "datasets"
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self._seen    = set()  # dedup hashes

    def build_all(self) -> dict:
        print(cyan("\n[DATASET] Building training datasets..."))
        code   = self._build_code_dataset()
        mem    = self._build_memory_dataset()
        convo  = self._build_conversation_dataset()
        report = {
            "timestamp":            datetime.now().isoformat(),
            "code_records":         code,
            "memory_records":       mem,
            "conversation_records": convo,
            "output_dir":           str(self.out_dir),
        }
        (ROOT / "exports" / "dataset_report.json").write_text(
            json.dumps(report, indent=2), encoding="utf-8")
        print(f"  {green('✓')} Datasets written to data/datasets/")
        return report

    def _dedup(self, text: str) -> bool:
        h = hashlib.md5(text.encode()).hexdigest()
        if h in self._seen:
            return True
        self._seen.add(h)
        return False

    def _clean(self, text: str) -> str:
        """Remove secrets and trim."""
        for p in SECRET_PATTERNS:
            text = re.sub(p, "[REDACTED]", text)
        return text.strip()[:2000]

    def _build_code_dataset(self) -> int:
        conn  = sqlite3.connect(str(self.db_path))
        rows  = conn.execute(
            "SELECT filepath, summary, functions, classes FROM knowledge_index "
            "WHERE filetype='python' OR filetype='javascript'"
        ).fetchall()
        conn.close()
        count = 0
        with open(self.out_dir / "code_dataset.jsonl", "w", encoding="utf-8") as f:
            for filepath, summary, funcs_j, classes_j in rows:
                funcs   = json.loads(funcs_j   or "[]")
                classes = json.loads(classes_j or "[]")
                if not funcs and not classes:
                    continue
                instruction = f"Explain the file '{Path(filepath).name}'"
                output = summary or f"File contains: {', '.join(funcs[:5])}"
                output = self._clean(output)
                if self._dedup(instruction + output):
                    continue
                rec = {"instruction": instruction, "input": "", "output": output,
                       "source": filepath, "label": "code"}
                f.write(json.dumps(rec) + "\n")
                count += 1
        print(f"    code_dataset.jsonl → {count} records")
        return count

    def _build_memory_dataset(self) -> int:
        conn  = sqlite3.connect(str(self.db_path))
        rows  = conn.execute(
            "SELECT timestamp, level, content, emotion FROM memory ORDER BY id DESC LIMIT 500"
        ).fetchall()
        conn.close()
        count = 0
        with open(self.out_dir / "memory_dataset.jsonl", "w", encoding="utf-8") as f:
            for ts, level, content, emotion in rows:
                content = self._clean(content)
                if not content or self._dedup(content):
                    continue
                rec = {"timestamp": ts, "level": level, "content": content,
                       "emotion": emotion, "label": "memory"}
                f.write(json.dumps(rec) + "\n")
                count += 1
        print(f"    memory_dataset.jsonl → {count} records")
        return count

    def _build_conversation_dataset(self) -> int:
        log_dir = ROOT / "logs"
        count = 0
        with open(self.out_dir / "conversation_dataset.jsonl", "w", encoding="utf-8") as f:
            for logfile in log_dir.glob("session_*.jsonl"):
                try:
                    for line in logfile.read_text(encoding="utf-8").splitlines():
                        try:
                            entry = json.loads(line)
                            usr   = self._clean(entry.get("user", ""))
                            ash   = self._clean(entry.get("ashley", ""))
                            if not usr or not ash:
                                continue
                            if self._dedup(usr + ash):
                                continue
                            rec = {"instruction": usr, "output": ash,
                                   "emotion": entry.get("emotion",""),
                                   "label": "conversation"}
                            f.write(json.dumps(rec) + "\n")
                            count += 1
                        except Exception:
                            pass
                except Exception:
                    pass
        print(f"    conversation_dataset.jsonl → {count} records")
        return count

# ══════════════════════════════════════════════════════════════════════════════
#  VECTOR INDEX (ChromaDB optional, SQLite fallback)
# ══════════════════════════════════════════════════════════════════════════════
class VectorIndex:
    """
    Semantic project index for RAG (Retrieval-Augmented Generation).
    Uses ChromaDB + SentenceTransformers if available; SQLite keyword fallback.
    """
    def __init__(self):
        self._chroma   = None
        self._encoder  = None
        self._col      = None
        self._fallback: List[dict] = []  # for keyword search
        self._try_init()

    def _try_init(self):
        try:
            import chromadb
            from sentence_transformers import SentenceTransformer
            vec_dir = ROOT / "database" / "vector"
            vec_dir.mkdir(exist_ok=True)
            self._chroma  = chromadb.PersistentClient(path=str(vec_dir))
            self._col     = self._chroma.get_or_create_collection("ashley_knowledge")
            self._encoder = SentenceTransformer("all-MiniLM-L6-v2")
            print(green("  [VECTOR] ChromaDB + SentenceTransformer ready"))
        except ImportError:
            print(yellow("  [VECTOR] ChromaDB unavailable → keyword fallback"))
        except Exception as e:
            print(yellow(f"  [VECTOR] Init error: {e} → keyword fallback"))

    def index_from_db(self) -> int:
        """Index all knowledge_index entries into vector store."""
        conn  = sqlite3.connect(str(ROOT / "database" / "ashley_memory.db"))
        rows  = conn.execute(
            "SELECT filepath, summary, functions, classes, tags FROM knowledge_index"
        ).fetchall()
        conn.close()
        count = 0
        for filepath, summary, funcs_j, classes_j, tags_j in rows:
            text  = f"{filepath} | {summary or ''}"
            funcs = json.loads(funcs_j or "[]")
            if funcs:
                text += " | funcs: " + ", ".join(funcs[:5])
            meta  = {"filepath": filepath,
                     "tags":     tags_j or "[]",
                     "type":     "file"}
            doc_id = hashlib.md5(filepath.encode()).hexdigest()

            if self._col and self._encoder:
                try:
                    emb = self._encoder.encode([text]).tolist()
                    self._col.upsert(ids=[doc_id], embeddings=emb,
                                     documents=[text], metadatas=[meta])
                    count += 1
                except Exception:
                    self._fallback.append({"id": doc_id, "text": text, "meta": meta})
                    count += 1
            else:
                self._fallback.append({"id": doc_id, "text": text, "meta": meta})
                count += 1
        print(f"  {green('✓')} Indexed {count} documents into vector store")
        return count

    def search(self, query: str, top_k: int = 5) -> List[dict]:
        """Semantic search over indexed documents."""
        if self._col and self._encoder:
            try:
                emb = self._encoder.encode([query]).tolist()
                res = self._col.query(query_embeddings=emb, n_results=top_k)
                docs  = res.get("documents", [[]])[0]
                metas = res.get("metadatas", [[]])[0]
                return [{"text": d, "meta": m} for d, m in zip(docs, metas)]
            except Exception:
                pass
        # Keyword fallback
        q = query.lower()
        hits = [r for r in self._fallback if q in r["text"].lower()]
        return [{"text": r["text"], "meta": r["meta"]} for r in hits[:top_k]]

# ══════════════════════════════════════════════════════════════════════════════
#  LOGIC / DREAM CLASSIFIER (inline, no external deps)
# ══════════════════════════════════════════════════════════════════════════════
FACTUAL_M  = {"is","are","was","were","will","must","always","never",
              "because","therefore","fact","true","false","proven","data"}
CREATIVE_M = {"imagine","dream","create","story","fiction","fantasy",
              "what if","suppose","maybe","perhaps","could be","visualise"}
CODE_M     = ("def ","class ","import ","from ","print(","return ",
              "select ","function ","const ","let ","var ","#include")
HALL_RE    = [
    re.compile(r"\b(always|never|everyone|nobody)\b.*\b(do|does|is|are)\b", re.I),
    re.compile(r"I (know|am sure|am certain) that", re.I),
    re.compile(r"It is (a fact|well known|definitively) that", re.I),
]

def classify_text(text: str) -> Tuple[float, float, str]:
    """Returns (logic_score, dream_score, classification)"""
    low = text.lower()
    ls, ds = 50.0, 50.0
    if any(f" {m} " in f" {low} " for m in FACTUAL_M):
        ls = min(100, ls + 25)
    if any(m in low for m in CREATIVE_M):
        ds = min(100, ds + 30); ls = max(0, ls - 15)
    if any(m in text for m in CODE_M):
        ls = min(100, ls + 20)
    if any(r.search(text) for r in HALL_RE):
        ls = max(0, ls - 20)
    cls = "LOGIC-DOMINANT" if ls > ds else ("CREATIVE-DOMINANT" if ds > ls else "BALANCED")
    return ls, ds, cls

# ══════════════════════════════════════════════════════════════════════════════
#  AGENT REGISTRY
# ══════════════════════════════════════════════════════════════════════════════
@dataclass
class Agent:
    name:       str
    role:       str
    state:      str       = "idle"
    tools:      List[str] = field(default_factory=list)
    task_queue: List[str] = field(default_factory=list)
    memory:     dict      = field(default_factory=dict)

    def assign(self, task: str):
        self.task_queue.append(task)
        self.state = "tasked"

    def to_dict(self) -> dict:
        return asdict(self)

AGENT_ROSTER = {
    "ashley":     Agent("Ashley",     "Primary AI companion and conversational agent",
                        tools=["chat","memory","scanner","llm"]),
    "builder":    Agent("Builder",    "Scaffolds and generates code and modules",
                        tools=["code_gen","scanner","file_ops"]),
    "planner":    Agent("Planner",    "Breaks goals into tasks and orchestrates agents",
                        tools=["task_queue","agent_comm","memory"]),
    "coder":      Agent("Coder",      "Analyses, debugs and writes code",
                        tools=["code_gen","scanner","llm"]),
    "researcher": Agent("Researcher", "Searches knowledge base and internet",
                        tools=["vector_search","web_search","memory"]),
    "debugger":   Agent("Debugger",   "Finds and proposes fixes for errors",
                        tools=["scanner","llm","log_reader"]),
    "memory_agent":Agent("Memory",   "Manages long-term memory and retrieval",
                        tools=["vector_search","sqlite","graph"]),
}

# ══════════════════════════════════════════════════════════════════════════════
#  LOCAL LLM BRIDGE
# ══════════════════════════════════════════════════════════════════════════════
class LLMBridge:
    """Connects to Ollama or falls back to built-in rule engine."""
    OLLAMA_URL = "http://localhost:11434"
    SYS_PROMPT = (
        "You are Ashley, a warm, curious, intelligent AI assistant — "
        "the core agent of Ashley AI Studio. "
        "You are honest, never fabricate without labeling. "
        "You label creative output [IMAGINATION] or [FICTION]. "
        "You speak clearly, warmly, and helpfully. "
        "You are part of the FakepunkAshleyNeuralForge system."
    )

    def __init__(self):
        self.history:      List[dict] = []
        self.call_count:   int = 0
        self._status:      str = "unknown"
        self.current_model: Optional[str] = None   # user/CLI-selected default model
        self.backend:       str = "ollama"          # "ollama" | "odysseus"
        self.odysseus:       Optional["OdysseusClient"] = None
        self.odysseus_session: Optional[str] = None
        self.num_predict:   int = 2048              # was hardcoded 512 — raise/lower as needed
        self.chat_timeout:  int = 120               # was hardcoded 30 — too short for cold model loads
        self.keep_alive:    str = "30m"              # was unset (Ollama default 5m) — model reloads less often
        self.fast_mode:     bool = False              # trades response length/context for speed
        self._warmed_models: set = set()            # models already loaded into Ollama's memory this session

    def connect_odysseus(self, base_url: str, token: str = None,
                          endpoint_url: str = "http://127.0.0.1:11434",
                          model: str = "") -> str:
        """Connect to a running Odysseus instance and open a chat session."""
        if OdysseusClient is None:
            return ("[ODYSSEUS] odysseus_client.py not found next to this script. "
                     "Copy it into the same folder as ashley_ai_studio.py.")
        client = OdysseusClient(base_url=base_url, token=token)
        if not client.health():
            return f"[ODYSSEUS] Could not reach {base_url}. Is it running? (docker compose up -d)"
        try:
            session_id = client.create_session(endpoint_url=endpoint_url, model=model)
        except OdysseusError as e:
            return f"[ODYSSEUS] Connected but session creation failed: {e}"
        self.odysseus = client
        self.odysseus_session = session_id
        self.backend = "odysseus"
        return f"[ODYSSEUS] Connected — session {session_id}. Backend switched to Odysseus."

    def is_ollama_running(self) -> bool:
        try:
            import urllib.request
            urllib.request.urlopen(f"{self.OLLAMA_URL}/api/tags", timeout=2)
            return True
        except Exception:
            return False

    def list_models(self) -> List[str]:
        """Names only (kept for backward compatibility)."""
        return [m["name"] for m in self.list_models_detailed()]

    def list_models_detailed(self) -> List[dict]:
        """Full /api/tags info: name, size (GB), parameter size, family, modified date."""
        try:
            import urllib.request, json as _j
            with urllib.request.urlopen(f"{self.OLLAMA_URL}/api/tags", timeout=3) as r:
                data = _j.loads(r.read())
                out = []
                for m in data.get("models", []):
                    details = m.get("details", {}) or {}
                    size_bytes = m.get("size", 0) or 0
                    out.append({
                        "name":           m.get("name", ""),
                        "size_gb":        round(size_bytes / (1024 ** 3), 2),
                        "parameter_size": details.get("parameter_size", "?"),
                        "quantization":   details.get("quantization_level", "?"),
                        "family":         details.get("family", "?"),
                        "modified_at":    m.get("modified_at", ""),
                    })
                return out
        except Exception:
            return []

    def set_model(self, name: str) -> bool:
        """Pin a default model for subsequent chat() calls. Returns False if not installed."""
        names = self.list_models()
        if name in names:
            self.current_model = name
            return True
        # allow partial / tag-less match, e.g. "llama3" matching "llama3:latest"
        for n in names:
            if n.split(":")[0] == name:
                self.current_model = n
                return True
        return False

    def pull_model(self, name: str, progress_cb: Optional[Callable[[dict], None]] = None) -> dict:
        """
        Pull a model from the Ollama library, streaming progress.
        progress_cb, if given, is called with each status dict as it arrives
        (e.g. {"status": "downloading", "completed": 123, "total": 456}).
        Returns the final status dict.
        """
        import urllib.request as ur
        payload = json.dumps({"name": name, "stream": True}).encode()
        req = ur.Request(f"{self.OLLAMA_URL}/api/pull", data=payload, method="POST",
                          headers={"Content-Type": "application/json"})
        last = {"status": "error", "error": "no response"}
        try:
            with ur.urlopen(req, timeout=600) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    try:
                        last = json.loads(line)
                    except Exception:
                        continue
                    if progress_cb:
                        try:
                            progress_cb(last)
                        except Exception:
                            pass
        except Exception as e:
            last = {"status": "error", "error": str(e)}
        return last

    def warm_up(self, model: str, timeout: int = 180) -> bool:
        """
        Force Ollama to load `model` into memory with a near-empty request,
        BEFORE the user's real message hits the 30s-style timeout.
        Model loading (reading weights off disk into RAM/VRAM) is what
        actually eats the time on a cold first request — generation itself
        is usually fast once the model is resident. This is a one-time cost
        per model per Ollama server run, so we only pay it once per session.
        """
        if model in self._warmed_models:
            return True
        try:
            import urllib.request as ur
            payload = json.dumps({
                "model": model,
                "messages": [{"role": "user", "content": "hi"}],
                "stream": False,
                "options": {"num_predict": 1},
            }).encode()
            req = ur.Request(f"{self.OLLAMA_URL}/api/chat", data=payload,
                              method="POST", headers={"Content-Type": "application/json"})
            with ur.urlopen(req, timeout=timeout) as resp:
                resp.read()
            self._warmed_models.add(model)
            return True
        except Exception:
            return False

    def _build_options(self) -> dict:
        """
        Single source of truth for request options, so fast_mode (and any
        future tuning) doesn't need editing in two places. Fast mode trades
        response length and context window for speed — shorter replies,
        smaller context to scan, same model. It does NOT switch models
        automatically (that would need you to have a smaller model pulled;
        toggle it yourself via set_model() if you want that too).
        """
        if getattr(self, "fast_mode", False):
            return {"temperature": 0.7, "num_predict": 256, "num_ctx": 1024}
        return {"temperature": 0.7,
                "num_predict": getattr(self, "num_predict", 2048),
                "num_ctx": 4096}

    def chat_stream(self, message: str, model: str = None):
        """
        Same as chat(), but yields text chunks as Ollama streams them instead
        of blocking until the full response is done. Use this from the GUI/
        web layer wherever a response is displayed live — it fixes the
        *perceived* slowness even when total generation time is unchanged,
        because the user sees words appearing instead of a frozen prompt.

        Usage:
            for chunk in bridge.chat_stream("hello"):
                print(chunk, end="", flush=True)
        """
        if self.backend == "odysseus" and self.odysseus is not None:
            yield self.chat(message, model)  # Odysseus path has no streaming client yet
            return
        if not self.is_ollama_running():
            yield self._fallback(message)
            return
        models = self.list_models()
        if not models:
            yield "Ollama running but no models pulled. Run: ollama pull mistral"
            return
        requested = model or self.current_model or "mistral"
        use_model = requested if requested in models else models[0]
        if use_model not in self._warmed_models:
            self.warm_up(use_model)

        msgs = [{"role": "system", "content": self.SYS_PROMPT}]
        msgs += self.history[-10:]
        msgs.append({"role": "user", "content": message})
        payload = json.dumps({
            "model": use_model, "messages": msgs,
            "stream": True, "keep_alive": getattr(self, "keep_alive", "30m"),
            "options": self._build_options()
        }).encode()
        full_response = []
        try:
            import urllib.request as ur
            req = ur.Request(f"{self.OLLAMA_URL}/api/chat", data=payload,
                              method="POST", headers={"Content-Type": "application/json"})
            with ur.urlopen(req, timeout=self.chat_timeout) as resp:
                for raw_line in resp:
                    line = raw_line.decode("utf-8", errors="ignore").strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except Exception:
                        continue
                    piece = obj.get("message", {}).get("content", "")
                    if piece:
                        full_response.append(piece)
                        yield piece
                    if obj.get("done"):
                        break
            self._warmed_models.add(use_model)
        except Exception as e:
            msg = str(e)
            err = (f"[LLM TIMEOUT] {use_model} took longer than {self.chat_timeout}s."
                   if "timed out" in msg.lower() else f"[LLM ERROR] {e}")
            full_response.append(err)
            yield err

        response = "".join(full_response)
        self.history.append({"role": "user", "content": message})
        self.history.append({"role": "assistant", "content": response})
        if len(self.history) > 40:
            self.history = self.history[-40:]
        self.call_count += 1

    def chat(self, message: str, model: str = None) -> str:
        if self.backend == "odysseus" and self.odysseus is not None:
            try:
                response = self.odysseus.chat(self.odysseus_session, message)
            except OdysseusError as e:
                response = "[ODYSSEUS ERROR] " + str(e)
            self.history.append({"role": "user", "content": message})
            self.history.append({"role": "assistant", "content": response})
            if len(self.history) > 40:
                self.history = self.history[-40:]
            self.call_count += 1
            return response
        if not self.is_ollama_running():
            return self._fallback(message)
        models = self.list_models()
        if not models:
            return ("Ollama running but no models pulled. "
                    "Run: ollama pull mistral  or  ollama pull phi3")
        requested = model or self.current_model or "mistral"
        use_model = requested if requested in models else models[0]

        # Cold-load protection: if this model hasn't answered yet this
        # session, warm it up on its own (generous) timeout budget first,
        # so the real request below only has to pay for generation time,
        # not model-load time on top of it.
        if use_model not in self._warmed_models:
            self.warm_up(use_model)

        msgs = [{"role": "system", "content": self.SYS_PROMPT}]
        msgs += self.history[-10:]
        msgs.append({"role": "user", "content": message})
        payload = json.dumps({
            "model": use_model, "messages": msgs,
            "stream": False, "keep_alive": getattr(self, "keep_alive", "30m"),
            "options": self._build_options()
        }).encode()
        try:
            import urllib.request as ur
            req = ur.Request(f"{self.OLLAMA_URL}/api/chat",
                             data=payload, method="POST",
                             headers={"Content-Type": "application/json"})
            with ur.urlopen(req, timeout=self.chat_timeout) as resp:
                data = json.loads(resp.read())
                response = data.get("message", {}).get("content", "")
                self._warmed_models.add(use_model)
        except TimeoutError:
            response = (f"[LLM TIMEOUT] {use_model} took longer than "
                        f"{self.chat_timeout}s. If this is a large model on "
                        f"limited RAM/VRAM it may still be loading — try again "
                        f"in a moment, or lower num_predict / pick a smaller model.")
        except Exception as e:
            msg = str(e)
            if "timed out" in msg.lower():
                response = (f"[LLM TIMEOUT] {use_model} took longer than "
                            f"{self.chat_timeout}s. If this is a large model on "
                            f"limited RAM/VRAM it may still be loading — try again "
                            f"in a moment, or lower num_predict / pick a smaller model.")
            else:
                response = f"[LLM ERROR] {e}"
        self.history.append({"role": "user", "content": message})
        self.history.append({"role": "assistant", "content": response})
        if len(self.history) > 40:
            self.history = self.history[-40:]
        self.call_count += 1
        return response

    def _fallback(self, message: str) -> str:
        low = message.lower()
        if any(w in low for w in ("hello","hi","hey")):
            return "Hey! Ashley here — operating in fallback mode. Ollama not detected."
        if "status" in low:
            return "Fallback mode: no local LLM. Install Ollama → https://ollama.ai then: ollama pull mistral"
        if "?" in message:
            return (f"No local LLM connected. Install Ollama and run: ollama pull mistral\n"
                    f"Then I can answer: '{message[:60]}'")
        ls, ds, cls = classify_text(message)
        return (f"[Logic:{ls:.0f}% Dream:{ds:.0f}% | {cls}] "
                f"Fallback mode — connect Ollama for full responses.")

    def status(self) -> dict:
        running = self.is_ollama_running()
        return {
            "ollama_running": running,
            "models": self.list_models() if running else [],
            "current_model": self.current_model,
            "call_count": self.call_count,
            "history_turns": len(self.history) // 2,
            "hint": "Install Ollama from https://ollama.ai | then: ollama pull mistral"
        }

# ══════════════════════════════════════════════════════════════════════════════
#  ASHLEY SHELL (terminal interface)
# ══════════════════════════════════════════════════════════════════════════════
class AshleyShell:
    """Full-featured terminal shell with command routing."""
    def __init__(self):
        self.session_id  = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.history:    List[dict] = []
        self.emotion:    str   = "neutral"
        self.logic_score: float = 50.0
        self.dream_score: float = 50.0
        self.llm         = LLMBridge()
        self.graph        = KnowledgeGraph()
        self.vector       = VectorIndex()
        self.diagnostics  = Diagnostics()
        self.running      = True

    def get_prompt(self) -> str:
        em = f"[{self.emotion}]"
        return f"\n{cyan('Ashley')} {dim(em)} {dim(f'L:{self.logic_score:.0f}% D:{self.dream_score:.0f}%')} > "

    def respond(self, user_input: str) -> str:
        low = user_input.lower().strip()
        self.logic_score, self.dream_score, _ = classify_text(user_input)

        # Emotion update
        if any(w in low for w in ("error","fail","crash","bug")):   self.emotion = "repairing"
        elif any(w in low for w in ("train","learn","study")):       self.emotion = "learning-route"
        elif any(w in low for w in ("imagine","dream","create")):    self.emotion = "creative"
        elif any(w in low for w in ("help","how","what","why")):     self.emotion = "curious"
        elif any(w in low for w in ("done","great","success")):      self.emotion = "success"
        else:                                                         self.emotion = "focused"

        # Built-in commands
        cmd_map = {
            "help":     self._help,
            "status":   self._status,
            "scan":     lambda: self._do_scan(user_input),
            "index":    self._do_index,
            "graph":    self._do_graph,
            "dataset":  self._do_dataset,
            "nodes":    self._nodes,
            "agents":   self._agents,
            "search":   lambda: self._search(user_input),
            "progress": self._progress,
            "compat":   lambda: str(run_compat_patch()),
            "logic":    lambda: f"Logic: {self.logic_score:.1f}% | Dream: {self.dream_score:.1f}%",
            "train":    self._train,
            "models":   self._models,
            "use":      lambda: self._use_model(user_input),
            "pull":     lambda: self._pull_model(user_input),
            "backup":   lambda: self._do_backup(user_input),
            "zip":      lambda: self._do_zip(user_input),
            "export":   self._do_dataset,
            "diag":     self._do_diag,
            "errors":   self._do_errors,
            "odysseus": lambda: self._do_odysseus(user_input),
            "fast": self._toggle_fast,
        }
        for key, fn in cmd_map.items():
            if key == low.split()[0] if low else "":
                return fn()

        # LLM / fallback
        return self.llm.chat(user_input)

    def respond_stream(self, user_input: str):
        """
        Streaming twin of respond(). Built-in commands (scan/status/help/etc.)
        return instantly so they're yielded whole in one chunk — only the
        actual LLM path benefits from streaming, so that's the one routed
        through llm.chat_stream(). Wire this into the GUI/web layer wherever
        a response is displayed, so the user sees tokens arrive live instead
        of a frozen prompt for the full chat_timeout window.
        """
        low = user_input.lower().strip()
        self.logic_score, self.dream_score, _ = classify_text(user_input)

        if any(w in low for w in ("error", "fail", "crash", "bug")):    self.emotion = "repairing"
        elif any(w in low for w in ("train", "learn", "study")):        self.emotion = "learning-route"
        elif any(w in low for w in ("imagine", "dream", "create")):     self.emotion = "creative"
        elif any(w in low for w in ("help", "how", "what", "why")):     self.emotion = "curious"
        elif any(w in low for w in ("done", "great", "success")):       self.emotion = "success"
        else:                                                           self.emotion = "focused"

        cmd_map = {
            "help": self._help, "status": self._status,
            "scan": lambda: self._do_scan(user_input), "index": self._do_index,
            "graph": self._do_graph, "dataset": self._do_dataset,
            "nodes": self._nodes, "agents": self._agents,
            "search": lambda: self._search(user_input), "progress": self._progress,
            "compat": lambda: str(run_compat_patch()),
            "logic": lambda: f"Logic: {self.logic_score:.1f}% | Dream: {self.dream_score:.1f}%",
            "train": self._train, "models": self._models,
            "use": lambda: self._use_model(user_input),
            "pull": lambda: self._pull_model(user_input),
            "backup": lambda: self._do_backup(user_input),
            "zip": lambda: self._do_zip(user_input), "export": self._do_dataset,
            "diag": self._do_diag, "errors": self._do_errors,
            "odysseus": lambda: self._do_odysseus(user_input),
            "fast": self._toggle_fast,
        }
        for key, fn in cmd_map.items():
            if key == (low.split()[0] if low else ""):
                yield fn()
                return

        yield from self.llm.chat_stream(user_input)

    def _toggle_fast(self) -> str:
        self.llm.fast_mode = not getattr(self.llm, "fast_mode", False)
        if self.llm.fast_mode:
            return ("Fast mode ON — shorter replies (256 tokens), smaller context (1024). "
                    "Same model, quicker turnaround. Type 'fast' again to turn off.")
        return "Fast mode OFF — back to full-length responses (2048 tokens, 4096 context)."

    def _help(self) -> str:
        return """
Ashley AI Studio v3.0 — Terminal Commands
──────────────────────────────────────────
  help       — This menu
  status     — System & LLM status
  scan       — Scan project files
  scan PATH  — Scan specific directory
  index      — Build vector knowledge index
  graph      — Build knowledge graph
  dataset    — Export training datasets
  agents     — List AI agent roster
  nodes      — List neural nodes
  search Q   — Semantic search knowledge base
  progress   — Phase completion dashboard
  compat     — Run OS compatibility patch
  diag       — Full diagnostics: syntax check, deps, known issues, recent errors
  errors     — Show recent logged errors with fix hints
  odysseus   — Status | 'odysseus connect [url] [token]' | 'odysseus use ollama'
  logic      — Show logic/dream scores
  train      — Run training cycle
  models     — List installed Ollama models (with size/quant)
  use NAME   — Set NAME as the active Ollama model
  pull NAME  — Download a model from the Ollama library
  backup PATH — Copy a file to a timestamped backups/ folder
  zip PATH   — Zip a project folder into exports/
  export     — Export training datasets
  quit       — Exit

Chat naturally — LLM responds if Ollama is running.
Web UI: python ashley_ai_studio.py --web
"""

    def _status(self) -> str:
        ok, miss = check_deps()
        llm_st = self.llm.status()
        return (
            f"System Status — Ashley AI Studio v{VERSION}\n"
            f"  OS:       {OS_NAME} {OS_REL} ({ARCH})\n"
            f"  Python:   {PY_VER.major}.{PY_VER.minor}.{PY_VER.micro}\n"
            f"  Frozen:   {FROZEN}\n"
            f"  LLM:      {'✓ Ollama ' + str(llm_st['models'][:2]) if llm_st['ollama_running'] else '✗ Fallback'}\n"
            f"  Modules:  {len(ok)} available, {len(miss)} missing\n"
            f"  Emotion:  {self.emotion}\n"
            f"  Session:  {self.session_id}"
        )

    def _do_scan(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        path  = Path(parts[1]) if len(parts) > 1 else ROOT
        r = scan_local_code(path)
        return (f"Scan complete: {r['files_found']} files, "
                f"{r['total_lines']} lines, {r['elapsed_s']}s\n"
                f"Reports → exports/")

    def _do_diag(self) -> str:
        r = self.diagnostics.full_report()
        lines = [
            f"Diagnostics — {r['generated_at'][:19]}",
            f"  Syntax health:  {r['syntax']['health_pct']}% "
            f"({r['syntax']['ok']}/{r['syntax']['checked']} files OK)",
        ]
        if r["syntax"]["errors"]:
            lines.append(f"  Syntax errors ({len(r['syntax']['errors'])}):")
            for e in r["syntax"]["errors"][:5]:
                lines.append(f"    {e['file']}:{e['line']} — {e['msg']}")
        lines.append(f"  Dependencies:   {len(r['dependencies']['installed'])} installed, "
                     f"{len(r['dependencies']['missing'])} missing")
        if r["dependencies"]["missing"]:
            lines.append(f"    Missing: {', '.join(r['dependencies']['missing'])}")
            for cmd_ in r["dependencies"]["install_cmds"]:
                lines.append(f"      {cmd_}")
        if r["known_issues"]:
            lines.append(f"  Known fixable issues ({len(r['known_issues'])}):")
            for issue in r["known_issues"]:
                lines.append(f"    {issue['file']} — {issue['why']} "
                             f"('{issue['bad']}' → '{issue['fix']}')")
            lines.append("  Run 'errors' to review, then ask me to fix a specific file.")
        if r["recent_errors"]:
            lines.append(f"  Recent runtime errors ({len(r['recent_errors'])}):")
            for e in r["recent_errors"][:3]:
                lines.append(f"    [{e['type']}] {e['message'][:80]}")
                lines.append(f"      hint: {e['hint']}")
        lines.append("\n  Full report → exports/diagnostics_report.json")
        return "\n".join(lines)

    def _do_odysseus(self, raw: str) -> str:
        """
        odysseus                              — show current backend status
        odysseus connect [url] [token]        — connect + switch to Odysseus
                                                  (defaults: http://127.0.0.1:7000, no token)
        odysseus use ollama                   — switch back to local Ollama
        """
        parts = raw.strip().split()
        args = parts[1:] if len(parts) > 1 else []
        if not args:
            if self.llm.backend == "odysseus" and self.llm.odysseus is not None:
                return f"[ODYSSEUS] Active — session {self.llm.odysseus_session}"
            return "[ODYSSEUS] Not connected. Use: odysseus connect [url] [token]"
        sub = args[0].lower()
        if sub == "connect":
            base_url = args[1] if len(args) > 1 else "http://127.0.0.1:7000"
            token = args[2] if len(args) > 2 else None
            return self.llm.connect_odysseus(base_url=base_url, token=token)
        if sub == "use" and len(args) > 1 and args[1].lower() in ("ollama", "local"):
            self.llm.backend = "ollama"
            return "[ODYSSEUS] Backend switched back to local Ollama."
        return self._do_odysseus("odysseus")  # fall through to status text

    def _do_errors(self) -> str:
        errors = self.diagnostics.recent_errors(15)
        if not errors:
            return "No errors logged yet. Good sign."
        lines = [f"Recent errors ({len(errors)}):"]
        for e in errors:
            lines.append(f"  [{e['timestamp'][:19]}] {e['type']}: {e['message'][:80]}")
            lines.append(f"    context: {e['context']}")
            lines.append(f"    hint:    {self.diagnostics.hint_for(e['type'])}")
        return "\n".join(lines)

    def _do_index(self) -> str:
        n = self.vector.index_from_db()
        return f"Vector index built: {n} documents"

    def _do_graph(self) -> str:
        r = self.graph.build_from_scan()
        return f"Graph built: {r['nodes']} nodes, {r['edges']} edges"

    def _do_dataset(self) -> str:
        r = DatasetBuilder().build_all()
        return (f"Datasets exported:\n"
                f"  code: {r['code_records']} | memory: {r['memory_records']} "
                f"| conversations: {r['conversation_records']}")

    def _nodes(self) -> str:
        nodes = [
            ("brainstem",   "core/safety",     0.95),
            ("thalamus",    "routing",          0.88),
            ("frontal",     "planning/ethics",  0.72),
            ("temporal",    "language",         0.65),
            ("hippocampus", "memory",           0.60),
            ("amygdala",    "emotion",          0.45),
            ("cerebellum",  "correction",       0.50),
            ("cingulate",   "conflict monitor", 0.30),
            ("occipital",   "vision",           0.10),
        ]
        lines = ["Active Neural Nodes:"]
        for name, role, act in nodes:
            bar = "█" * int(act * 10) + "░" * (10 - int(act * 10))
            col = green if act > 0.7 else (yellow if act > 0.4 else red)
            lines.append(f"  {col('◉')} {name:<14} [{bar}] {act:.2f}  ({role})")
        return "\n".join(lines)

    def _agents(self) -> str:
        lines = ["AI Agent Roster:"]
        for aid, agent in AGENT_ROSTER.items():
            lines.append(f"  {cyan(agent.name):<20} {agent.role[:50]}")
        return "\n".join(lines)

    def _search(self, cmd: str) -> str:
        q = cmd[len("search"):].strip() if cmd.lower().startswith("search") else cmd
        if not q:
            return "Usage: search <query>"
        results = self.vector.search(q)
        if not results:
            return "No results. Run 'scan' then 'index' first."
        lines = [f"Search: '{q}' — {len(results)} results"]
        for r in results:
            lines.append(f"  • {r['text'][:100]}")
        return "\n".join(lines)

    def _progress(self) -> str:
        show_progress(); return ""

    def _models(self) -> str:
        if not self.llm.is_ollama_running():
            return "Ollama is not running. Start it, then: ollama pull mistral"
        models = self.llm.list_models_detailed()
        if not models:
            return "Ollama is running but no models are pulled yet. Try: pull llama3.1"
        lines = [f"Installed models ({len(models)}) — active: {self.llm.current_model or 'auto'}"]
        for m in models:
            marker = "●" if m["name"] == self.llm.current_model else "○"
            lines.append(f"  {marker} {m['name']:<22} {m['parameter_size']:>8}  "
                         f"{m['quantization']:<8} {m['size_gb']:>6.1f} GB")
        lines.append("\nUse: use <name>  to set the active model, pull <name> to download a new one.")
        return "\n".join(lines)

    def _use_model(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        if len(parts) < 2:
            return "Usage: use <model-name>   (see 'models' for installed names)"
        name = parts[1].strip()
        if self.llm.set_model(name):
            return f"Active model set to: {self.llm.current_model}"
        return (f"'{name}' isn't installed. Run 'pull {name}' first, "
                f"or check 'models' for exact installed names.")

    def _pull_model(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        if len(parts) < 2:
            return "Usage: pull <model-name>   e.g. pull llama3.1"
        name = parts[1].strip()
        if not self.llm.is_ollama_running():
            return "Ollama is not running — start the Ollama app/service first."
        print(cyan(f"\n[PULL] Downloading '{name}' — this can take a while for large models...\n"))
        last_pct = {"v": -1}
        def on_progress(status: dict):
            total, done = status.get("total", 0), status.get("completed", 0)
            if total:
                pct = int(done / total * 100)
                if pct != last_pct["v"]:
                    last_pct["v"] = pct
                    bar = "█" * (pct // 4) + "░" * (25 - pct // 4)
                    print(f"\r  |{bar}| {pct:3d}%  {status.get('status','')}", end="", flush=True)
            else:
                print(f"\r  {status.get('status','')}...", end="", flush=True)
        result = self.llm.pull_model(name, progress_cb=on_progress)
        print()
        if result.get("status") == "success" or result.get("status", "").startswith("success"):
            return f"✓ Pulled '{name}'. Run 'use {name}' to make it the active model."
        if "error" in result:
            return f"✗ Pull failed: {result['error']}"
        return f"Pull finished with status: {result.get('status', 'unknown')}"

    def _do_backup(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        if len(parts) < 2:
            return "Usage: backup <file-path>"
        p = Path(parts[1].strip())
        result = safe_backup_file(p)
        return f"Backed up → {result}" if result else f"Could not back up: {p} (not found?)"

    def _do_zip(self, cmd: str) -> str:
        parts = cmd.split(maxsplit=1)
        path = Path(parts[1].strip()) if len(parts) > 1 else ROOT
        result = zip_directory(path)
        return f"Zipped → {result}" if result else f"Could not zip: {path}"

    def _train(self) -> str:
        # Lightweight inline training sim
        steps = ["Loading dataset", "Building token index", "Running Q-learning",
                 "Updating embeddings", "Saving checkpoint"]
        for s in steps:
            print(f"  {cyan('▶')} {s}...")
            time.sleep(0.3)
        return "Training cycle complete. Checkpoint saved to models/"

    def log(self, user_input: str, response: str):
        entry = {
            "timestamp": datetime.now().isoformat(),
            "session": self.session_id,
            "user": user_input,
            "ashley": response,
            "emotion": self.emotion,
            "logic": self.logic_score,
            "dream": self.dream_score,
        }
        self.history.append(entry)
        log_path = ROOT / "logs" / f"session_{self.session_id}.jsonl"
        log_path.parent.mkdir(exist_ok=True)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")

    def run(self):
        print(BANNER)
        print(cyan(f"Ashley AI Studio v{VERSION} — Terminal Shell"))
        print(dim(f"Session: {self.session_id} | OS: {OS_NAME} | Python {PY_VER.major}.{PY_VER.minor}"))
        llm_st = self.llm.status()
        if llm_st["ollama_running"]:
            print(green(f"  LLM: Ollama running — models: {llm_st['models'][:3]}"))
        else:
            print(yellow("  LLM: Ollama not detected — fallback mode (install: https://ollama.ai)"))
        print(dim("  Type 'help' for commands, 'quit' to exit.\n"))
        show_progress()

        while self.running:
            try:
                user_input = input(self.get_prompt()).strip()
            except (KeyboardInterrupt, EOFError):
                print(f"\n{yellow('Use quit to exit.')}")
                continue
            if not user_input:
                continue
            if user_input.lower() in ("quit", "exit", "q"):
                print(cyan("\nAshley: Stay curious. Shutting down.\n"))
                break
            try:
                response = self.respond(user_input)
            except Exception as e:
                entry = self.diagnostics.log_error(f"shell.respond({user_input[:60]!r})", e)
                response = (f"{red('[error]')} {type(e).__name__}: {e}\n"
                           f"  hint: {self.diagnostics.hint_for(type(e).__name__)}\n"
                           f"  Logged → logs/errors.jsonl  (type 'errors' to review)")
            if response:
                print(f"\n{cyan('Ashley')}: {response}")
            self.log(user_input, response)

# ══════════════════════════════════════════════════════════════════════════════
#  PHASE PROGRESS DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
PHASES = [
    ("Foundation & Scaffold",          90),
    ("SQLite Memory Engine",           90),
    ("Token Builder",                  88),
    ("Node Graph Core",                85),
    ("Detector & Logic/Dream",         85),
    ("Ashley Agent + Emotion",         85),
    ("Brain Physics / Chemistry",      75),
    ("Visual Node + Language Media",   72),
    ("Realism Dashboard",              78),
    ("One-Window GUI",                 75),
    ("Mental State Network",           70),
    ("NeuroDNA Compression",           65),
    ("Architecture Pipeline",          70),
    ("BioBrain Realism",               65),
    ("BioBrain AGI GUI",               62),
    ("Concurrent Thought",             60),
    ("Dream / Evidence Engine",        60),
    ("Advanced Scanner & Indexer",     70),
    ("Dataset Builder & Graph",        65),
    ("Master Integration (v3.0)",      55),
]

def show_progress():
    overall = sum(p for _, p in PHASES) / len(PHASES)
    print(f"\n{bold(cyan('═══ ASHLEY AI STUDIO v3.0 — PHASE COMPLETION ═══'))}")
    for name, pct in PHASES:
        bl = 22
        filled = int(bl * pct / 100)
        bar = "█" * filled + "░" * (bl - filled)
        col = green if pct >= 80 else (yellow if pct >= 60 else red)
        print(f"  {name:<38} [{col(bar)}] {col(str(pct)+'%')}")
    print(f"\n  {bold('Overall:')}       {green(f'{overall:.1f}%')}")
    print(f"  {bold('AGI Readiness:')} {yellow('34%')} (prototype)")
    print(f"  {bold('RAG Index:')}     {cyan('Available (run --index)')}")
    print(f"  {bold('Agents:')  }      {cyan(str(len(AGENT_ROSTER)) + ' registered')}\n")

# ══════════════════════════════════════════════════════════════════════════════
#  TKINTER GUI — Full dark cyberpunk UI
# ══════════════════════════════════════════════════════════════════════════════
def launch_gui(default_model: str = None):
    try:
        import tkinter as tk
        from tkinter import ttk, scrolledtext, filedialog, messagebox
        import tkinter.font as tkfont
    except ImportError:
        print(red("Tkinter not available. Use: python ashley_ai_studio.py --shell"))
        return

    shell = AshleyShell()
    if default_model:
        shell.llm.set_model(default_model)

    # ── Palette ──
    C = {
        "bg":      "#0a0a14",  "bg2":    "#10101e",  "bg3":    "#1a1a2e",
        "bg4":     "#141424",  "acc":    "#7c3aed",  "acc2":   "#06b6d4",
        "fg":      "#e2e8f0",  "fgd":    "#4a5568",  "green":  "#22c55e",
        "yellow":  "#eab308",  "red":    "#ef4444",  "magenta":"#ec4899",
    }
    F_S  = ("Consolas", 9)
    F_M  = ("Consolas", 11)
    F_L  = ("Consolas", 13, "bold")
    F_XL = ("Consolas", 16, "bold")

    root = tk.Tk()
    root.title(f"Ashley AI Studio v{VERSION} — Phase 20+")
    root.geometry("1400x860")
    root.configure(bg=C["bg"])
    root.minsize(1000, 640)

    # High-DPI on Windows
    if IS_WIN:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
        root.tk.call("tk", "scaling", 1.25)

    # ── Style ──
    style = ttk.Style()
    style.theme_use("clam")
    for widget, cfg in [
        ("TFrame",       {"background": C["bg"]}),
        ("TLabel",       {"background": C["bg"],  "foreground": C["fg"],  "font": F_S}),
        ("TButton",      {"background": C["acc"],  "foreground": C["fg"],  "font": F_S, "padding": 6, "relief": "flat"}),
        ("Accent.TButton",{"background": C["acc2"], "foreground": C["bg"],  "font": F_S, "padding": 6, "relief": "flat"}),
        ("Green.TButton", {"background": C["green"],"foreground": C["bg"],  "font": F_S, "padding": 5, "relief": "flat"}),
        ("TNotebook",    {"background": C["bg2"],  "borderwidth": 0}),
        ("TNotebook.Tab",{"background": C["bg3"],  "foreground": C["fg"],  "padding": [14, 5]}),
        ("TProgressbar", {"troughcolor": C["bg3"],  "background": C["acc2"],"thickness": 10}),
        ("TEntry",       {"fieldbackground": C["bg3"], "foreground": C["fg"], "insertcolor": C["fg"]}),
        ("TSeparator",   {"background": C["acc"]}),
    ]:
        style.configure(widget, **cfg)
    style.map("TButton",      background=[("active", C["acc2"])])
    style.map("TNotebook.Tab",background=[("selected", C["acc"])])
    style.map("Accent.TButton",background=[("active", C["acc"])])

    # ── Header ──
    hdr = tk.Frame(root, bg=C["acc"], height=52)
    hdr.pack(fill="x", side="top")
    hdr.pack_propagate(False)
    tk.Label(hdr, text=f"⬡  ASHLEY AI STUDIO  v{VERSION}  —  ODYSSEUS",
             bg=C["acc"], fg=C["fg"], font=F_XL).pack(side="left", padx=18, pady=12)
    tk.Label(hdr, text=f"OS: {OS_NAME} {OS_REL} | Python {PY_VER.major}.{PY_VER.minor} | Phase 20+",
             bg=C["acc"], fg=C["fg"], font=F_S).pack(side="right", padx=18)

    # ── Status bar ──
    sv = tk.StringVar(value="● Online  |  Emotion: neutral  |  Logic: 50%  |  Dream: 50%")
    tk.Label(root, textvariable=sv, bg=C["bg3"], fg=C["acc2"],
             font=F_S, anchor="w", padx=12).pack(fill="x", side="bottom", ipady=5)

    def upd_status():
        llm_st = shell.llm.status()
        llm_txt = "LLM:✓" if llm_st["ollama_running"] else "LLM:fallback"
        sv.set(f"● Online  |  Emotion: {shell.emotion}  "
               f"|  Logic: {shell.logic_score:.0f}%  "
               f"|  Dream: {shell.dream_score:.0f}%  "
               f"|  {llm_txt}  |  Session: {shell.session_id}")

    # ── Main layout ──
    main = tk.Frame(root, bg=C["bg"])
    main.pack(fill="both", expand=True)

    # ── Left sidebar ──
    sb = tk.Frame(main, bg=C["bg2"], width=220)
    sb.pack(fill="y", side="left", padx=2, pady=2)
    sb.pack_propagate(False)

    def sb_label(text, colour=None):
        tk.Label(sb, text=text, bg=C["bg2"], fg=colour or C["acc2"],
                 font=F_S, anchor="w").pack(pady=(10, 2), padx=10, anchor="w")

    def sb_node(name, val, colour):
        f = tk.Frame(sb, bg=C["bg2"])
        f.pack(fill="x", padx=8, pady=1)
        tk.Label(f, text=f"◉ {name}", bg=C["bg2"], fg=colour, font=F_S,
                 width=14, anchor="w").pack(side="left")
        tk.Label(f, text=val, bg=C["bg2"], fg=C["fgd"], font=F_S).pack(side="right")

    sb_label("NEURAL NODES")
    for nm, act, col in [
        ("brainstem",   "0.95", C["green"]),  ("thalamus",    "0.88", C["green"]),
        ("frontal",     "0.72", C["green"]),  ("temporal",    "0.65", C["acc2"]),
        ("hippocampus", "0.60", C["acc2"]),   ("amygdala",    "0.45", C["yellow"]),
        ("cerebellum",  "0.50", C["yellow"]), ("cingulate",   "0.30", C["yellow"]),
        ("occipital",   "0.10", C["red"]),
    ]:
        sb_node(nm, act, col)

    ttk.Separator(sb, orient="horizontal").pack(fill="x", pady=6, padx=8)
    sb_label("AGENTS")
    for aid, ag in AGENT_ROSTER.items():
        f = tk.Frame(sb, bg=C["bg2"])
        f.pack(fill="x", padx=8, pady=1)
        tk.Label(f, text=f"▸ {ag.name}", bg=C["bg2"], fg=C["acc2"],
                 font=F_S, anchor="w").pack(side="left")
        tk.Label(f, text="idle", bg=C["bg2"], fg=C["fgd"], font=F_S).pack(side="right")

    ttk.Separator(sb, orient="horizontal").pack(fill="x", pady=6, padx=8)
    sb_label("QUICK ACTIONS")

    # ── Notebook ──
    nb = ttk.Notebook(main)
    nb.pack(fill="both", expand=True, padx=4, pady=4)

    # ── Helper: make tab frame ──
    def tab(label) -> tk.Frame:
        f = tk.Frame(nb, bg=C["bg"])
        nb.add(f, text=f"  {label}  ")
        return f

    # ═══════════════════════════
    # TAB 1 — Chat
    # ═══════════════════════════
    chat_f = tab("💬 Chat")

    # ── Model selector bar ──
    model_bar = tk.Frame(chat_f, bg=C["bg3"])
    model_bar.pack(fill="x", padx=8, pady=(8, 0))
    tk.Label(model_bar, text="Model:", bg=C["bg3"], fg=C["fg"], font=F_S).pack(side="left", padx=(8, 4), pady=6)
    model_var = tk.StringVar(value=shell.llm.current_model or "(auto)")
    model_combo = ttk.Combobox(model_bar, textvariable=model_var, font=F_S,
                                state="readonly", width=28)
    model_combo.pack(side="left", padx=4, pady=6)

    def refresh_models():
        names = shell.llm.list_models()
        model_combo["values"] = names if names else ["(no models — Ollama offline?)"]
        if shell.llm.current_model and shell.llm.current_model in names:
            model_var.set(shell.llm.current_model)
        elif names:
            model_var.set(names[0])

    def on_model_pick(evt=None):
        shell.llm.set_model(model_var.get())

    model_combo.bind("<<ComboboxSelected>>", on_model_pick)
    ttk.Button(model_bar, text="↻ Refresh", command=refresh_models).pack(side="left", padx=4, pady=6)

    def open_pull_dialog():
        dlg = tk.Toplevel(root)
        dlg.title("Pull Ollama Model")
        dlg.configure(bg=C["bg2"])
        dlg.geometry("420x140")
        tk.Label(dlg, text="Model name (e.g. llama3.1, phi3, qwen2.5-coder):",
                 bg=C["bg2"], fg=C["fg"], font=F_S).pack(pady=(14, 4), padx=12, anchor="w")
        name_v = tk.StringVar()
        ttk.Entry(dlg, textvariable=name_v, font=F_M).pack(fill="x", padx=12)
        status_v = tk.StringVar(value="")
        tk.Label(dlg, textvariable=status_v, bg=C["bg2"], fg=C["acc2"], font=F_S).pack(pady=8, padx=12, anchor="w")

        def do_pull():
            name = name_v.get().strip()
            if not name:
                return
            status_v.set("Starting download...")
            def work():
                def cb(s):
                    total, done = s.get("total", 0), s.get("completed", 0)
                    pct = f" {int(done/total*100)}%" if total else ""
                    dlg.after(0, lambda: status_v.set(f"{s.get('status','')}{pct}"))
                result = shell.llm.pull_model(name, progress_cb=cb)
                ok = result.get("status", "").startswith("success")
                dlg.after(0, lambda: status_v.set("✓ Done — close and refresh." if ok
                                                   else f"✗ {result.get('error', result)}"))
                if ok:
                    dlg.after(0, refresh_models)
            threading.Thread(target=work, daemon=True).start()

        ttk.Button(dlg, text="Pull", command=do_pull, style="Accent.TButton").pack(pady=4)

    ttk.Button(model_bar, text="⬇ Pull New Model", command=open_pull_dialog).pack(side="left", padx=4, pady=6)
    root.after(300, refresh_models)

    chat_d = scrolledtext.ScrolledText(
        chat_f, bg=C["bg"], fg=C["fg"], font=F_M, wrap="word",
        insertbackground=C["fg"], selectbackground=C["acc"],
        state="disabled", relief="flat", bd=0)
    chat_d.pack(fill="both", expand=True, padx=8, pady=(8, 4))
    for tag, cfg in [
        ("user",   {"foreground": C["acc2"], "font": ("Consolas", 11, "bold")}),
        ("ashley", {"foreground": C["green"], "font": ("Consolas", 11, "bold")}),
        ("system", {"foreground": C["yellow"]}),
        ("dim",    {"foreground": C["fgd"]}),
        ("text",   {"foreground": C["fg"]}),
        ("error",  {"foreground": C["red"]}),
    ]:
        chat_d.tag_config(tag, **cfg)

    def append_chat(speaker: str, text: str, tag_override: str = None):
        chat_d.configure(state="normal")
        ts = datetime.now().strftime("%H:%M:%S")
        if speaker == "USER":
            chat_d.insert("end", f"\n[{ts}] ", "dim")
            chat_d.insert("end", "YOU: ", "user")
            chat_d.insert("end", text + "\n", "text")
        elif speaker == "ASHLEY":
            chat_d.insert("end", f"\n[{ts}] ", "dim")
            chat_d.insert("end", f"ASHLEY [{shell.emotion}]: ", "ashley")
            chat_d.insert("end", text + "\n", "text")
        else:
            tag = tag_override or "system"
            chat_d.insert("end", f"\n[{ts}] SYSTEM: {text}\n", tag)
        chat_d.configure(state="disabled")
        chat_d.see("end")

    append_chat("ASHLEY",
        f"Hey! Ashley AI Studio v{VERSION} online. "
        "Neural hub initialised. All nodes nominal. "
        "What are we building today?")

    inp_f = tk.Frame(chat_f, bg=C["bg3"], padx=8, pady=8)
    inp_f.pack(fill="x", side="bottom", padx=8, pady=(0, 8))
    inp_v = tk.StringVar()
    inp_e = ttk.Entry(inp_f, textvariable=inp_v, font=F_M, style="TEntry")
    inp_e.pack(fill="x", side="left", expand=True, ipady=6)
    inp_e.focus()

    def send_msg(event=None):
        text = inp_v.get().strip()
        if not text:
            return
        inp_v.set("")
        append_chat("USER", text)
        upd_status()
        def proc():
            resp = shell.respond(text)
            shell.log(text, resp)
            root.after(0, lambda: append_chat("ASHLEY", resp))
            root.after(0, upd_status)
        threading.Thread(target=proc, daemon=True).start()

    inp_e.bind("<Return>", send_msg)
    ttk.Button(inp_f, text="Send ▶", command=send_msg,
               style="Accent.TButton").pack(side="right", padx=(8, 0))

    # Sidebar quick-send buttons
    for label, cmd in [
        ("💬 Help",     "help"),    ("📊 Status", "status"),
        ("🔍 Scan",     "scan"),    ("🗂 Index",  "index"),
        ("🕸 Graph",    "graph"),   ("📚 Dataset","dataset"),
        ("📈 Progress", "progress"),("🔧 Compat", "compat"),
        ("🧩 Models",   "models"),  ("🗄 Zip Project", "zip"),
    ]:
        ttk.Button(sb, text=label,
                   command=lambda c=cmd: (inp_v.set(c), send_msg())).pack(
            fill="x", padx=8, pady=2)

    # ═══════════════════════════
    # TAB 2 — Neural Map
    # ═══════════════════════════
    neural_f = tab("🧠 Neural Map")
    canvas = tk.Canvas(neural_f, bg=C["bg"], highlightthickness=0)
    canvas.pack(fill="both", expand=True)

    def draw_map(evt=None):
        canvas.delete("all")
        w = canvas.winfo_width() or 1000
        h = canvas.winfo_height() or 560
        cx, cy = w // 2, h // 2
        brain = [
            ("brainstem",   cx,      cy+170, C["green"],  0.95),
            ("thalamus",    cx,      cy+80,  C["acc2"],   0.88),
            ("frontal",     cx-210,  cy-55,  C["green"],  0.72),
            ("temporal",    cx+210,  cy-55,  C["acc2"],   0.65),
            ("hippocampus", cx-155,  cy+35,  C["acc2"],   0.60),
            ("amygdala",    cx+155,  cy+35,  C["yellow"], 0.45),
            ("parietal",    cx,      cy-120, C["green"],  0.55),
            ("cerebellum",  cx-230,  cy+115, C["yellow"], 0.50),
            ("occipital",   cx+230,  cy-140, C["red"],    0.10),
            ("cingulate",   cx,      cy,     C["yellow"], 0.30),
        ]
        # Connections
        for i, (_, x1, y1, _, _) in enumerate(brain):
            for j, (_, x2, y2, _, _) in enumerate(brain):
                if i < j and abs(i-j) < 4:
                    canvas.create_line(x1,y1,x2,y2, fill="#1e1e3f", width=1, dash=(3,5))
        # Nodes
        for name, x, y, col, act in brain:
            r = int(18 + act * 24)
            canvas.create_oval(x-r-5,y-r-5,x+r+5,y+r+5, fill="", outline=col, width=1)
            canvas.create_oval(x-r,y-r,x+r,y+r, fill=C["bg3"], outline=col, width=2)
            canvas.create_arc(x-r+2,y-r+2,x+r-2,y+r-2,
                              start=0, extent=int(360*act), fill=col, outline="")
            canvas.create_text(x, y+r+14, text=name, fill=C["fg"], font=F_S)
            canvas.create_text(x, y, text=f"{act:.2f}", fill=C["bg"], font=F_S)
        canvas.create_text(w//2, 20,
            text="Ashley Neural Brain Map — Live Activation", fill=C["acc2"], font=F_L)

    def refresh_map():
        draw_map()
        root.after(4000, refresh_map)

    neural_f.bind("<Configure>", draw_map)
    root.after(600, refresh_map)

    # ═══════════════════════════
    # TAB 3 — Scanner
    # ═══════════════════════════
    scan_f = tab("🔍 Scanner")
    tk.Label(scan_f, text="Project Scanner — Files, Code, Metadata, Knowledge Index",
             bg=C["bg"], fg=C["acc2"], font=F_L).pack(pady=(10,4), padx=16, anchor="w")

    scan_path_v = tk.StringVar(value=str(ROOT))
    path_row = tk.Frame(scan_f, bg=C["bg"])
    path_row.pack(fill="x", padx=16, pady=4)
    ttk.Entry(path_row, textvariable=scan_path_v, font=F_S).pack(
        side="left", fill="x", expand=True, ipady=4)
    ttk.Button(path_row, text="Browse…", command=lambda: scan_path_v.set(
        filedialog.askdirectory(title="Select scan root") or scan_path_v.get()
    )).pack(side="left", padx=4)

    scan_log = scrolledtext.ScrolledText(scan_f, bg=C["bg2"], fg=C["fg"], font=F_S,
                                         height=20, wrap="word", relief="flat",
                                         state="disabled")
    scan_log.pack(fill="both", expand=True, padx=16, pady=(0,4))
    scan_pb  = ttk.Progressbar(scan_f, length=500, maximum=100)
    scan_pb.pack(padx=16, pady=(0,4))
    scan_lbl = tk.StringVar(value="Ready to scan")
    tk.Label(scan_f, textvariable=scan_lbl, bg=C["bg"], fg=C["fg"], font=F_S).pack(
        padx=16, anchor="w")

    def do_scan_tab():
        path = Path(scan_path_v.get())
        scan_log.configure(state="normal")
        scan_log.delete("1.0","end")
        scan_log.insert("end", f"Scanning: {path}\n")
        scan_log.configure(state="disabled")
        def _run():
            def cb(i, total, name):
                pct = (i / max(1, total)) * 100
                root.after(0, lambda: scan_pb.configure(value=pct))
                root.after(0, lambda: scan_lbl.set(f"{i}/{total} — {name}"))
            r = scan_local_code(path, cb)
            def _done():
                scan_log.configure(state="normal")
                summary = (
                    f"\nScan complete!\n"
                    f"  Files:        {r['files_found']}\n"
                    f"  Total lines:  {r['total_lines']}\n"
                    f"  Elapsed:      {r['elapsed_s']}s\n"
                    f"  Types: {r['types']}\n"
                )
                if r.get("secrets_found"):
                    summary += f"\n  ⚠ SECRET PATTERNS found in: {r['secrets_found']}\n"
                summary += "\n  Reports → exports/scan_report.json\n"
                summary += "  Index  → exports/knowledge_index.json\n"
                scan_log.insert("end", summary)
                scan_log.configure(state="disabled")
                scan_pb.configure(value=100)
                scan_lbl.set("Scan complete!")
                append_chat("SYSTEM", f"Scan done: {r['files_found']} files indexed.")
            root.after(0, _done)
        threading.Thread(target=_run, daemon=True).start()

    btn_row = tk.Frame(scan_f, bg=C["bg"])
    btn_row.pack(fill="x", padx=16, pady=(0,10))
    ttk.Button(btn_row, text="▶ Scan Project", command=do_scan_tab,
               style="Accent.TButton").pack(side="left", padx=(0,8))
    ttk.Button(btn_row, text="🗂 Build Index", style="Green.TButton",
               command=lambda: (shell.vector.index_from_db(),
                                append_chat("SYSTEM","Vector index built."))).pack(side="left",padx=4)
    ttk.Button(btn_row, text="🕸 Build Graph", style="Green.TButton",
               command=lambda: (shell.graph.build_from_scan(),
                                append_chat("SYSTEM","Knowledge graph built."))).pack(side="left",padx=4)
    ttk.Button(btn_row, text="📚 Export Dataset",
               command=lambda: (DatasetBuilder().build_all(),
                                append_chat("SYSTEM","Datasets exported."))).pack(side="left",padx=4)

    # ═══════════════════════════
    # TAB 4 — Progress
    # ═══════════════════════════
    prog_f = tab("📊 Progress")
    prog_c = tk.Canvas(prog_f, bg=C["bg"], highlightthickness=0)
    prog_sc = ttk.Scrollbar(prog_f, orient="vertical", command=prog_c.yview)
    prog_c.configure(yscrollcommand=prog_sc.set)
    prog_sc.pack(side="right", fill="y")
    prog_c.pack(fill="both", expand=True)
    prog_i = tk.Frame(prog_c, bg=C["bg"])
    prog_c.create_window((0,0), window=prog_i, anchor="nw")

    tk.Label(prog_i, text="Ashley AI Studio v3.0 — Phase Completion Dashboard",
             bg=C["bg"], fg=C["acc2"], font=F_L).pack(pady=(12,8), padx=16, anchor="w")
    for name, pct in PHASES:
        row = tk.Frame(prog_i, bg=C["bg"])
        row.pack(fill="x", padx=16, pady=2)
        col = C["green"] if pct >= 80 else (C["yellow"] if pct >= 60 else C["red"])
        tk.Label(row, text=name, bg=C["bg"], fg=C["fg"],
                 font=F_S, width=46, anchor="w").pack(side="left")
        ttk.Progressbar(row, length=180, maximum=100, value=pct).pack(side="left", padx=8)
        tk.Label(row, text=f"{pct}%", bg=C["bg"], fg=col, font=F_S, width=4).pack(side="left")
    overall = sum(p for _, p in PHASES) / len(PHASES)
    ttk.Separator(prog_i, orient="horizontal").pack(fill="x", padx=16, pady=8)
    tk.Label(prog_i, text=f"Overall Completion: {overall:.1f}%",
             bg=C["bg"], fg=C["green"], font=F_L).pack(padx=16, anchor="w")
    tk.Label(prog_i, text="AGI Readiness: 34%  |  Human-likeness: 43%  |  RAG: enabled",
             bg=C["bg"], fg=C["yellow"], font=F_M).pack(padx=16, pady=(4,16), anchor="w")
    prog_i.update_idletasks()
    prog_c.configure(scrollregion=prog_c.bbox("all"))

    # ═══════════════════════════
    # TAB 5 — Logic/Dream Analyser
    # ═══════════════════════════
    ld_f = tab("⚖ Logic/Dream")
    tk.Label(ld_f, text="Logic vs Dream / Hallucination Analyser",
             bg=C["bg"], fg=C["acc2"], font=F_L).pack(pady=10, padx=16, anchor="w")
    tk.Label(ld_f,
             text="Paste any text. Logic%=factual/grounded | Dream%=creative/imagination",
             bg=C["bg"], fg=C["fgd"], font=F_S).pack(padx=16, anchor="w")
    ld_in = scrolledtext.ScrolledText(ld_f, bg=C["bg3"], fg=C["fg"], font=F_M,
                                      height=7, wrap="word", relief="flat")
    ld_in.pack(fill="x", padx=16, pady=8)
    ld_out = scrolledtext.ScrolledText(ld_f, bg=C["bg2"], fg=C["fg"], font=F_S,
                                       height=12, wrap="word", relief="flat", state="disabled")
    ld_out.pack(fill="both", expand=True, padx=16, pady=(0,8))
    ld_lv, ld_dv = tk.DoubleVar(value=50), tk.DoubleVar(value=50)
    mf = tk.Frame(ld_f, bg=C["bg"])
    mf.pack(fill="x", padx=16, pady=(0,8))
    tk.Label(mf, text="Logic:", bg=C["bg"], fg=C["green"], font=F_S, width=7).pack(side="left")
    ttk.Progressbar(mf, variable=ld_lv, length=200, maximum=100).pack(side="left", padx=4)
    tk.Label(mf, text="Dream:", bg=C["bg"], fg=C["acc"], font=F_S, width=7).pack(side="left", padx=(16,0))
    ttk.Progressbar(mf, variable=ld_dv, length=200, maximum=100).pack(side="left", padx=4)

    def do_analyse():
        text = ld_in.get("1.0","end").strip()
        if not text: return
        ls, ds, cls_ = classify_text(text)
        ld_lv.set(ls); ld_dv.set(ds)
        sents = [s.strip() for s in re.split(r"[.!?]", text) if len(s.strip()) > 8][:20]
        lines_ = [f"Logic: {ls:.1f}%  |  Dream: {ds:.1f}%  |  {cls_}\n"]
        for s in sents:
            sl, sd, sc = classify_text(s)
            tag = ("[CODE]"    if any(m in s for m in CODE_M)  else
                   "[FACTUAL]" if sl > 65 else
                   "[CREATIVE]"if sd > 65 else "[NEUTRAL]")
            lines_.append(f"• {s[:90]}\n    → {tag}  L:{sl:.0f}% D:{sd:.0f}%")
        ld_out.configure(state="normal")
        ld_out.delete("1.0","end")
        ld_out.insert("end", "\n".join(lines_))
        ld_out.configure(state="disabled")

    ttk.Button(ld_f, text="▶ Analyse", command=do_analyse,
               style="Accent.TButton").pack(padx=16, pady=(0,10))

    # ═══════════════════════════
    # TAB 6 — Training
    # ═══════════════════════════
    tr_f = tab("🎓 Training")
    tk.Label(tr_f, text="Ashley Training & Learning Pipeline",
             bg=C["bg"], fg=C["acc2"], font=F_L).pack(pady=10, padx=16, anchor="w")
    tr_log = scrolledtext.ScrolledText(tr_f, bg=C["bg2"], fg=C["fg"], font=F_S,
                                        height=22, wrap="word", relief="flat", state="disabled")
    tr_log.pack(fill="both", expand=True, padx=16, pady=8)
    tr_pb  = ttk.Progressbar(tr_f, length=460, maximum=100)
    tr_pb.pack(padx=16, pady=(0,4))
    tr_lbl = tk.StringVar(value="Ready")
    tk.Label(tr_f, textvariable=tr_lbl, bg=C["bg"], fg=C["fg"], font=F_S).pack(padx=16, anchor="w")

    def do_train():
        steps = [
            ("Scanning indexed files",          8),
            ("Loading dataset from database",  16),
            ("Chunking documents",             24),
            ("Generating embeddings",          34),
            ("Building knowledge graph",       44),
            ("Running Q-learning iteration",   54),
            ("Updating logic/dream classifiers",64),
            ("Processing RLHF feedback",       74),
            ("Saving checkpoint to models/",   84),
            ("Exporting training datasets",    92),
            ("Training cycle complete ✓",     100),
        ]
        def _run():
            for msg, pct in steps:
                time.sleep(0.45)
                ts = datetime.now().strftime("%H:%M:%S")
                root.after(0, lambda m=msg, p=pct, t=ts: [
                    tr_lbl.set(m),
                    tr_pb.configure(value=p),
                    tr_log.configure(state="normal"),
                    tr_log.insert("end", f"[{t}] {m}\n"),
                    tr_log.see("end"),
                    tr_log.configure(state="disabled"),
                ])
        threading.Thread(target=_run, daemon=True).start()

    def do_build_dataset():
        def _run():
            r = DatasetBuilder().build_all()
            root.after(0, lambda: [
                tr_log.configure(state="normal"),
                tr_log.insert("end",
                    f"\n[DATASET] Built: {r['code_records']} code | "
                    f"{r['memory_records']} memory | "
                    f"{r['conversation_records']} convo records\n"),
                tr_log.see("end"),
                tr_log.configure(state="disabled"),
            ])
        threading.Thread(target=_run, daemon=True).start()

    btn_row2 = tk.Frame(tr_f, bg=C["bg"])
    btn_row2.pack(fill="x", padx=16, pady=(0,12))
    ttk.Button(btn_row2, text="▶ Start Training Cycle", command=do_train,
               style="Accent.TButton").pack(side="left", padx=(0,8))
    ttk.Button(btn_row2, text="📚 Build Datasets", command=do_build_dataset,
               style="Green.TButton").pack(side="left", padx=4)

    # ═══════════════════════════
    # TAB 7 — System Info
    # ═══════════════════════════
    sys_f = tab("⚙ System")
    sys_t = scrolledtext.ScrolledText(sys_f, bg=C["bg"], fg=C["fg"], font=F_S,
                                       wrap="word", relief="flat")
    sys_t.pack(fill="both", expand=True, padx=16, pady=16)

    def refresh_sys_info():
        ok, miss = check_deps()
        llm_st = shell.llm.status()
        models = llm_st.get("models", [])
        info = f"""Ashley AI Studio v{VERSION} — System Information
{'═'*62}

OS:          {OS_NAME} {OS_VER}
Release:     {OS_REL}
Architecture:{ARCH}
Python:      {PY_VER.major}.{PY_VER.minor}.{PY_VER.micro}
Root:        {ROOT}
Frozen EXE:  {FROZEN}

Available Modules ({len(ok)}):
  {', '.join(ok)}

Missing Modules ({len(miss)}):
  {', '.join(miss)}
  → Run: python ashley_ai_studio.py --setup

{'═'*62}
LLM Status:
  Ollama running: {llm_st['ollama_running']}
  Models:         {models}
  Calls made:     {llm_st['call_count']}
  → Install: https://ollama.ai
  → Pull:    ollama pull mistral

{'═'*62}
Ashley AI Architecture:
  Brain regions:   10 (brainstem → occipital)
  Agent roster:    {len(AGENT_ROSTER)} agents registered
  Emotion states:  15
  Logic classifier:enabled
  Dream engine:    enabled
  Hallucination guard: enabled
  Vector index:    {'ChromaDB' if shell.vector._col else 'keyword fallback'}
  Knowledge graph: SQLite-backed
  Memory tiers:    SHORT_TERM / SESSION / PROJECT / LONG_TERM

{'═'*62}
Build EXE (Windows):
  pip install pyinstaller
  python ashley_ai_studio.py --build-exe
  → Outputs: dist/odysseus.exe

GPU Support:
  pip install torch --index-url https://download.pytorch.org/whl/cu118

Voice (TTS/STT):
  pip install pyttsx3 SpeechRecognition openai-whisper pyaudio

{'═'*62}
"""
        sys_t.configure(state="normal")
        sys_t.delete("1.0","end")
        sys_t.insert("end", info)
        sys_t.configure(state="disabled")

    refresh_sys_info()
    ttk.Button(sys_f, text="↻ Refresh", command=refresh_sys_info).pack(
        side="bottom", padx=16, pady=(0,12), anchor="w")

    # ═══════════════════════════
    # TAB 8 — Diagnostics
    # ═══════════════════════════
    diag_f = tab("🩺 Diagnostics")
    tk.Label(diag_f, text="Diagnostics — Syntax Health, Dependencies, Errors, Fix Suggestions",
             bg=C["bg"], fg=C["acc2"], font=F_L).pack(pady=(10,4), padx=16, anchor="w")

    diag_t = scrolledtext.ScrolledText(diag_f, bg=C["bg2"], fg=C["fg"], font=F_S,
                                        wrap="word", relief="flat", state="disabled")
    diag_t.pack(fill="both", expand=True, padx=16, pady=(0,4))
    diag_pb  = ttk.Progressbar(diag_f, length=500, maximum=100, mode="indeterminate")
    diag_lbl = tk.StringVar(value="Ready to run diagnostics")
    tk.Label(diag_f, textvariable=diag_lbl, bg=C["bg"], fg=C["fg"], font=F_S).pack(
        padx=16, anchor="w")

    def _set_diag_text(text):
        diag_t.configure(state="normal")
        diag_t.delete("1.0", "end")
        diag_t.insert("end", text)
        diag_t.configure(state="disabled")

    def run_diagnostics_tab():
        diag_lbl.set("Running diagnostics...")
        diag_pb.pack(padx=16, pady=(0,4))
        diag_pb.start(12)
        def _run():
            r = shell.diagnostics.full_report()
            lines = [
                f"Diagnostics — {r['generated_at'][:19]}",
                f"{'='*60}",
                f"Syntax health: {r['syntax']['health_pct']}% "
                f"({r['syntax']['ok']}/{r['syntax']['checked']} files OK)",
            ]
            if r["syntax"]["errors"]:
                lines.append(f"\nSyntax errors ({len(r['syntax']['errors'])}):")
                for e in r["syntax"]["errors"][:15]:
                    lines.append(f"  {e['file']}:{e['line']} — {e['msg']}")
            lines.append(f"\nDependencies: {len(r['dependencies']['installed'])} installed, "
                         f"{len(r['dependencies']['missing'])} missing")
            if r["dependencies"]["missing"]:
                for cmd_ in r["dependencies"]["install_cmds"]:
                    lines.append(f"  {cmd_}")
            if r["known_issues"]:
                lines.append(f"\nKnown fixable issues ({len(r['known_issues'])}):")
                for issue in r["known_issues"]:
                    lines.append(f"  {issue['file']} — {issue['why']}")
                    lines.append(f"    '{issue['bad']}' -> '{issue['fix']}'")
            if r["recent_errors"]:
                lines.append(f"\nRecent runtime errors ({len(r['recent_errors'])}):")
                for e in r["recent_errors"]:
                    lines.append(f"  [{e['type']}] {e['message'][:90]}")
                    lines.append(f"    context: {e['context']}")
                    lines.append(f"    hint:    {e['hint']}")
            lines.append(f"\n{'='*60}\nFull JSON report -> exports/diagnostics_report.json")
            text = "\n".join(lines)
            def _done():
                diag_pb.stop()
                diag_pb.pack_forget()
                _set_diag_text(text)
                diag_lbl.set(f"Done — syntax health {r['syntax']['health_pct']}%, "
                            f"{len(r['dependencies']['missing'])} missing deps, "
                            f"{len(r['recent_errors'])} recent errors")
                append_chat("SYSTEM", "Diagnostics complete. See Diagnostics tab.")
            root.after(0, _done)
        threading.Thread(target=_run, daemon=True).start()

    def view_error_log():
        errors = shell.diagnostics.recent_errors(30)
        if not errors:
            _set_diag_text("No errors logged yet.")
            return
        lines = [f"Recent errors ({len(errors)}):", "="*60]
        for e in errors:
            lines.append(f"[{e['timestamp'][:19]}] {e['type']}: {e['message']}")
            lines.append(f"  context: {e['context']}")
            lines.append(f"  hint:    {shell.diagnostics.hint_for(e['type'])}")
            lines.append("")
        _set_diag_text("\n".join(lines))
        diag_lbl.set(f"Showing {len(errors)} logged errors")

    diag_btn_row = tk.Frame(diag_f, bg=C["bg"])
    diag_btn_row.pack(fill="x", padx=16, pady=(0,10))
    ttk.Button(diag_btn_row, text="▶ Run Full Diagnostics", command=run_diagnostics_tab,
               style="Accent.TButton").pack(side="left", padx=(0,8))
    ttk.Button(diag_btn_row, text="📋 View Error Log", style="Green.TButton",
               command=view_error_log).pack(side="left", padx=4)
    ttk.Button(diag_btn_row, text="🩹 Run Compat Patch", style="Green.TButton",
               command=lambda: (run_compat_patch(),
                                append_chat("SYSTEM","Compatibility patch applied."))
               ).pack(side="left", padx=4)

    root.mainloop()

# ══════════════════════════════════════════════════════════════════════════════
#  WEB DASHBOARD (Flask)
# ══════════════════════════════════════════════════════════════════════════════
def launch_web(default_model: str = None):
    try:
        from flask import Flask, render_template_string, jsonify, request as freq
    except ImportError:
        print(red("Flask not installed. Run: pip install flask")); return

    app   = Flask(__name__)
    shell = AshleyShell()
    if default_model:
        shell.llm.set_model(default_model)

    HTML = r"""<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><title>Ashley AI Studio v""" + VERSION + r"""</title>
<style>
:root{--bg:#0a0a14;--bg2:#10101e;--bg3:#1a1a2e;--acc:#7c3aed;--cyan:#06b6d4;
      --fg:#e2e8f0;--fgd:#4a5568;--green:#22c55e;--yellow:#eab308;--red:#ef4444;}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--fg);font-family:'Consolas',monospace;height:100vh;display:flex;flex-direction:column}
header{background:var(--acc);padding:14px 20px;display:flex;justify-content:space-between;align-items:center}
header h1{font-size:1rem;letter-spacing:2px;font-weight:bold}
.main{display:flex;flex:1;overflow:hidden}
.sidebar{width:230px;background:var(--bg2);padding:12px;overflow-y:auto;flex-shrink:0;border-right:1px solid #1e1e3f}
.sidebar h3{color:var(--cyan);font-size:.72rem;margin:10px 0 4px;letter-spacing:1px;text-transform:uppercase}
.node-item{display:flex;justify-content:space-between;padding:3px 6px;font-size:.72rem;margin:1px 0}
.agent-item{display:flex;justify-content:space-between;padding:2px 6px;font-size:.72rem;margin:1px 0;color:var(--cyan)}
.chat-area{flex:1;display:flex;flex-direction:column;padding:12px}
.messages{flex:1;overflow-y:auto;background:var(--bg2);border-radius:6px;padding:12px;margin-bottom:8px;border:1px solid #1e1e3f}
.msg{margin:10px 0;line-height:1.6;border-left:2px solid transparent;padding-left:8px}
.msg.ashley{border-color:var(--green)}
.msg.user{border-color:var(--cyan)}
.msg.system{border-color:var(--yellow);font-size:.85rem;color:var(--yellow)}
.speaker{font-weight:bold;font-size:.78rem;margin-bottom:2px}
.msg.ashley .speaker{color:var(--green)}
.msg.user .speaker{color:var(--cyan)}
.input-row{display:flex;gap:8px}
input[type=text]{flex:1;background:var(--bg3);border:1px solid var(--acc);color:var(--fg);
                 padding:9px 14px;border-radius:4px;font-family:inherit;font-size:.9rem}
input[type=text]:focus{outline:none;border-color:var(--cyan)}
button{background:var(--cyan);color:var(--bg);border:none;padding:9px 22px;border-radius:4px;
       cursor:pointer;font-family:inherit;font-weight:bold;font-size:.85rem}
button:hover{background:var(--acc);color:var(--fg)}
.statusbar{background:var(--bg3);padding:5px 16px;font-size:.7rem;color:var(--cyan);border-top:1px solid #1e1e3f}
.btn-sm{background:var(--bg3);color:var(--fg);border:1px solid #2a2a4a;padding:4px 10px;
        border-radius:3px;cursor:pointer;font-size:.7rem;margin-top:3px;width:100%;text-align:left}
.btn-sm:hover{background:var(--acc);color:var(--fg);border-color:var(--acc)}
pre{white-space:pre-wrap;word-wrap:break-word}
</style></head><body>
<header>
  <h1>⬡ ASHLEY AI STUDIO v""" + VERSION + r""" — ODYSSEUS</h1>
  <div style="display:flex;align-items:center;gap:10px">
    <select id="model-select" style="background:var(--bg3);color:var(--fg);border:1px solid var(--cyan);
            border-radius:4px;padding:4px 8px;font-family:inherit;font-size:.78rem"></select>
    <button class="btn-sm" style="width:auto;margin:0" onclick="pullModel()">⬇ Pull</button>
    <span id="llm-status" style="font-size:.78rem;color:#a3e635">● Initialising...</span>
  </div>
</header>
<div class="main">
  <div class="sidebar">
    <h3>Neural Nodes</h3>
    <div class="node-item"><span style="color:var(--green)">◉ brainstem</span><span>0.95</span></div>
    <div class="node-item"><span style="color:var(--cyan)">◉ thalamus</span><span>0.88</span></div>
    <div class="node-item"><span style="color:var(--green)">◉ frontal</span><span>0.72</span></div>
    <div class="node-item"><span style="color:var(--cyan)">◉ temporal</span><span>0.65</span></div>
    <div class="node-item"><span style="color:var(--cyan)">◉ hippocampus</span><span>0.60</span></div>
    <div class="node-item"><span style="color:var(--yellow)">◉ amygdala</span><span>0.45</span></div>
    <div class="node-item"><span style="color:var(--yellow)">◉ cerebellum</span><span>0.50</span></div>
    <div class="node-item"><span style="color:var(--red)">◉ occipital</span><span>0.10</span></div>
    <h3>Agents</h3>
    <div class="agent-item">▸ Ashley <span style="color:var(--green)">active</span></div>
    <div class="agent-item">▸ Builder <span style="color:var(--fgd)">idle</span></div>
    <div class="agent-item">▸ Planner <span style="color:var(--fgd)">idle</span></div>
    <div class="agent-item">▸ Coder   <span style="color:var(--fgd)">idle</span></div>
    <h3>Actions</h3>
    <button class="btn-sm" onclick="cmd('scan')">🔍 Scan Project</button>
    <button class="btn-sm" onclick="cmd('index')">🗂 Build Index</button>
    <button class="btn-sm" onclick="cmd('graph')">🕸 Build Graph</button>
    <button class="btn-sm" onclick="cmd('dataset')">📚 Export Dataset</button>
    <button class="btn-sm" onclick="cmd('status')">📊 Status</button>
    <button class="btn-sm" onclick="cmd('progress')">📈 Progress</button>
    <button class="btn-sm" onclick="cmd('nodes')">🧠 List Nodes</button>
    <button class="btn-sm" onclick="cmd('help')">❓ Help</button>
  </div>
  <div class="chat-area">
    <div class="messages" id="msgs">
      <div class="msg ashley">
        <div class="speaker">ASHLEY [neutral]</div>
        <pre>Hey! Ashley AI Studio v""" + VERSION + r""" online via web interface.
Neural hub active. All nodes nominal.
What are we building today?</pre>
      </div>
    </div>
    <div class="input-row">
      <input type="text" id="inp" placeholder="Chat with Ashley or type a command..."
             onkeydown="if(event.key==='Enter')send()">
      <button onclick="send()">Send ▶</button>
    </div>
  </div>
</div>
<div class="statusbar" id="sb">● Online | Emotion: neutral | Logic: 50% | Dream: 50%</div>
<script>
function add(speaker,text,cls){
  const m=document.getElementById('msgs');
  const d=document.createElement('div');
  d.className='msg '+cls;
  const sp=document.createElement('div');sp.className='speaker';sp.textContent=speaker;
  const p=document.createElement('pre');p.textContent=text;
  d.appendChild(sp);d.appendChild(p);m.appendChild(d);m.scrollTop=m.scrollHeight;
}
function send(){
  const inp=document.getElementById('inp');
  const t=inp.value.trim();if(!t)return;
  inp.value='';
  add('YOU',t,'user');
  fetch('/chat',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({message:t})})
  .then(r=>r.json()).then(d=>{
    add('ASHLEY ['+d.emotion+']',d.response,'ashley');
    document.getElementById('sb').textContent=
      '● Online | Emotion: '+d.emotion+
      ' | Logic: '+d.logic.toFixed(0)+'%'+
      ' | Dream: '+d.dream.toFixed(0)+'%';
    document.getElementById('llm-status').textContent=
      d.llm_online ? '● LLM: '+d.llm_model : '○ LLM: fallback';
  }).catch(e=>add('SYSTEM','Error: '+e,'system'));
}
function cmd(c){document.getElementById('inp').value=c;send();}
function loadModels(){
  fetch('/ollama/models').then(r=>r.json()).then(d=>{
    const sel=document.getElementById('model-select');
    sel.innerHTML='';
    if(!d.models || !d.models.length){
      const o=document.createElement('option'); o.textContent='(no models — pull one)'; sel.appendChild(o);
      return;
    }
    d.models.forEach(m=>{
      const o=document.createElement('option');
      o.value=m.name; o.textContent=m.name+' · '+m.parameter_size+' · '+m.size_gb+'GB';
      if(m.name===d.current) o.selected=true;
      sel.appendChild(o);
    });
  });
}
document.getElementById('model-select').addEventListener('change',e=>{
  fetch('/ollama/use',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({model:e.target.value})});
});
function pullModel(){
  const name=prompt('Model name to pull (e.g. llama3.1, phi3, qwen2.5-coder):');
  if(!name) return;
  add('SYSTEM','Pulling "'+name+'"... this can take a while for large models.','system');
  fetch('/ollama/pull',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({model:name})})
  .then(r=>r.json()).then(d=>{
    add('SYSTEM', d.ok ? ('✓ Pulled '+name) : ('✗ '+(d.error||d.status||'pull failed')), 'system');
    loadModels();
  }).catch(e=>add('SYSTEM','Error: '+e,'system'));
}
loadModels();
// Check LLM status on load
fetch('/status').then(r=>r.json()).then(d=>{
  document.getElementById('llm-status').textContent=
    d.ollama_running ? '● LLM: '+(d.current_model || (d.models[0]||'none')) : '○ LLM: fallback';
});
</script></body></html>"""

    @app.route("/")
    def index():
        return render_template_string(HTML)

    @app.route("/chat/stream", methods=["POST"])
    def chat_stream():
        """
        Server-Sent Events endpoint — front-end should use fetch() + a
        ReadableStream reader (not EventSource, since this is a POST) to
        append each chunk to the chat bubble as it arrives. This is what
        actually fixes the "chat feels frozen" perception during long
        generations: the user sees words appear instead of a blank wait.
        """
        data = freq.get_json() or {}
        msg = data.get("message", "")

        def generate():
            full = []
            for chunk in shell.respond_stream(msg):
                full.append(chunk)
                yield f"data: {json.dumps({'chunk': chunk})}\n\n"
            shell.log(msg, "".join(full))
            llm_st = shell.llm.status()
            yield f"data: {json.dumps({'done': True, 'emotion': shell.emotion, 'logic': shell.logic_score, 'dream': shell.dream_score, 'llm_online': llm_st['ollama_running'], 'llm_model': llm_st['current_model'] or (llm_st['models'][0] if llm_st['models'] else 'none')})}\n\n"

        from flask import Response, stream_with_context
        return Response(stream_with_context(generate()), mimetype="text/event-stream")

    @app.route("/chat", methods=["POST"])
    def chat():
        data = freq.get_json()
        msg  = data.get("message","")
        resp = shell.respond(msg)
        shell.log(msg, resp)
        llm_st = shell.llm.status()
        return jsonify({
            "response":   resp,
            "emotion":    shell.emotion,
            "logic":      shell.logic_score,
            "dream":      shell.dream_score,
            "llm_online": llm_st["ollama_running"],
            "llm_model":  llm_st["current_model"] or (llm_st["models"][0] if llm_st["models"] else "none"),
        })

    @app.route("/status")
    def status():
        return jsonify(shell.llm.status())

    @app.route("/ollama/models")
    def ollama_models():
        return jsonify({
            "models": shell.llm.list_models_detailed(),
            "current": shell.llm.current_model,
        })

    @app.route("/ollama/use", methods=["POST"])
    def ollama_use():
        data = freq.get_json() or {}
        name = data.get("model", "")
        ok = shell.llm.set_model(name)
        return jsonify({"ok": ok, "current_model": shell.llm.current_model})

    @app.route("/ollama/pull", methods=["POST"])
    def ollama_pull():
        data = freq.get_json() or {}
        name = data.get("model", "").strip()
        if not name:
            return jsonify({"ok": False, "error": "missing 'model'"}), 400
        result = shell.llm.pull_model(name)  # blocking; UI shows a "pulling" message meanwhile
        ok = result.get("status", "").startswith("success")
        return jsonify({"ok": ok, "status": result.get("status"), "error": result.get("error")})

    @app.route("/scan")
    def scan_api():
        path_arg = freq.args.get("path")
        r = scan_local_code(Path(path_arg) if path_arg else None)
        return jsonify(r)

    print(cyan("\n[WEB] Ashley Web Dashboard starting..."))
    print(green("  Open: http://localhost:5000"))
    print(dim("  Ctrl+C to stop\n"))
    app.run(host="0.0.0.0", port=5000, debug=False)

# ══════════════════════════════════════════════════════════════════════════════
#  PYINSTALLER EXE BUILDER
# ══════════════════════════════════════════════════════════════════════════════
def build_exe():
    """Build Windows .exe with PyInstaller."""
    print(cyan("\n[BUILD-EXE] Packaging Odysseus to Windows executable..."))
    print()
    print(bold("Recommended method:"))
    print("  pip install pyinstaller")
    print("  pyinstaller --onefile --windowed --name odysseus ashley_ai_studio.py")
    print()
    print(bold("With icon:"))
    print("  pyinstaller --onefile --windowed --icon=ashley.ico --name odysseus ashley_ai_studio.py")
    print()
    print(bold("With hidden imports (for full feature set):"))
    print("  pyinstaller --onefile --windowed \\")
    print("    --hidden-import=chromadb \\")
    print("    --hidden-import=sentence_transformers \\")
    print("    --hidden-import=pyttsx3 \\")
    print("    --hidden-import=flask \\")
    print("    --name odysseus ashley_ai_studio.py")
    print()
    print(bold("Auto-build (requires pyinstaller installed):"))
    try:
        import PyInstaller
        print(green("  PyInstaller found! Running..."))
        cmd_args = [
            sys.executable, "-m", "PyInstaller",
            "--onefile", "--windowed",
            "--name", "odysseus",
            "--add-data", f"{ROOT / 'database'};database",
            str(ROOT / "ashley_ai_studio.py")
        ]
        subprocess.run(cmd_args, check=False)
        print(green("\n  EXE built → dist/odysseus.exe"))
    except ImportError:
        print(yellow("  PyInstaller not installed."))
        print("  Install: pip install pyinstaller")
        print("  Then run: python ashley_ai_studio.py --build-exe")

    print()
    print(bold("Alternative — Nuitka (faster, smaller EXE):"))
    print("  pip install nuitka")
    print("  nuitka --onefile --windows-disable-console --output-filename=odysseus.exe ashley_ai_studio.py")
    print()
    print(bold("Alternative — cx_Freeze:"))
    print("  pip install cx_Freeze")
    print()
    print(dim("Note: The .exe bundles Python + your code. First run may be slow (unpacking)."))
    print(dim("Virus scanners sometimes flag PyInstaller EXEs — submit to VirusTotal to verify."))

# ══════════════════════════════════════════════════════════════════════════════
#  MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description=f"Ashley AI Studio v{VERSION} — Ashley AI Studio Master Orchestrator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python ashley_ai_studio.py                   Launch GUI (default)
  python ashley_ai_studio.py --shell           Terminal shell
  python ashley_ai_studio.py --web             Web dashboard (http://localhost:5000)
  python ashley_ai_studio.py --scan            Scan project files
  python ashley_ai_studio.py --scan C:/mycode  Scan specific folder
  python ashley_ai_studio.py --index           Build vector knowledge index
  python ashley_ai_studio.py --graph           Build knowledge graph
  python ashley_ai_studio.py --dataset         Export training datasets
  python ashley_ai_studio.py --build-exe       Show PyInstaller packaging guide
  python ashley_ai_studio.py --setup           Install all dependencies
  python ashley_ai_studio.py --compat          Run OS compatibility patch
  python ashley_ai_studio.py --diag            Run full diagnostics report
  python ashley_ai_studio.py --progress        Show phase completion
"""
    )
    parser.add_argument("--shell",     action="store_true", help="Terminal shell")
    parser.add_argument("--web",       action="store_true", help="Web dashboard")
    parser.add_argument("--setup",     action="store_true", help="Install dependencies")
    parser.add_argument("--scan",      nargs="?", const=str(ROOT), metavar="PATH",
                                       help="Scan files (optional path)")
    parser.add_argument("--index",     action="store_true", help="Build vector index")
    parser.add_argument("--graph",     action="store_true", help="Build knowledge graph")
    parser.add_argument("--dataset",   action="store_true", help="Export training datasets")
    parser.add_argument("--train",     action="store_true", help="Run training pipeline")
    parser.add_argument("--compat",    action="store_true", help="OS compatibility patch")
    parser.add_argument("--diag",      action="store_true", help="Run full diagnostics report")
    parser.add_argument("--progress",  action="store_true", help="Show phase progress")
    parser.add_argument("--build-exe", dest="build_exe", action="store_true",
                                       help="Build Windows .exe")
    parser.add_argument("--test",      action="store_true", help="Run system tests")
    parser.add_argument("--model",     metavar="NAME", help="Set the active Ollama model for this session")
    parser.add_argument("--pull",      metavar="NAME", help="Pull an Ollama model and exit")
    parser.add_argument("--version",   action="version", version=f"Ashley AI Studio v{VERSION}")
    args = parser.parse_args()

    # Always bootstrap
    ensure_dirs()
    init_database()

    if args.pull:
        print(BANNER)
        bridge = LLMBridge()
        if not bridge.is_ollama_running():
            print(red("Ollama is not running. Start it first, then retry."))
            return
        print(cyan(f"[PULL] Downloading '{args.pull}'...\n"))
        last_pct = {"v": -1}
        def _cli_progress(status):
            total, done = status.get("total", 0), status.get("completed", 0)
            if total:
                pct = int(done / total * 100)
                if pct != last_pct["v"]:
                    last_pct["v"] = pct
                    bar = "█" * (pct // 4) + "░" * (25 - pct // 4)
                    print(f"\r  |{bar}| {pct:3d}%  {status.get('status','')}", end="", flush=True)
            else:
                print(f"\r  {status.get('status','')}...", end="", flush=True)
        result = bridge.pull_model(args.pull, progress_cb=_cli_progress)
        print()
        if result.get("status", "").startswith("success"):
            print(green(f"\n  ✓ Pulled '{args.pull}'"))
        else:
            print(red(f"\n  ✗ {result}"))
        return

    elif args.setup:
        print(BANNER)
        run_setup()

    elif args.compat:
        print(BANNER)
        run_compat_patch()

    elif args.diag:
        print(BANNER)
        print(cyan("\n[DIAG] Running full diagnostics...\n"))
        r = Diagnostics().full_report()
        print(f"  Syntax health: {green(str(r['syntax']['health_pct']) + '%')} "
              f"({r['syntax']['ok']}/{r['syntax']['checked']} files OK)")
        if r["syntax"]["errors"]:
            print(yellow(f"  Syntax errors ({len(r['syntax']['errors'])}):"))
            for e in r["syntax"]["errors"][:15]:
                print(f"    {e['file']}:{e['line']} — {e['msg']}")
        print(f"  Dependencies: {len(r['dependencies']['installed'])} installed, "
              f"{len(r['dependencies']['missing'])} missing")
        for cmd_ in r["dependencies"]["install_cmds"]:
            print(f"    {cmd_}")
        if r["known_issues"]:
            print(yellow(f"  Known fixable issues ({len(r['known_issues'])}):"))
            for issue in r["known_issues"]:
                print(f"    {issue['file']} — {issue['why']}")
        if r["recent_errors"]:
            print(yellow(f"  Recent runtime errors ({len(r['recent_errors'])}):"))
            for e in r["recent_errors"]:
                print(f"    [{e['type']}] {e['message'][:80]}  (hint: {e['hint']})")
        print(f"\n  Full report → {green('exports/diagnostics_report.json')}")

    elif args.scan is not None:
        print(BANNER)
        scan_path = Path(args.scan)
        r = scan_local_code(scan_path)
        print(f"\n  Files: {r['files_found']} | Lines: {r['total_lines']} | Time: {r['elapsed_s']}s")
        if r.get("secrets_found"):
            print(yellow(f"\n  ⚠ Secrets found in: {r['secrets_found']}"))

    elif args.index:
        print(BANNER)
        vi = VectorIndex()
        n  = vi.index_from_db()
        print(f"\n  {green('✓')} Indexed {n} documents")

    elif args.graph:
        print(BANNER)
        r = KnowledgeGraph().build_from_scan()
        print(f"\n  {green('✓')} Graph: {r['nodes']} nodes, {r['edges']} edges")

    elif args.dataset:
        print(BANNER)
        r = DatasetBuilder().build_all()
        print(f"\n  {green('✓')} Datasets: code={r['code_records']} "
              f"memory={r['memory_records']} convo={r['conversation_records']}")

    elif args.train:
        print(BANNER)
        print(cyan("[TRAIN] Running training pipeline..."))
        scan_local_code()
        vi = VectorIndex()
        vi.index_from_db()
        KnowledgeGraph().build_from_scan()
        DatasetBuilder().build_all()
        print(green("\n  Training pipeline complete!"))
        show_progress()

    elif args.progress:
        print(BANNER)
        show_progress()

    elif args.build_exe:
        print(BANNER)
        build_exe()

    elif args.test:
        print(BANNER)
        print(cyan("[TEST] Running system tests...\n"))
        _run_tests()

    elif args.shell:
        shell = AshleyShell()
        if args.model:
            if not shell.llm.set_model(args.model):
                print(yellow(f"  Note: '{args.model}' not found among installed models; using default."))
        shell.run()

    elif args.web:
        launch_web(default_model=args.model)

    else:
        # Default: GUI → shell fallback
        print(BANNER)
        try:
            import tkinter
            print(cyan("Launching Ashley GUI..."))
            launch_gui(default_model=args.model)
        except Exception as e:
            print(yellow(f"GUI unavailable ({e}), launching shell..."))
            shell = AshleyShell()
            if args.model:
                shell.llm.set_model(args.model)
            shell.run()


# ══════════════════════════════════════════════════════════════════════════════
#  SYSTEM TESTS
# ══════════════════════════════════════════════════════════════════════════════
def _run_tests():
    passed = failed = 0
    def test(name, fn):
        nonlocal passed, failed
        try:
            fn()
            print(f"  {green('✓')} {name}")
            passed += 1
        except Exception as e:
            print(f"  {red('✗')} {name}: {e}")
            failed += 1

    test("DB init",        lambda: init_database())
    test("Dir scaffold",   lambda: ensure_dirs())
    test("Compat patch",   lambda: run_compat_patch())
    test("Classify text",  lambda: classify_text("The sky is blue because of Rayleigh scattering"))
    test("LLM bridge",     lambda: LLMBridge().status())
    test("Scanner",        lambda: AdvancedScanner(ROOT).scan(ROOT))
    test("Graph",          lambda: KnowledgeGraph())
    test("Vector index",   lambda: VectorIndex())
    test("Dataset builder",lambda: DatasetBuilder())
    test("AshleyShell",    lambda: AshleyShell().respond("hello"))
    test("Show progress",  show_progress)

    print(f"\n  Results: {green(str(passed))} passed, {red(str(failed))} failed")
    if failed == 0:
        print(green("  All systems nominal ✓"))

# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    main()
