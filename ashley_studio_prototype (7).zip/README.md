# Ashley AI Studio — Extension Prototype

This zip contains: your original `ashley_ai_studio.py` (one small patch applied,
see below), three new standalone modules, and this integration guide.

## What's in here

```
ashley_ai_studio.py          <- your file, patched: num_predict, timeout,
                                 warm-up, streaming chat, SSE endpoint
ashley_studio_extensions/
    draft_verify.py           <- draft/verify (speculative-decoding-style) engine
    ollama_blobs.py           <- local Ollama model inventory scanner
    virtual_desktop.py        <- "kernel" -> Virtual Desktop terminology + wrapper
    system_monitor.py         <- CPU/RAM/GPU inventory + efficiency suggestions
    word_validator.py         <- real-word filtering (replaces brute-force
                                 letter-combination enumeration)
    personas.py                <- Ashley & Cortana as distinct, tunable personas
    RAG_AUDIT.md               <- concrete audit of VectorIndex/KnowledgeGraph
    COMPLETION_AUDIT.md        <- honest completion % across the whole project
README.md                     <- this file
```

## 1. Patches already applied to `ashley_ai_studio.py`

- `LLMBridge.chat()` had `"num_predict": 512` hardcoded (short-response bug)
  → now `self.num_predict = 2048`, configurable per-instance.
- `chat()` had a hardcoded 30s timeout, too short for a model's *first* load
  into memory (which is what was actually timing out in your logs, not
  generation itself) → now `self.chat_timeout = 120`, plus a `warm_up()`
  method that force-loads a model on a generous timeout *before* the user's
  real message hits the shorter budget. Timeout errors now say plainly that
  the model may still be loading, instead of a bare exception string.
- New `chat_stream()` / `AshleyShell.respond_stream()` / `/chat/stream` SSE
  endpoint — streams tokens as they arrive instead of blocking for the full
  response. This is the fix for chat *feeling* slow even when total
  generation time is unchanged. Front-end wiring (fetch + ReadableStream
  reader, since SSE-over-POST isn't `EventSource`-compatible) still needs to
  be added to the dashboard's JS — the endpoint is ready, the display isn't
  wired to it yet.

## 2. Draft/Verify engine (`draft_verify.py`)

Implements the intern/boss workflow you described: a fast drafter model
writes, a verifier model scores it (accuracy/coherence/code_quality/
efficiency/overall) and either publishes, requests a revision, or rejects
outright, looping up to `MAX_CYCLES` times. Nothing returns until the
verifier's score clears `PUBLISH_THRESHOLD` or cycles run out.

Wire it in wherever `LLMBridge` is already used, e.g. inside `AshleyShell`:

```python
from ashley_studio_extensions.draft_verify import DraftVerifyEngine

engine = DraftVerifyEngine(
    backend=self.llm,                 # your existing LLMBridge instance
    drafter_model="phi3",             # small/fast — the "intern"
    verifier_model="mistral",         # bigger — the "boss/publisher"
)
report = engine.publish("Write a function that reverses a linked list")
print(report.final_text, report.published, report.cycles_used)
```

**Read the note at the bottom of that file** before you assume this is
token-level speculative decoding — it's a chunk-level approximation that
gets you the actual behavior you described (draft → check → revise →
publish) using APIs Ollama actually exposes today. True parallel-token
speculative decoding needs raw logit access; the file explains the two real
paths to that (Ollama's `/v1` OpenAI-compatible endpoint, or llama.cpp's
native `--model-draft` flag) if you want to chase it later.

## 3. Ollama blob/manifest scanner (`ollama_blobs.py`)

```python
from ashley_studio_extensions.ollama_blobs import OllamaBlobScanner

scanner = OllamaBlobScanner()   # auto-detects ~/.ollama/models, or pass root=
print(scanner.summary())
```

Run this **on your own machine** (it needs your actual `.ollama` folder,
which isn't present in this sandbox — I tested it here against a Linux path
and confirmed it degrades cleanly when the folder's missing, but the real
output will only show up when you run it against your Windows
`C:\Users\wills\.ollama\models`).

Important reality check baked into the file's docstring: blobs are frozen
GGUF weights, not something you scan to "train" a model. This tool gives you
inventory (which models, what size, which blobs are present/missing) for
your `ModelRouter` to pick from — it is not a training data source.

## 4. Virtual Desktop layer (`virtual_desktop.py`)

Your only literal "kernel" references were Windows' `kernel32.dll` calls in
`_win_bootstrap()` — those have to keep that exact name, they're OS API
lookups. What actually wanted renaming was the conceptual "thing that
decides which front-end to boot." That's now an explicit `VirtualDesktop`
class with registered "workspaces" (gui/shell/web), replacing an implicit
if/elif in `main()`:

```python
from ashley_studio_extensions.virtual_desktop import build_default_desktop

vd = build_default_desktop(launch_gui, launch_web, AshleyShell)
vd.open(args.mode or "gui", default_model=args.model)
```

## 5. RAG audit (`RAG_AUDIT.md`) & completion audit (`COMPLETION_AUDIT.md`)

Concrete gaps in `VectorIndex`/`KnowledgeGraph`, ranked by real impact
(biggest: you're indexing file summaries, not chunked content). The
completion audit is an honest read of what's actually built vs. described
across the whole project (core, media studio, RAG, and everything in this
zip), with rough percentages and an explicit list of what's genuinely not
started yet (TTS/STT, avatar livestreaming, hardware voltage/thermal
detection, trained image/video generation) and why each is a separate
project rather than a quick add-on.

## 6. System monitor (`system_monitor.py`)

```python
from ashley_studio_extensions.system_monitor import SystemMonitor
mon = SystemMonitor()
snap = mon.snapshot()          # CPU/RAM/GPU utilization, temps where available
print(mon.recommend(snap))     # plain-language efficiency suggestions
```

Reads CPU/RAM via `psutil`, GPU via `nvidia-smi` if present (Apple Silicon
gets a unified-memory note instead of separate VRAM). Deliberately does
**not** attempt voltage/VRM-level "damage detection" — that needs vendor
tools with kernel-level access (HWiNFO64, GPU-Z, `lm-sensors`), not a Python
script. The docstring explains why and points to the right tool for that
specific need.

## 7. Word validator (`word_validator.py`)

This replaces the "generate every letter/number combination until they're
all built" idea — that's combinatorially unbounded and mostly nonsense
output. Instead: check candidate tokens against a real wordlist (auto-finds
`/usr/share/dict/words` if present), with an optional LLM call as a
second-opinion backstop for words the static list misses:

```python
from ashley_studio_extensions.word_validator import WordValidator
wv = WordValidator()
result = wv.check("blorptastic", llm_bridge=shell.llm)  # falls back to asking Ollama
```

## 8. Personas (`personas.py`)

Ashley and Cortana as distinct, data-driven personas (traits, tone, a
`logic_bias` float, separate system prompts) instead of one hardcoded
system prompt in `LLMBridge`. Integration note at the bottom of the file
shows the exact `LLMBridge` change needed plus a `set_persona()` method so
`AshleyShell` can switch personas mid-session.

## Suggested build order from here
1. Drop all new modules next to `ashley_ai_studio.py`.
2. Wire the `/chat/stream` endpoint into the dashboard's JS (fetch +
   ReadableStream) — the backend half is done, the display half isn't.
3. Swap `LLMBridge.SYS_PROMPT` for `personas.py`'s `get_persona()` and add
   a `persona <name>` shell command.
4. Run `ollama_blobs.py` and `system_monitor.py` standalone on your actual
   machine to sanity-check both against your real hardware/Ollama layout.
5. Wire `DraftVerifyEngine` into one command path in `AshleyShell`, test
   with two real local models.
6. Tackle `RAG_AUDIT.md` item 1 (chunking) — everything else there builds
   on top of it.
7. Swap `main()`'s launch-mode dispatch over to `VirtualDesktop` last —
   pure refactor, no behavior change, do it once everything else is stable.
8. TTS/STT, avatar livestreaming, and trained image/video generation are
   each their own project — see `COMPLETION_AUDIT.md` for the real building
   blocks (Coqui TTS/piper, whisper.cpp, diffusers) when you're ready to
   scope one of those separately.
