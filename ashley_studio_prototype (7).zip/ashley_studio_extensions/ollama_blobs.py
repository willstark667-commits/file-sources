#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ollama_blobs.py — Local Ollama Model Scanner
════════════════════════════════════════════════════════════════════════════
Reality check first, because this matters for what you can actually build:

  The `blobs/` folder (C:\\Users\\wills\\.ollama\\models\\blobs on your machine)
  contains SHA256-named files that are either:
    - GGUF model weight files (already trained, quantized, frozen), or
    - small JSON config/template/license files.
  There is no plain-text "content" to read out of a weights blob — it's
  packed tensors. You cannot "train your own language model" by scanning
  these files. What you CAN do, and what this module does, is walk the
  `manifests/` folder (sits next to blobs/) — those are small JSON files
  that map a model name+tag to its blob digests, size, parameter count,
  quantization level, and template. That's real, useful metadata for your
  ModelRouter to pick drafter vs. verifier models automatically (e.g. "give
  me the smallest model I have" or "give me anything with parameter_size
  containing '70b'").

  If you actually want to train something on your own data, the blobs
  aren't the input — your project files, conversation logs, and datasets
  are (which is exactly what your DatasetBuilder / KnowledgeGraph already
  target). This scanner is for *inventory*, not training data.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import json
import os
import platform
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional


@dataclass
class LocalModelInfo:
    name: str
    tag: str
    digest: str
    size_bytes: int
    param_size: str = "?"
    quantization: str = "?"
    family: str = "?"
    manifest_path: str = ""
    blob_paths: List[str] = field(default_factory=list)
    missing_blobs: List[str] = field(default_factory=list)

    @property
    def size_gb(self) -> float:
        return round(self.size_bytes / (1024 ** 3), 2)


def default_ollama_root() -> Path:
    """Best guess at ~/.ollama/models, honouring OLLAMA_MODELS env var first."""
    env = os.environ.get("OLLAMA_MODELS")
    if env:
        return Path(env)
    if platform.system() == "Windows":
        return Path(os.environ.get("USERPROFILE", str(Path.home()))) / ".ollama" / "models"
    return Path.home() / ".ollama" / "models"


class OllamaBlobScanner:
    """
    Scans <ollama_root>/manifests/**/<model>/<tag> (JSON files) and cross
    references digests against <ollama_root>/blobs/sha256-<digest>.

    Usage:
        scanner = OllamaBlobScanner()                 # auto-detect
        scanner = OllamaBlobScanner(root="D:/ollama")  # explicit path
        models = scanner.scan()
        for m in models:
            print(m.name, m.tag, m.size_gb, "GB", m.param_size, m.quantization)
    """

    def __init__(self, root: Optional[str] = None):
        self.root = Path(root) if root else default_ollama_root()
        self.manifests_dir = self.root / "manifests"
        self.blobs_dir = self.root / "blobs"

    def paths_ok(self) -> dict:
        return {
            "root": str(self.root),
            "root_exists": self.root.exists(),
            "manifests_exists": self.manifests_dir.exists(),
            "blobs_exists": self.blobs_dir.exists(),
        }

    def scan(self) -> List[LocalModelInfo]:
        if not self.manifests_dir.exists():
            return []
        results: List[LocalModelInfo] = []
        # Manifest layout: manifests/registry.ollama.ai/library/<model>/<tag>
        for manifest_file in self.manifests_dir.rglob("*"):
            if not manifest_file.is_file():
                continue
            try:
                data = json.loads(manifest_file.read_text(encoding="utf-8"))
            except Exception:
                continue  # not a manifest JSON (or unreadable)

            layers = data.get("layers", [])
            config = data.get("config", {})

            # tag is the filename, model name is the parent dir
            tag = manifest_file.name
            model_name = manifest_file.parent.name

            total_size = sum(l.get("size", 0) for l in layers) + config.get("size", 0)
            blob_paths, missing = [], []
            param_size = quantization = family = "?"

            for layer in layers:
                digest = layer.get("digest", "")
                blob_name = digest.replace(":", "-")  # "sha256:abcd" -> "sha256-abcd"
                blob_path = self.blobs_dir / blob_name
                if blob_path.exists():
                    blob_paths.append(str(blob_path))
                else:
                    missing.append(blob_name)
                media_type = layer.get("mediaType", "")
                if "params" in media_type.lower() or layer.get("size", 0) and param_size == "?":
                    # Ollama doesn't put param_size directly in the manifest layer;
                    # it lives in the model's own /api/show response. We surface
                    # what's available here and leave the rest to LLMBridge.list_models_detailed().
                    pass

            results.append(LocalModelInfo(
                name=model_name,
                tag=tag,
                digest=config.get("digest", ""),
                size_bytes=total_size,
                param_size=param_size,
                quantization=quantization,
                family=family,
                manifest_path=str(manifest_file),
                blob_paths=blob_paths,
                missing_blobs=missing,
            ))
        return results

    def summary(self) -> dict:
        models = self.scan()
        return {
            "paths": self.paths_ok(),
            "model_count": len(models),
            "total_size_gb": round(sum(m.size_gb for m in models), 2),
            "models": [
                {"name": m.name, "tag": m.tag, "size_gb": m.size_gb,
                 "missing_blobs": len(m.missing_blobs)}
                for m in models
            ],
        }


def enrich_with_api_details(models: List[LocalModelInfo], llm_bridge) -> List[LocalModelInfo]:
    """
    The manifest alone doesn't carry parameter_size/quantization/family —
    those come from Ollama's running /api/tags endpoint. If Ollama is up,
    merge that in (pass your existing LLMBridge instance in).
    """
    try:
        detailed = {d["name"]: d for d in llm_bridge.list_models_detailed()}
    except Exception:
        return models
    for m in models:
        full_name = f"{m.name}:{m.tag}"
        d = detailed.get(full_name) or detailed.get(m.name)
        if d:
            m.param_size = d.get("parameter_size", m.param_size)
            m.quantization = d.get("quantization", m.quantization)
            m.family = d.get("family", m.family)
    return models


if __name__ == "__main__":
    scanner = OllamaBlobScanner()
    print(json.dumps(scanner.summary(), indent=2))
