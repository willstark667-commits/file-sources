#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
draft_verify.py — Draft/Verify Engine for Ashley AI Studio
════════════════════════════════════════════════════════════════════════════
Plain-English -> real-technique glossary (so future-you knows what this file
actually implements when re-reading it in six months):

    "intern model"          -> DRAFTER  (small/fast model, or AdaptiveNGram)
    "boss / publisher"      -> VERIFIER (large model, has final say)
    "rejection sampling"    -> accept/reject test comparing drafter output
                                against verifier's own judgement
    "confidence scheduled"  -> draft chunk length shrinks/grows based on how
                                often the drafter's chunks are getting accepted
    "decay"                 -> repetition penalty applied per revision cycle
    "doesn't publish unless complete" -> PUBLISH_THRESHOLD gate below
    "parallel word guesses" -> see NOTE ON TRUE TOKEN-LEVEL SPECULATIVE
                                DECODING at the bottom of this file — this is
                                the one piece that's honestly out of reach of
                                Ollama's chat API today. Read that note.

This module has ZERO import-time dependency on ashley_ai_studio.py. It takes
an existing LLMBridge-like object (anything with a `.chat(message, model)`
method) so it drops straight into your refactor without circular imports.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import json
import re
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional, Protocol


# ── Minimal interface contract (structural typing, no hard import) ──────────
class ChatBackend(Protocol):
    def chat(self, message: str, model: str = None) -> str: ...


@dataclass
class DraftResult:
    text: str
    model: str
    cycle: int
    scores: dict = field(default_factory=dict)
    verdict: str = "pending"          # "publish" | "revise" | "reject"
    notes: str = ""


@dataclass
class PublishReport:
    final_text: str
    cycles_used: int
    history: List[DraftResult] = field(default_factory=list)
    published: bool = False


# ── Verifier scoring ─────────────────────────────────────────────────────────
_SCORE_KEYS = ("accuracy", "coherence", "code_quality", "efficiency", "overall")

_SCORE_PROMPT = """You are the PUBLISHER reviewing a draft written by a junior model (the intern).
Score the draft strictly. Respond with ONLY a JSON object, no prose, no markdown fences:

{{"accuracy": <0-100>, "coherence": <0-100>, "code_quality": <0-100 or null if not code>,
  "efficiency": <0-100>, "overall": <0-100>, "verdict": "publish"|"revise"|"reject",
  "notes": "<one short sentence, what to fix if not publish>"}}

ORIGINAL PROMPT:
{prompt}

DRAFT TO SCORE:
{draft}
"""

_REVISE_PROMPT = """You are the PUBLISHER. The intern's draft was scored "revise". Rewrite it,
fixing exactly what these notes say, keeping everything else the intern got right. Output
ONLY the corrected draft text — no preamble, no explanation.

NOTES: {notes}

ORIGINAL PROMPT:
{prompt}

DRAFT:
{draft}
"""


def _extract_json(text: str) -> Optional[dict]:
    """Verifier models sometimes wrap JSON in prose or fences despite instructions."""
    m = re.search(r"\{.*\}", text, re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


class DraftVerifyEngine:
    """
    Two-model (or model + AdaptiveNGram) pipeline:
      1. DRAFTER produces a fast, cheap draft.
      2. VERIFIER scores it across accuracy / coherence / code_quality / efficiency.
      3. If verdict != "publish", VERIFIER rewrites the flagged parts and we
         loop (this is your "editing / drafting / publishing cycles").
      4. Nothing leaves the engine until verdict == "publish" or cycles run out
         ("doesn't publish unless complete").

    PUBLISH_THRESHOLD gates the "overall" score required to auto-publish even
    if the model says "publish" — a cheap sanity backstop.
    """

    PUBLISH_THRESHOLD = 70
    MAX_CYCLES = 3

    def __init__(self, backend: ChatBackend, drafter_model: str, verifier_model: str,
                 ngram_fallback: Optional[Callable[[str], str]] = None):
        self.backend = backend
        self.drafter_model = drafter_model
        self.verifier_model = verifier_model
        # Optional callable, e.g. AdaptiveNGram.generate — used when Ollama is
        # unreachable so drafting never blocks on a network call.
        self.ngram_fallback = ngram_fallback

    # ── Drafting ─────────────────────────────────────────────────────────────
    def _draft(self, prompt: str, notes_from_prior_cycle: str = "") -> str:
        try:
            msg = prompt if not notes_from_prior_cycle else (
                f"{prompt}\n\n(Revise per this feedback: {notes_from_prior_cycle})"
            )
            return self.backend.chat(msg, model=self.drafter_model)
        except Exception:
            if self.ngram_fallback:
                return self.ngram_fallback(prompt)
            raise

    # ── Verification / scoring ──────────────────────────────────────────────
    def _score(self, prompt: str, draft: str) -> dict:
        raw = self.backend.chat(
            _SCORE_PROMPT.format(prompt=prompt, draft=draft),
            model=self.verifier_model,
        )
        parsed = _extract_json(raw)
        if not parsed:
            # Verifier didn't return clean JSON — fail safe to "revise" rather
            # than silently publishing unscored output.
            return {k: 0 for k in _SCORE_KEYS if k != "overall"} | {
                "overall": 0, "verdict": "revise",
                "notes": "verifier returned non-JSON, retry",
            }
        return parsed

    def _revise(self, prompt: str, draft: str, notes: str) -> str:
        return self.backend.chat(
            _REVISE_PROMPT.format(notes=notes, prompt=prompt, draft=draft),
            model=self.verifier_model,
        )

    # ── Public entry point ───────────────────────────────────────────────────
    def publish(self, prompt: str, max_cycles: Optional[int] = None) -> PublishReport:
        """Run the full draft -> score -> revise loop and return the report."""
        max_cycles = max_cycles or self.MAX_CYCLES
        history: List[DraftResult] = []
        notes = ""
        text = ""

        for cycle in range(1, max_cycles + 1):
            text = self._draft(prompt, notes_from_prior_cycle=notes)
            scores = self._score(prompt, text)
            verdict = scores.get("verdict", "revise")
            overall = scores.get("overall", 0) or 0
            result = DraftResult(text=text, model=self.drafter_model, cycle=cycle,
                                  scores=scores, verdict=verdict,
                                  notes=scores.get("notes", ""))
            history.append(result)

            if verdict == "publish" and overall >= self.PUBLISH_THRESHOLD:
                return PublishReport(final_text=text, cycles_used=cycle,
                                      history=history, published=True)

            if verdict == "reject":
                notes = scores.get("notes", "start over, prior attempt was off-target")
                continue  # full re-draft next cycle

            # verdict == "revise": publisher fixes it directly (this is the
            # "big model finalizes like a publisher" behaviour)
            notes = scores.get("notes", "")
            text = self._revise(prompt, text, notes)

        # Ran out of cycles — return best effort, flagged unpublished
        history.append(DraftResult(text=text, model=self.verifier_model,
                                    cycle=max_cycles + 1, verdict="unpublished",
                                    notes="max cycles exhausted"))
        return PublishReport(final_text=text, cycles_used=max_cycles,
                              history=history, published=False)


# ══════════════════════════════════════════════════════════════════════════
# NOTE ON TRUE TOKEN-LEVEL SPECULATIVE DECODING
# ══════════════════════════════════════════════════════════════════════════
# Real speculative decoding (what vLLM / TensorRT-LLM / llama.cpp's
# `--draft-model` flag do) works at the TOKEN level: the small model proposes
# N tokens autoregressively, then the big model scores all N in a single
# parallel forward pass and accepts the longest matching prefix. That needs
# direct access to logits/KV-cache, which Ollama's /api/chat endpoint does
# not expose.
#
# Two honest paths forward if you want the real thing rather than this
# chunk-level approximation:
#   1. Ollama's OpenAI-compatible endpoint (http://localhost:11434/v1) does
#      accept a `logprobs` field on /v1/completions for some models — worth
#      probing on your machine (`curl` it and check the response shape
#      before building on it, behavior varies by Ollama version/model).
#   2. Run llama.cpp's own server (llama-server) with --model-draft — it has
#      native speculative decoding built in and Ashley could just call it
#      instead of Ollama for this specific feature.
#
# The DraftVerifyEngine above gets you the *behavioral* win you described
# (fast draft, big model checks, doesn't publish incomplete work, scoring,
# cycles) without needing raw logit access. That's the realistic v1.
