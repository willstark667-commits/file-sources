#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ollama_perf.py — The real speed levers for local Ollama inference
════════════════════════════════════════════════════════════════════════════
Important honesty check first: no amount of Python wrapper code around
LLMBridge.chat() makes the model itself think faster. Generation speed is
governed almost entirely by these five things, in rough order of impact:

  1. num_gpu (GPU layer offload) — biggest single lever. If a model doesn't
     fully fit in VRAM, Ollama splits it between GPU and CPU, and the CPU
     portion is 10-50x slower per layer. Check with `ollama ps` while a
     model is loaded — it reports how much is on GPU vs CPU.
  2. Model size/quantization — a 7B Q4 model is dramatically faster than a
     13B Q8 model. Quantization (Q4_K_M vs Q8_0 vs f16) trades a little
     accuracy for a lot of speed/memory. This is a model *choice*, not a
     code fix.
  3. keep_alive — by default Ollama unloads a model from memory after 5
     minutes idle, so the NEXT message pays the full cold-load cost again
     (this compounds with the timeout issue from last session). Setting
     keep_alive higher keeps it resident.
  4. num_ctx (context window) — larger context = more memory + slower per-
     token generation, since attention cost grows with context length.
     Don't set this bigger than you actually need.
  5. num_thread — CPU thread count for the CPU-side portion of inference.
     Usually best left at physical core count; oversubscribing hurts.

None of these are things this script can change on the server — they're
request-level options you send to Ollama's API, or environment variables
you set before `ollama serve` starts. This module wires them into requests;
it can't override deeper defaults Ollama enforces server-side.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import json
import time
import urllib.request as ur
from dataclasses import dataclass


@dataclass
class OllamaPerfConfig:
    keep_alive: str = "30m"     # keep model resident 30 min instead of default 5m
    num_ctx: int = 4096         # only raise if you actually need longer context
    num_gpu: int = -1           # -1 = let Ollama decide layer split automatically
    num_thread: int = 0         # 0 = let Ollama pick (usually physical core count)

    def as_options(self, num_predict: int = 2048, temperature: float = 0.7) -> dict:
        opts = {"temperature": temperature, "num_predict": num_predict,
                "num_ctx": self.num_ctx}
        if self.num_gpu >= 0:
            opts["num_gpu"] = self.num_gpu
        if self.num_thread > 0:
            opts["num_thread"] = self.num_thread
        return opts


def benchmark_model(base_url: str, model: str, prompt: str = "Write one sentence.",
                     num_predict: int = 100) -> dict:
    """
    Quick round-trip timing so you can compare models/settings on YOUR
    hardware instead of guessing. Run once per model after a warm-up call
    (first call always includes load time — call twice, keep the second).
    """
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "stream": False,
        "options": {"num_predict": num_predict, "temperature": 0.0},
    }).encode()
    req = ur.Request(f"{base_url}/api/chat", data=payload, method="POST",
                      headers={"Content-Type": "application/json"})
    start = time.time()
    with ur.urlopen(req, timeout=180) as resp:
        data = json.loads(resp.read())
    elapsed = time.time() - start
    eval_count = data.get("eval_count", 0)
    eval_duration_ns = data.get("eval_duration", 0)
    tokens_per_sec = (eval_count / (eval_duration_ns / 1e9)) if eval_duration_ns else None
    return {
        "model": model, "wall_time_s": round(elapsed, 2),
        "tokens_generated": eval_count,
        "tokens_per_sec": round(tokens_per_sec, 1) if tokens_per_sec else None,
        "load_duration_s": round(data.get("load_duration", 0) / 1e9, 2),
    }


if __name__ == "__main__":
    import sys
    base = "http://localhost:11434"
    model = sys.argv[1] if len(sys.argv) > 1 else "mistral"
    print(f"Warming up {model}...")
    benchmark_model(base, model, num_predict=1)  # discard, just loads it
    print(f"Benchmarking {model}...")
    print(json.dumps(benchmark_model(base, model), indent=2))
