; ashley_studio_setup.iss — Inno Setup script for Ashley AI Studio
; ══════════════════════════════════════════════════════════════════════════
; Reality check: this script needs to be COMPILED with Inno Setup itself
; (a Windows GUI tool, free from jrsoftware.org) — I can't compile a .exe
; from this Linux sandbox, only write the script that Inno Setup turns into
; one. Steps on your end:
;   1. Install Inno Setup: https://jrsoftware.org/isdl.php
;   2. Put this file next to your project folder (or edit SourceDir below)
;   3. Open this .iss in Inno Setup's IDE, click Build > Compile
;   4. The installer .exe lands in the Output/ folder this script creates
;
; This assumes your project's built with PyInstaller into a single folder
; first (Inno Setup packages files, it doesn't bundle Python itself) —
; see the PyInstaller note at the bottom if you haven't done that step yet.
; ══════════════════════════════════════════════════════════════════════════

#define MyAppName "Ashley AI Studio"
#define MyAppVersion "3.0"
#define MyAppPublisher "William S."
#define MyAppExeName "AshleyStudio.exe"
; Change this to wherever your PyInstaller `dist\AshleyStudio\` folder is:
#define SourceDir "dist\AshleyStudio"

[Setup]
AppId={{A17E5EE0-ASH1-4A17-9CD0-ASHLEYSTUDIO1}}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir=Output
OutputBaseFilename=AshleyStudio_Setup_v{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
; Change to your own icon (.ico) if you have one for the CRT/amber theme:
; SetupIconFile=assets\ashley_icon.ico
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"
Name: "installollama"; Description: "Check for Ollama and offer to install it if missing"; GroupDescription: "Dependencies:"

[Files]
; Pulls in everything PyInstaller produced — .exe, bundled Python runtime,
; and any DLLs it collected. Adjust SourceDir above if your build output
; folder is named differently.
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; Ship a default config/requirements alongside, if you keep one outside the exe bundle:
; Source: "requirements.txt"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
; Optional: offer to launch right after install finishes
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent

[Code]
// Checks if Ollama's default port responds; if not, offers to open the
// Ollama download page. This is a best-effort convenience check, not a
// real dependency installer — Inno Setup's scripting (Pascal) can't run
// arbitrary installers cleanly without its own separate installer package.
function IsOllamaLikelyInstalled(): Boolean;
begin
  Result := FileExists(ExpandConstant('{localappdata}\Programs\Ollama\ollama app.exe'))
    or FileExists('C:\Program Files\Ollama\ollama app.exe');
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if (CurStep = ssPostInstall) and WizardIsTaskSelected('installollama') then
  begin
    if not IsOllamaLikelyInstalled() then
    begin
      if MsgBox('Ollama was not found on this system. {#MyAppName} needs it '
        + 'to run any AI features. Open the Ollama download page now?',
        mbConfirmation, MB_YESNO) = IDYES then
        ShellExec('open', 'https://ollama.ai/download', '', '', SW_SHOW, ewNoWait, 0);
    end;
  end;
end;

; ══════════════════════════════════════════════════════════════════════════
; BEFORE this script works, you need a PyInstaller build. One-time setup:
;
;   pip install pyinstaller
;   pyinstaller --name AshleyStudio --onedir --windowed ^
;       --add-data "assets;assets" ashley_ai_studio.py
;
; That produces dist\AshleyStudio\AshleyStudio.exe plus its dependencies —
; THAT folder is what SourceDir above should point to. --onedir (not
; --onefile) is deliberate: --onefile unpacks to a temp folder on every
; launch, which directly fights your "faster boot" goal from earlier.
;
; Common PyInstaller gotchas for a project this size (worth checking before
; you package):
;   - Tkinter usually bundles automatically; Flask/pywebview sometimes need
;     --hidden-import flags if PyInstaller misses a dynamically-imported
;     submodule (you'll see this as an ImportError only in the built .exe,
;     not when running the plain .py — always test the exe, not just the script).
;   - ChromaDB/SentenceTransformers, if used, are large — expect a
;     multi-hundred-MB dist folder. Ollama itself is NOT bundled (correctly)
;     since it's a separate program the user installs once, not part of
;     your app's package.
; ══════════════════════════════════════════════════════════════════════════
