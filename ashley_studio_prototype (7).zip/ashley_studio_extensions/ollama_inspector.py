#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ollama_inspector.py — What is the Ollama process actually doing?
════════════════════════════════════════════════════════════════════════════
Answers your "detect code and directory and registry of ollama running in
the background" ask, using the same safe, read-only OS APIs as
system_monitor.py — no reverse engineering of Ollama's internals, no
injecting into its process, just what psutil can see about any running
process: its binary path, working directory, open network ports, memory/CPU
use, and (where the OS allows it) loaded shared libraries.

Note on scope: this reads process metadata, not Ollama's source code. If you
want to actually read Ollama's own code, that's on GitHub (ollama/ollama,
mostly Go) — a running-process inspector like this can't show you source,
only what the compiled binary is doing right now.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import platform
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class OllamaProcessInfo:
    found: bool
    pid: Optional[int] = None
    exe_path: str = ""
    working_dir: str = ""
    cmdline: List[str] = field(default_factory=list)
    memory_mb: float = 0.0
    cpu_percent: float = 0.0
    open_ports: List[int] = field(default_factory=list)
    loaded_libraries: List[str] = field(default_factory=list)
    child_processes: List[int] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


class OllamaInspector:
    def find_process(self) -> OllamaProcessInfo:
        try:
            import psutil
        except ImportError:
            return OllamaProcessInfo(found=False, notes=["psutil not installed — pip install psutil"])

        target = None
        for proc in psutil.process_iter(["pid", "name", "exe", "cwd", "cmdline"]):
            try:
                name = (proc.info.get("name") or "").lower()
                if "ollama" in name:
                    target = proc
                    break
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if not target:
            return OllamaProcessInfo(found=False, notes=["No process with 'ollama' in its name is currently running."])

        info = OllamaProcessInfo(found=True, pid=target.pid)
        try:
            info.exe_path = target.exe() or ""
            info.working_dir = target.cwd() or ""
            info.cmdline = target.cmdline()
            mem = target.memory_info()
            info.memory_mb = round(mem.rss / (1024 ** 2), 1)
            info.cpu_percent = target.cpu_percent(interval=0.3)
            info.child_processes = [c.pid for c in target.children(recursive=True)]
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            info.notes.append(f"Some fields unavailable (permissions): {e}")

        # Open network ports — this is how you confirm it's actually listening
        # on 11434 (or wherever OLLAMA_HOST points it) rather than guessing.
        try:
            for conn in target.connections(kind="inet"):
                if conn.status == psutil.CONN_LISTEN and conn.laddr:
                    info.open_ports.append(conn.laddr.port)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            info.notes.append("Couldn't read open ports (may need admin/sudo on this OS).")

        # Loaded shared libraries — Linux/macOS via psutil, Windows via a
        # separate best-effort check since psutil doesn't expose DLLs directly.
        try:
            if platform.system() != "Windows":
                info.loaded_libraries = list(target.memory_maps())[:0]  # placeholder, see below
                maps = target.memory_maps()
                libs = {m.path for m in maps if m.path and (m.path.endswith(".so") or ".so." in m.path)}
                info.loaded_libraries = sorted(libs)[:40]  # cap — this list can be huge
            else:
                info.notes.append("DLL enumeration on Windows needs a separate tool "
                                  "(e.g. Process Explorer's DLL view) — psutil doesn't "
                                  "expose loaded modules on Windows directly.")
        except (psutil.NoSuchProcess, psutil.AccessDenied, NotImplementedError):
            info.notes.append("Couldn't enumerate loaded libraries on this OS/permission level.")

        return info

    def summary_text(self, info: Optional[OllamaProcessInfo] = None) -> str:
        info = info or self.find_process()
        if not info.found:
            return "Ollama is not currently running. " + " ".join(info.notes)
        lines = [
            f"Ollama running as PID {info.pid}",
            f"  Binary:      {info.exe_path or '(permission denied)'}",
            f"  Working dir: {info.working_dir or '(permission denied)'}",
            f"  Command:     {' '.join(info.cmdline) if info.cmdline else '(unavailable)'}",
            f"  Memory:      {info.memory_mb} MB",
            f"  CPU:         {info.cpu_percent}%",
            f"  Listening on ports: {info.open_ports or '(none found / permission denied)'}",
            f"  Child processes: {len(info.child_processes)} (model runner subprocesses, typically)",
        ]
        if info.loaded_libraries:
            lines.append(f"  Loaded libraries (first {len(info.loaded_libraries)}):")
            lines.extend(f"    {lib}" for lib in info.loaded_libraries[:10])
            if len(info.loaded_libraries) > 10:
                lines.append(f"    ... and {len(info.loaded_libraries) - 10} more")
        for note in info.notes:
            lines.append(f"  Note: {note}")
        return "\n".join(lines)


if __name__ == "__main__":
    print(OllamaInspector().summary_text())
