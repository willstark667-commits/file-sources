# RAG System Audit — Ashley AI Studio

Reviewed: `VectorIndex`, `KnowledgeGraph`, `DatasetBuilder`, `AdvancedScanner`, `classify_text`.

## What's already working
- `VectorIndex` correctly tries ChromaDB + SentenceTransformers first and
  degrades to a keyword-substring fallback — good defensive design for a
  self-hosted tool that shouldn't hard-fail if deps are missing.
- `index_from_db()` pulls straight from your `knowledge_index` SQLite table,
  so scanning → indexing is already one clean pipeline.
- `classify_text()` gives you a cheap logic/dream split with zero external
  dependencies — fine as a lightweight router signal.

## Real gaps (in priority order)

**1. No chunking — you're embedding whole-file summaries, not content.**
`index_from_db()` embeds `"{filepath} | {summary}"`, not the actual file
text. For code files this is fine for "which file does X" lookups, but it
means the vector index can't answer "show me the function that does Y" —
only "which file is about Y". Fix: add a `chunk_and_index()` pass that reads
each file, splits by function/class boundaries (you already have an AST
scanner in `AdvancedScanner` — reuse its parsed spans instead of writing a
new chunker), and embeds each chunk separately with `{filepath}:{lineno}` as
metadata.

**2. No re-ranking.** `search()` returns raw ChromaDB nearest-neighbor
results with no second pass. For a personal codebase this is usually fine at
low `top_k`, but if you extend this to the "search and inject website text as
drafts" idea, you'll want a cheap re-rank step (e.g. score returned chunks
with `classify_text` + a keyword-overlap score) before handing results to the
LLM, or irrelevant near-neighbors will pollute the prompt.

**3. Fallback path has no vector similarity at all.** When ChromaDB is
unavailable, `search()` does substring matching only — no ranking, no
partial-match scoring. This is the harder case to fix well without adding a
dependency; if you want a same-notebook fallback bump: run `hashlib`-based
MinHash or a TF-IDF (`sklearn` is heavier, but pure-Python TF-IDF over your
own corpus is ~40 lines) so the no-ChromaDB path still ranks results instead
of returning them in filesystem order.

**4. No de-duplication or staleness handling.** `index_from_db()` calls
`upsert`, so re-running won't duplicate — good. But there's no invalidation
when a file changes: if `AdvancedScanner` re-scans and updates
`knowledge_index`, the vector store keeps the old embedding until you
manually re-run indexing. Worth adding a `last_indexed_at` timestamp compared
against file mtime, so `--index` only re-embeds what changed (this also
directly fixes your "faster boot time" concern — most of your boot cost on a
big project is redundant re-embedding).

**5. `KnowledgeGraph` and `VectorIndex` don't talk to each other.** Graph
edges (imports, calls, references) aren't used to expand vector search
results (e.g. "also pull in files this one imports"). This is the single
highest-value connection to make if you want RAG that understands your
project's actual structure instead of just semantic similarity — a
graph-hop expansion after the initial vector hit is a common, well-tested
RAG pattern (sometimes called "graph RAG").

## Recommended next build (concrete, not conceptual)
In priority order: (1) chunk-level indexing reusing `AdvancedScanner`'s AST
spans, (2) mtime-based re-index skip, (3) graph-hop expansion joining
`KnowledgeGraph` edges onto vector hits. Re-ranking and TF-IDF fallback are
lower priority — only worth it once you're regularly hitting the ChromaDB-
unavailable path in practice.
