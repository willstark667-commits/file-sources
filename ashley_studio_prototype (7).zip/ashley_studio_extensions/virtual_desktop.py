#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
virtual_desktop.py — Virtual Desktop Orchestration Layer
════════════════════════════════════════════════════════════════════════════
Terminology note: your codebase never actually had a module called "kernel" —
the only "kernel" references in ashley_ai_studio.py are Windows' own
kernel32.dll calls (_win_bootstrap, console codepage setup). Those are OS API
calls and must stay named exactly that; renaming them would break ctypes
lookups. What you're really asking to rename is the *conceptual* core of the
program — the thing that decides "launch GUI, or shell, or web dashboard,
or run --scan" — from an informal "kernel" idea into an explicit
"Virtual Desktop" concept: one environment, multiple interchangeable
front-ends (windows/panes), matching your CRT-terminal aesthetic goals.

This module is that layer. It doesn't replace launch_gui/launch_web/
AshleyShell — it wraps them as "workspaces" you can register, list, and
switch between, so main()'s job shrinks to "boot the VirtualDesktop and
open a workspace" instead of a long if/elif chain.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional


@dataclass
class Workspace:
    """One pluggable front-end: gui, shell, web, or anything you add later."""
    key: str
    label: str
    launch: Callable[..., None]
    description: str = ""


class VirtualDesktop:
    """
    Central registry + launcher for all front-ends. Replaces the informal
    "kernel decides what to boot" idea with an explicit, inspectable object.

        vd = VirtualDesktop()
        vd.register("gui",   "Tkinter GUI",      launch_gui,   "Full desktop window")
        vd.register("shell", "Terminal shell",   AshleyShell().run, "Rich terminal")
        vd.register("web",   "Flask dashboard",  launch_web,   "Browser dashboard")
        vd.open("gui", default_model="mistral")
    """

    def __init__(self):
        self._workspaces: Dict[str, Workspace] = {}
        self._active: Optional[str] = None
        self._history: List[str] = []

    def register(self, key: str, label: str, launch_fn: Callable[..., None],
                 description: str = "") -> None:
        self._workspaces[key] = Workspace(key=key, label=label,
                                           launch=launch_fn, description=description)

    def list_workspaces(self) -> List[dict]:
        return [{"key": w.key, "label": w.label, "description": w.description}
                for w in self._workspaces.values()]

    def open(self, key: str, **kwargs) -> None:
        if key not in self._workspaces:
            available = ", ".join(self._workspaces) or "(none registered)"
            raise KeyError(f"No workspace '{key}' registered. Available: {available}")
        self._active = key
        self._history.append(key)
        self._workspaces[key].launch(**kwargs)

    @property
    def active(self) -> Optional[str]:
        return self._active

    @property
    def history(self) -> List[str]:
        return list(self._history)


def build_default_desktop(launch_gui, launch_web, shell_cls) -> VirtualDesktop:
    """
    Convenience wiring for ashley_ai_studio.py's existing entry points.
    Call from main() like:

        from virtual_desktop import build_default_desktop
        vd = build_default_desktop(launch_gui, launch_web, AshleyShell)
        vd.open(args.mode, default_model=args.model)   # mode in {"gui","shell","web"}
    """
    vd = VirtualDesktop()
    vd.register("gui", "Tkinter GUI", launch_gui,
                "Full windowed desktop — CRT theme, panes, drag-drop")
    vd.register("web", "Flask dashboard", launch_web,
                "Browser dashboard — media studio, remote access")
    vd.register("shell", "Terminal shell", lambda **kw: shell_cls().run(**kw),
                "Rich terminal — scripting, low-resource machines")
    return vd
