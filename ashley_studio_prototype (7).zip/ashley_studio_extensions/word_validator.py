#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
word_validator.py — Real-word filtering for generated tokens/text
════════════════════════════════════════════════════════════════════════════
This replaces the "generate every combination of letters until they're all
built" idea. That approach is combinatorially unbounded (no stopping point,
and >99.9% of output would be nonsense) — this does the equivalent job the
way it's actually solvable: check candidate strings against a known-word
vocabulary, with an optional LLM call as a second-opinion backstop for
words the static list doesn't have (names, slang, technical terms).
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Set


_WORD_RE = re.compile(r"^[a-zA-Z][a-zA-Z'\-]*$")


@dataclass
class ValidationResult:
    text: str
    is_word: bool
    source: str          # "wordlist" | "llm" | "heuristic" | "not_found"
    confidence: float     # 0.0-1.0


class WordValidator:
    """
    Usage:
        wv = WordValidator()                       # tries common system wordlists
        wv = WordValidator(wordlist_path="my.txt")  # or point at your own list

        wv.check("hello")          -> ValidationResult(is_word=True, source="wordlist")
        wv.check("xqzt")           -> ValidationResult(is_word=False, source="not_found")
        wv.check("blorptastic", llm_bridge=bridge)  -> falls back to asking the LLM
    """

    # Common locations a real English wordlist already sits on most systems —
    # no download needed if any of these exist.
    _CANDIDATE_PATHS = [
        "/usr/share/dict/words",              # macOS / most Linux distros
        "/usr/share/dict/american-english",
        "/usr/dict/words",
    ]

    def __init__(self, wordlist_path: Optional[str] = None):
        self._words: Set[str] = set()
        path = wordlist_path or next(
            (p for p in self._CANDIDATE_PATHS if Path(p).exists()), None
        )
        self.wordlist_path = path
        if path:
            try:
                with open(path, "r", encoding="utf-8", errors="ignore") as f:
                    self._words = {line.strip().lower() for line in f if line.strip()}
            except Exception:
                self._words = set()

    @property
    def loaded_word_count(self) -> int:
        return len(self._words)

    def _looks_like_a_word(self, token: str) -> bool:
        """Cheap structural heuristic used only when there's no wordlist and
        no LLM available — checks shape (letters only, has a vowel, no
        absurd consonant runs), not meaning."""
        if not _WORD_RE.match(token):
            return False
        low = token.lower()
        if not any(v in low for v in "aeiouy"):
            return False
        if re.search(r"[bcdfghjklmnpqrstvwxz]{5,}", low):
            return False
        return True

    def check(self, token: str, llm_bridge=None) -> ValidationResult:
        low = token.strip().lower()
        if not low:
            return ValidationResult(token, False, "not_found", 0.0)

        if self._words:
            found = low in self._words
            return ValidationResult(token, found,
                                     "wordlist" if found else "not_found",
                                     1.0 if found else 0.0)

        if llm_bridge is not None:
            try:
                reply = llm_bridge.chat(
                    f'Is "{token}" a real English word (or a common proper noun)? '
                    f'Answer with exactly one word: YES or NO.'
                )
                said_yes = reply.strip().upper().startswith("YES")
                return ValidationResult(token, said_yes, "llm", 0.75 if said_yes else 0.25)
            except Exception:
                pass  # fall through to heuristic

        ok = self._looks_like_a_word(token)
        return ValidationResult(token, ok, "heuristic", 0.4 if ok else 0.1)

    def filter_real_words(self, tokens: list[str], llm_bridge=None) -> list[str]:
        return [t for t in tokens if self.check(t, llm_bridge=llm_bridge).is_word]


if __name__ == "__main__":
    wv = WordValidator()
    print(f"Loaded {wv.loaded_word_count} words from: {wv.wordlist_path}")
    for sample in ("hello", "computer", "xqzttp", "the", "blorptastic"):
        r = wv.check(sample)
        print(f"  {sample!r:16} -> is_word={r.is_word} source={r.source}")
