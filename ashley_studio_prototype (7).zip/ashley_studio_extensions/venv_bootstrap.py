#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
venv_bootstrap.py — Auto-create and use a virtual environment
════════════════════════════════════════════════════════════════════════════
Drop this import at the very top of ashley_ai_studio.py's main() (before any
heavy imports). On first run it creates a venv, installs from
requirements.txt (auto-generating a sane one if you don't have one yet),
then RE-EXECS the same script inside that venv — so every subsequent run
after the first launches straight in, already isolated from your system
Python, no manual `source venv/bin/activate` step needed.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path
from typing import Optional

VENV_DIR_NAME = ".ashley_venv"

# Only the packages your actual code paths import today. Do NOT include
# torch/tensorflow/transformers here — see the note at the bottom of this
# file for when (if ever) you'd actually need them.
DEFAULT_REQUIREMENTS = [
    "flask",
    "pywebview",
    "opencv-python",
    "chromadb",
    "sentence-transformers",
    "psutil",
]


def _venv_python(venv_dir: Path) -> Path:
    if sys.platform == "win32":
        return venv_dir / "Scripts" / "python.exe"
    return venv_dir / "bin" / "python"


def _already_in_venv() -> bool:
    return sys.prefix != sys.base_prefix


def ensure_requirements_file(project_root: Path) -> Path:
    req_path = project_root / "requirements.txt"
    if not req_path.exists():
        req_path.write_text("\n".join(DEFAULT_REQUIREMENTS) + "\n")
        print(f"[venv_bootstrap] No requirements.txt found — wrote a default one at {req_path}")
    return req_path


def ensure_venv_and_relaunch(project_root: Optional[str] = None) -> None:
    """
    Call this as the FIRST line of your script's entrypoint. If we're
    already running inside the venv, it returns immediately (no-op). If not,
    it creates the venv (first run only), installs requirements, and
    re-executes the current script inside it — this function never returns
    in that case, the process is replaced via os.execv.
    """
    if _already_in_venv():
        return  # already isolated, nothing to do

    root = Path(project_root) if project_root else Path(sys.argv[0]).resolve().parent
    venv_dir = root / VENV_DIR_NAME
    py = _venv_python(venv_dir)

    if not py.exists():
        print(f"[venv_bootstrap] Creating virtual environment at {venv_dir} (first run only)...")
        subprocess.run([sys.executable, "-m", "venv", str(venv_dir)], check=True)
        req_path = ensure_requirements_file(root)
        print("[venv_bootstrap] Installing dependencies (this may take a minute)...")
        subprocess.run([str(py), "-m", "pip", "install", "--upgrade", "pip"], check=False)
        subprocess.run([str(py), "-m", "pip", "install", "-r", str(req_path)], check=False)
        print("[venv_bootstrap] Environment ready.")

    print(f"[venv_bootstrap] Relaunching inside venv: {py}")
    os.execv(str(py), [str(py)] + sys.argv)  # replaces this process, never returns


# ══════════════════════════════════════════════════════════════════════════
# DO YOU NEED numpy / torch / tensorflow / transformers / CUDA?
# ══════════════════════════════════════════════════════════════════════════
# Answer for what's actually built today: NO. Your current architecture
# talks to Ollama over HTTP — Ollama does all model inference in its own
# separate process (compiled Go/C++, its own CUDA usage). Your Python code
# never touches a tensor directly, so torch/tensorflow/CUDA-in-Python
# aren't dependencies of anything that exists yet.
#
# You WOULD need them only if you build one of these specific things:
#   - Local Stable Diffusion via `diffusers`      -> needs torch + CUDA
#   - Custom pose estimation via MediaPipe        -> needs opencv + mediapipe
#   - Training/fine-tuning any model yourself      -> needs torch/transformers
#   - Whisper.cpp for STT                          -> no Python torch needed,
#                                                       it's a standalone binary
#
# Recommendation: don't add these to requirements.txt speculatively. Add
# each only when you start the specific feature that needs it — they're
# multi-GB installs (especially torch+CUDA) and slow your setup/boot time
# for capabilities you're not using yet, which is the opposite of what
# you're asking for with "faster boot."
