class DaemonManager:
    def start(self):
        print('Daemons started')
