class EventBus:
    pass
