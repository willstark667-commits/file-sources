from ai.assistant import Assistant
from daemons.daemon_manager import DaemonManager

DaemonManager().start()
Assistant().start()
