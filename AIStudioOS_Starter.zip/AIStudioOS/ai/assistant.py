class Assistant:
    def start(self):
        print('AI Studio OS online')
