# NanoBrain — miniature internal neural network prototype (Ashley build)

A small, honest, actually-running prototype of the "internal neural
network agent" concept, now with a persona ("Ashley"), auto-growth,
a 2D visualizer, and a chat tab wired to Ollama.

## What this is
- A **few nodes** (3–8), each with its own ID, vectors, and its own
  storage folder under `data/node_XXX/` (files, training log, assigned
  file manifest).
- **Auto-growth**: `autogrow` scans your workspace, *predicts* how many
  nodes the data needs plus an ETA, spawns them **one at a time**
  (live in the 2D visualizer), divides the scanned files across nodes,
  then pretrains each node **one at a time**, logging exactly which
  files/how many each node trained on, including a "grokking" extra
  pass when a node converges well.
- A **2D visualizer** tab: circles = nodes, lines = the connections
  between them, glow/pulse when active, brightness tied to confidence.
  "Add Node" / "Pulse" buttons for manual control.
- A **Chat tab** ("Ashley"): chatbox + persisted history, file
  attachment, and a voice toggle that clearly shows LIVE/off. Routes
  through **Ollama** (used here as the actual language/management
  backend) with Ashley's persona as the system prompt; falls back to a
  labeled toy-network response if Ollama isn't running, rather than
  pretending to be smart without it.
- A **persona system** (`persona.py`): Ashley's traits are weighted
  percentages, plus a **keyword tracker** that scans scan-previews,
  chat messages, and attachments for Ashley/Cortana/persona-related
  terms and lets you add more (`addkeyword`).
- **Voice** (`voice.py`): generic TTS/STT via `pyttsx3` /
  `SpeechRecognition`, auto-installed by the launcher if missing.
  This wraps *generic* synthetic voice engines — it does not clone or
  reproduce any specific real person's voice.

## Honest scope / realism note
See the chat message this shipped with for the full breakdown, in
short: the node/scan/training scaffolding here is real and running.
The *intelligence* behind Ashley's replies is Ollama's, routed through
this persona/memory layer — the hand-written neuron chain itself only
does a toy bit-prediction task, not language understanding. That's the
correct division of labor (net = decision/identity layer, Ollama =
language capability), not a shortcut.

## Running it
```bash
python3 launcher.py
# or, to skip auto-installing the optional voice packages:
python3 launcher.py --no-auto-install
```
Core (Shell/Network/Chat + Ollama bridge) is standard-library only.
Voice is optional and degrades gracefully if not installed.
For real chat replies, run `ollama serve` with a model pulled (default
expected: `llama3` — change `OLLAMA_MODEL` in `nanobrain/config.py`).

## Shell commands
```
status                 network status / maturity %
nodes                  list nodes: confidence, files, assigned counts
scan [path]            read-only scan + index a directory
search <keyword>       search the scan index
autogrow               predict node count + ETA, grow one at a time,
                       divide files across nodes, pretrain one at a time
pretrain               phase 1, all nodes at once (no file division)
train                  phase 2 joint training
predict <0|1>          feed a bit through the chain
grow                   add a single node
save / load            checkpoint the network
keywords               show the Ashley-keyword tracker report
addkeyword <word>      track a new keyword
voice [on|off]         toggle voice, show status
clear / exit
```

## Layout
```
NanoBrain/
├── launcher.py        # checks tkinter, auto-installs optional voice deps
├── requirements.txt
├── nanobrain/
│   ├── config.py       # all paths anchored to __file__, not cwd
│   ├── neuron.py         # node: vectors, weight/bias, own folder, training log
│   ├── network.py         # wiring, autogrow/ETA, file division, grokking, status
│   ├── scanner.py           # non-destructive file indexer
│   ├── persona.py            # Ashley traits + keyword tracker
│   ├── chat.py                 # chat history persistence
│   ├── ollama_bridge.py          # stdlib-only Ollama HTTP client
│   ├── voice.py                   # optional TTS/STT, graceful fallback
│   └── gui.py                      # Tkinter: Shell / Network / Chat tabs
├── data/            (runtime: per-node folders, checkpoint, persona, chat, keywords)
├── workspace/        (runtime: default scan target)
└── logs/
```

