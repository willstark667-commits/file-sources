# Ashley AI Studio - Code Graph & Import Blueprint

This document outlines the complete architectural blueprint, layout, and all code/script imports used across the Ashley AI Studio ecosystem.

## 1. Core Dependencies & Imports
The following libraries are required to run the full suite of AI models, GUI, and tools:

### Standard Library Imports (Built-in)
- `os`, `sys`: File system and path routing.
- `json`, `ast`: Data parsing and code graphing.
- `math`, `random`: Probability engines and heuristic calculations.
- `collections` (`deque`): Memory buffers for Q-Learning.
- `traceback`, `logging`: Advanced console routing and error handling.

### Third-Party Imports (External)
- `torch`, `torch.nn`, `torch.optim`: PyTorch for the Transformer Model and Deep Q-Networks.
- `numpy`: Matrix math and tensor manipulation for RAG.
- `sklearn.metrics.pairwise` (`cosine_similarity`): Semantic vector search.
- `webview`: PyWebView for the modern HTML/CSS/JS frontend shell.
- `pygame`: Fallback shell and 3D virtual environment rendering.
- `requests`, `bs4` (`BeautifulSoup`): Web research and internal browser scraping.
- `networkx`, `matplotlib`: Advanced knowledge graph visualization.

## 2. Architectural Layout & Blueprint

### Frontend (The Shell)
- **`gui/pyweb_shell.py`**: The main PyWebView server. Renders the UI.
- **`gui/web/index.html`**: The HTML/CSS/JS layout containing tabs for Chat, Arena, Tools, and Settings.
- **`gui/media_viewer.py`**: Handles image, audio, and video rendering.

### Backend (The Engine)
- **`core/modules/module_manager.py`**: The "Hooks & Wheels" bridge. Connects frontend JS calls to backend Python functions.
- **`engine/omni/console_router.py`**: Catches tracebacks, routes terminal commands, and prevents crashes.
- **`engine/ml_core/`**: The Deep Learning Core.
  - `transformer_model.py`: The PyTorch LLM architecture.
  - `q_learning_agent.py`: Reinforcement learning for tool selection.
  - `tensor_rag.py`: Vector embeddings for uploaded files.

### The Bridge (Hooks & Wheels)
- **Wheels**: Pluggable modules (e.g., Voice Studio, Chess Arena) that can be loaded or unloaded dynamically.
- **Hooks**: Event listeners. When the frontend sends a message, a hook triggers the LLM, the Omni-Logger, and the Voice Synthesizer simultaneously.
- **Handles**: Direct API routes exposed to the PyWebView frontend.