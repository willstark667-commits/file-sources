import os
import zipfile

def unpack_all():
    """
    Standalone unpacker script.
    Finds all Phase zips in the current directory, extracts them sequentially,
    and builds the full Ashley AI Studio program.
    """
    print("==================================================")
    print("       Ashley AI Studio - Full Builder            ")
    print("==================================================")
    
    target_dir = "Ashley_AI_Studio_Full"
    os.makedirs(target_dir, exist_ok=True)
    
    # Find all phase zips
    zips = [f for f in os.listdir('.') if f.startswith('Ashley_AI_Studio_Phase') and f.endswith('.zip')]
    zips.sort() # Ensure chronological order (Phase 4, Phase 5, Phase 6, Phase 7)
    
    if not zips:
        print("No Phase zips found in the current directory!")
        return
        
    for zip_name in zips:
        print(f"Unpacking {zip_name}...")
        with zipfile.ZipFile(zip_name, 'r') as zip_ref:
            zip_ref.extractall(target_dir)
            
    print(f"\n[Success] Full program built successfully in ./{target_dir}/")
    print(f"To run the studio, execute:")
    print(f"  cd {target_dir}/Ashley_AI_Studio")
    print(f"  python setup_and_launch.py")

if __name__ == "__main__":
    unpack_all()