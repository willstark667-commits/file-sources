import json
import os

class SystemConfigManager:
    """
    Manages graphics, refresh rates, FPS, and DLL paths for the Pygame/Pyglet shell.
    Handles menu cycles, loops, and transition timings.
    """
    def __init__(self, config_path="config/settings.json"):
        self.config_path = config_path
        self.settings = {
            "graphics": {
                "resolution": (1920, 1080),
                "fps_cap": 60,
                "auto_refresh": True,
                "refresh_interval_ms": 16, # ~60fps
                "shaders_enabled": True,
                "theme": "dark"
            },
            "system": {
                "dll_paths": ["/usr/lib", "C:\\Windows\\System32"],
                "menu_transition_speed": 0.3,
                "power_saver_mode": False
            },
            "audio": {
                "tts_enabled": True,
                "stt_enabled": True,
                "volume": 0.8
            }
        }
        self.load_config()

    def load_config(self):
        if os.path.exists(self.config_path):
            with open(self.config_path, 'r') as f:
                loaded = json.load(f)
                self.settings.update(loaded)
        else:
            self.save_config()

    def save_config(self):
        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(self.settings, f, indent=4)

    def update_setting(self, category, key, value):
        if category in self.settings and key in self.settings[category]:
            self.settings[category][key] = value
            self.save_config()
            print(f"[Config] Updated {category}.{key} to {value}")