import os

class MediaViewer:
    """
    A unified media viewer for images, audio, and video.
    Integrates with the Pygame/Tkinter shell to display media to the user.
    """
    def __init__(self):
        self.supported_images = ['.png', '.jpg', '.jpeg', '.gif']
        self.supported_audio = ['.mp3', '.wav', '.ogg']
        self.supported_video = ['.mp4', '.avi', '.mkv']

    def view_media(self, file_path):
        if not os.path.exists(file_path):
            print(f"[MediaViewer] Error: File not found - {file_path}")
            return False
            
        ext = os.path.splitext(file_path)[1].lower()
        
        if ext in self.supported_images:
            return self._show_image(file_path)
        elif ext in self.supported_audio:
            return self._play_audio(file_path)
        elif ext in self.supported_video:
            return self._play_video(file_path)
        else:
            print(f"[MediaViewer] Unsupported media format: {ext}")
            return False

    def _show_image(self, path):
        print(f"[MediaViewer] Displaying Image: {path}")
        # Stub: Pygame image load and blit
        return True

    def _play_audio(self, path):
        print(f"[MediaViewer] Playing Audio: {path}")
        # Stub: Pygame mixer music load and play
        return True

    def _play_video(self, path):
        print(f"[MediaViewer] Playing Video: {path}")
        # Stub: OpenCV or Pygame video playback
        return True