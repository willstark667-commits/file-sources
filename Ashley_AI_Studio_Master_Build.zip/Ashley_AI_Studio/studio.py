import os
import sys

# Add the current directory to the path so imports work correctly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.persona_manager import PersonaManager
from gui.pyweb_shell import PyWebShell
from core.file_manager import AdvancedFileManager
from core.neural_builder import NeuralNetworkBuilder
from core.web_research import WebResearchAgent
from core.self_improvement import SelfImprovementLoop
from core.backup_system import BackupManager
from core.internal_browser import InternalBrowser
from core.media_generator import MediaGenerator
from core.modules.module_manager import ModuleManager
from engine.omni.console_router import ConsoleRouter

# Phase 11: Core AI Agent Imports
from engine.llm.prompt_memory import PromptMemory
from engine.llm.multi_agent_router import MultiAgentRouter
from engine.llm.learning_loop import LearningLoop

def main():
    print("==================================================")
    print("        Initializing Ashley AI Studio V4          ")
    print("        (Deep Learning & Core Agent Active)       ")
    print("==================================================")
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Initialize Core Architecture
    module_manager = ModuleManager()
    console_router = ConsoleRouter()
    
    # 2. Initialize AI Core Agent (Stage 0 & 1)
    prompt_memory = PromptMemory(os.path.join(base_dir, "data", "prompt_memory.db"))
    multi_agent_router = MultiAgentRouter(prompt_memory)
    learning_loop = LearningLoop(prompt_memory)
    
    # Register AI Core as Wheels
    module_manager.register_wheel("PromptMemory", prompt_memory)
    module_manager.register_wheel("MultiAgentRouter", multi_agent_router)
    module_manager.register_wheel("LearningLoop", learning_loop)
    
    # Create Frontend Handle for Chatting
    def handle_chat_request(data):
        prompt = data.get("prompt", "")
        provider = data.get("provider", "ollama") # Default to local
        result = multi_agent_router.query(prompt, task_type="chat", preferred_provider=provider)
        
        # Auto-score and learn from the interaction (simulated feedback for now)
        learning_loop.evaluate_and_learn(result["interaction_id"], result["response"])
        
        return result

    module_manager.register_handle("ask_ashley", handle_chat_request)
    
    # 3. Initialize Legacy & Support Modules
    persona_manager = PersonaManager()
    file_manager = AdvancedFileManager(base_dir)
    neural_builder = NeuralNetworkBuilder()
    web_research = WebResearchAgent()
    internal_browser = InternalBrowser()
    media_generator = MediaGenerator(os.path.join(base_dir, "data"))
    
    # 4. Initialize Self-Improvement & Backups
    backup_dir = os.path.join(base_dir, "backups")
    backup_manager = BackupManager(base_dir, backup_dir)
    self_improvement = SelfImprovementLoop(base_dir)
    
    # 5. Create an initial startup backup
    backup_manager.create_backup("startup_v4")
    
    # 6. Launch the PyWebView GUI
    print("\n[System] Launching Studio Interface (PyWebView)...")
    shell = PyWebShell(engine=None, backup_manager=backup_manager)
    shell.run()

if __name__ == "__main__":
    main()