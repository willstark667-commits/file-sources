import urllib.request
import urllib.parse
import json
import re

class WebResearchAgent:
    """
    Allows Cortana and Ashley to search the web, gather data, and track information
    for training and improving prompts.
    """
    def __init__(self):
        self.search_history = []
        self.knowledge_base = []

    def search_duckduckgo(self, query):
        """
        A simple web scraper stub using DuckDuckGo HTML search.
        In a production environment, this would use a real Search API (like Google Custom Search or SERP API).
        """
        print(f"[WebResearch] Searching the web for: '{query}'")
        self.search_history.append(query)
        
        url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)
        req = urllib.request.Request(
            url, 
            data=None, 
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
        )
        
        try:
            response = urllib.request.urlopen(req)
            html = response.read().decode('utf-8')
            
            # Very basic regex to extract snippet text from DuckDuckGo HTML
            snippets = re.findall(r'<a class="result__snippet[^>]*>(.*?)</a>', html, re.IGNORECASE | re.DOTALL)
            
            results = []
            for snippet in snippets[:3]: # Get top 3 results
                # Clean up bold tags
                clean_text = re.sub(r'<[^>]+>', '', snippet).strip()
                results.append(clean_text)
                self.knowledge_base.append(clean_text)
                
            print(f"[WebResearch] Found {len(results)} relevant snippets.")
            return results
            
        except Exception as e:
            print(f"[WebResearch] Search failed: {e}")
            return ["Error: Could not retrieve search results."]

    def summarize_knowledge(self):
        """Compiles gathered research into a training prompt format."""
        if not self.knowledge_base:
            return "No research data gathered yet."
            
        summary = "--- Gathered Web Research ---\n"
        for i, fact in enumerate(self.knowledge_base[-10:]): # Last 10 facts
            summary += f"{i+1}. {fact}\n"
        return summary