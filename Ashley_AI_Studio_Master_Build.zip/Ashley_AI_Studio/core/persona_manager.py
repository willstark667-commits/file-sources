class PersonaManager:
    """
    Manages different AI personas (e.g., Ashley, Cortana).
    Handles TTS (Text-to-Speech) and STT (Speech-to-Text) toggles,
    as well as persona-specific system prompts and behaviors.
    """
    def __init__(self):
        self.personas = {
            "ashley": {
                "name": "Ashley",
                "role": "Writing and Coding Assistant",
                "system_prompt": "You are Ashley, an advanced AI coding and writing assistant. You focus on building, debugging, and optimizing code.",
                "voice_model": "ashley_v1_female"
            },
            "cortana": {
                "name": "Cortana",
                "role": "System Operations and Research Agent",
                "system_prompt": "You are Cortana, a system operations and research AI. You focus on web search, file management, and system diagnostics.",
                "voice_model": "cortana_v1_female"
            }
        }
        self.current_persona_id = "ashley"
        self.tts_enabled = False
        self.stt_enabled = False

    @property
    def current_persona(self):
        return self.personas[self.current_persona_id]

    def switch_persona(self, persona_id):
        if persona_id in self.personas:
            self.current_persona_id = persona_id
            print(f"[System] Switched persona to {self.current_persona['name']}")
            return True
        print(f"[Error] Persona '{persona_id}' not found.")
        return False

    def toggle_tts(self):
        self.tts_enabled = not self.tts_enabled
        status = "ON" if self.tts_enabled else "OFF"
        print(f"[System] Text-to-Speech (TTS) is now {status}")

    def toggle_stt(self):
        self.stt_enabled = not self.stt_enabled
        status = "ON" if self.stt_enabled else "OFF"
        print(f"[System] Speech-to-Text (STT) is now {status}")

    def get_system_prompt(self):
        return self.current_persona["system_prompt"]