import math
import random

class Neuron:
    def __init__(self, num_inputs):
        # Initialize weights randomly between -1 and 1
        self.weights = [random.uniform(-1.0, 1.0) for _ in range(num_inputs)]
        self.bias = random.uniform(-1.0, 1.0)
        self.output = 0.0
        self.delta = 0.0

class Layer:
    def __init__(self, num_neurons, num_inputs_per_neuron):
        self.neurons = [Neuron(num_inputs_per_neuron) for _ in range(num_neurons)]

class NeuralNetworkBuilder:
    """
    A custom, from-scratch Neural Network framework for Ashley AI Studio.
    Allows adding layers, nodes, and training via backpropagation.
    """
    def __init__(self):
        self.layers = []
        self.learning_rate = 0.1

    def add_layer(self, num_neurons, num_inputs_per_neuron):
        """Adds a new layer to the network."""
        layer = Layer(num_neurons, num_inputs_per_neuron)
        self.layers.append(layer)
        print(f"[NeuralBuilder] Added layer with {num_neurons} nodes.")

    def _sigmoid(self, x):
        # Prevent overflow
        if x < -700: return 0.0
        return 1.0 / (1.0 + math.exp(-x))

    def _sigmoid_derivative(self, output):
        return output * (1.0 - output)

    def forward_propagate(self, inputs):
        """Passes inputs through the network to generate an output/prediction."""
        current_inputs = inputs
        for layer in self.layers:
            new_inputs = []
            for neuron in layer.neurons:
                activation = neuron.bias
                for i in range(len(neuron.weights)):
                    activation += neuron.weights[i] * current_inputs[i]
                neuron.output = self._sigmoid(activation)
                new_inputs.append(neuron.output)
            current_inputs = new_inputs
        return current_inputs

    def backward_propagate(self, expected_outputs):
        """Calculates errors and updates deltas backwards through the network."""
        for i in reversed(range(len(self.layers))):
            layer = self.layers[i]
            errors = []
            if i == len(self.layers) - 1:
                # Output layer error
                for j, neuron in enumerate(layer.neurons):
                    errors.append(expected_outputs[j] - neuron.output)
            else:
                # Hidden layer error
                for j, neuron in enumerate(layer.neurons):
                    error = 0.0
                    next_layer = self.layers[i + 1]
                    for next_neuron in next_layer.neurons:
                        error += (next_neuron.weights[j] * next_neuron.delta)
                    errors.append(error)
            
            for j, neuron in enumerate(layer.neurons):
                neuron.delta = errors[j] * self._sigmoid_derivative(neuron.output)

    def update_weights(self, inputs):
        """Updates the weights and biases based on the calculated deltas."""
        for i, layer in enumerate(self.layers):
            current_inputs = inputs if i == 0 else [n.output for n in self.layers[i - 1].neurons]
            for neuron in layer.neurons:
                for j in range(len(current_inputs)):
                    neuron.weights[j] += self.learning_rate * neuron.delta * current_inputs[j]
                neuron.bias += self.learning_rate * neuron.delta

    def train_cycle(self, training_data, epochs=1000):
        """
        Runs a training loop.
        training_data format: [(inputs_list, expected_outputs_list), ...]
        """
        print(f"[NeuralBuilder] Starting training loop for {epochs} epochs...")
        for epoch in range(epochs):
            total_error = 0.0
            for inputs, expected in training_data:
                outputs = self.forward_propagate(inputs)
                total_error += sum([(expected[i] - outputs[i])**2 for i in range(len(expected))])
                self.backward_propagate(expected)
                self.update_weights(inputs)
            
            if (epoch + 1) % (epochs // 10) == 0:
                print(f"  > Epoch {epoch + 1}/{epochs} | Error: {total_error:.4f}")
        print("[NeuralBuilder] Training complete.")