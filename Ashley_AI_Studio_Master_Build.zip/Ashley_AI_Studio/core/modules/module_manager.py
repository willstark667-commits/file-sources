class ModuleManager:
    """
    Advanced Architecture: Hooks, Wheels, and Handles.
    Bridges the PyWebView Frontend with the Python Backend.
    """
    def __init__(self):
        self.hooks = {}    # Event listeners (e.g., 'on_message_received')
        self.wheels = {}   # Pluggable core modules (e.g., 'LLM_Engine', 'Audio_Studio')
        self.handles = {}  # Direct function references for the frontend API

    # --- WHEELS (Modules) ---
    def register_wheel(self, name, module_instance):
        """Registers a complex feature/module (Wheel) into the system."""
        self.wheels[name] = module_instance
        print(f"[ModuleManager] Wheel registered: {name}")

    def get_wheel(self, name):
        return self.wheels.get(name)

    # --- HOOKS (Events) ---
    def register_hook(self, event_name, callback):
        """Attaches a function to an event trigger."""
        if event_name not in self.hooks:
            self.hooks[event_name] = []
        self.hooks[event_name].append(callback)

    def trigger_hook(self, event_name, *args, **kwargs):
        """Fires all functions attached to an event."""
        results = []
        if event_name in self.hooks:
            for callback in self.hooks[event_name]:
                try:
                    results.append(callback(*args, **kwargs))
                except Exception as e:
                    print(f"[ModuleManager] Hook Error on '{event_name}': {e}")
        return results

    # --- HANDLES (Frontend/Backend Bridging) ---
    def register_handle(self, action_name, func):
        """Registers a backend function that the PyWebView frontend can call."""
        self.handles[action_name] = func

    def bridge_frontend_backend(self, action, data):
        """
        The main router for the PyWebView GUI.
        The Javascript frontend sends an action, and this routes it to the Python backend.
        """
        if action in self.handles:
            try:
                return self.handles[action](data)
            except Exception as e:
                return {"status": "error", "traceback": str(e)}
        return {"status": "error", "message": f"Handle '{action}' not found."}