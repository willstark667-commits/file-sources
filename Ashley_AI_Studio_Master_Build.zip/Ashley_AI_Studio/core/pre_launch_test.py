import os
import sys
from core.backup_system import BackupManager
from tools.diagnostics import CodeDiagnostic

class PreLaunchTester:
    """
    Runs a diagnostic check before launching the Studio.
    If critical errors are found in the new version, it triggers a fallback restore.
    """
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.backup_manager = BackupManager(base_dir, os.path.join(base_dir, "backups"))
        self.diagnostic = CodeDiagnostic()

    def run_tests(self):
        print("[PreLaunchTest] Running system diagnostics...")
        
        # 1. Check Syntax
        report = self.diagnostic.analyze_project(self.base_dir)
        if "Errors Found" in report:
            print("[PreLaunchTest] CRITICAL ERROR: Syntax errors detected in the new version!")
            print(report)
            self._trigger_fallback()
            return False
            
        # 2. Check Core Directories
        required_dirs = ["core", "gui", "engine", "data"]
        for d in required_dirs:
            if not os.path.exists(os.path.join(self.base_dir, d)):
                print(f"[PreLaunchTest] CRITICAL ERROR: Missing required directory '{d}'!")
                self._trigger_fallback()
                return False
                
        print("[PreLaunchTest] All systems nominal. Ready for launch.")
        return True

    def _trigger_fallback(self):
        print("[PreLaunchTest] Initiating emergency fallback to last known good configuration...")
        success = self.backup_manager.restore_fallback()
        if success:
            print("[PreLaunchTest] Fallback complete. Exiting to prevent further corruption.")
            sys.exit(1)
        else:
            print("[PreLaunchTest] FATAL: Fallback failed. Manual intervention required.")
            sys.exit(1)