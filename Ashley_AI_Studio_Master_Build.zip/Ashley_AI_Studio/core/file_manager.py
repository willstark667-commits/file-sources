import os
import shutil
import mimetypes

class AdvancedFileManager:
    """
    Scans directories, detects file types, organizes them into the Studio's database,
    and creates shortcuts for quick access.
    Updated for V2: Supports CSS, HTML, CSV, and language versions.
    """
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.data_dir = os.path.join(base_dir, "data")
        self.shortcuts_dir = os.path.join(base_dir, "shortcuts")
        
        # Define categories and their target directories
        self.categories = {
            "images": os.path.join(self.data_dir, "images"),
            "video": os.path.join(self.data_dir, "video"),
            "text": os.path.join(self.data_dir, "text"),
            "code_python_v3": os.path.join(self.data_dir, "code", "python", "v3"),
            "code_javascript_es6": os.path.join(self.data_dir, "code", "javascript", "es6"),
            "web_html": os.path.join(self.data_dir, "web", "html"),
            "web_css": os.path.join(self.data_dir, "web", "css"),
            "web_csv": os.path.join(self.data_dir, "web", "csv")
        }
        
        # Ensure directories exist
        for path in self.categories.values():
            os.makedirs(path, exist_ok=True)
        os.makedirs(self.shortcuts_dir, exist_ok=True)

    def _detect_category(self, file_path):
        mime_type, _ = mimetypes.guess_type(file_path)
        ext = os.path.splitext(file_path)[1].lower()
        
        if mime_type:
            if mime_type.startswith('image'): return "images"
            if mime_type.startswith('video'): return "video"
            if mime_type.startswith('text/plain'): return "text"
            if mime_type == 'text/csv': return "web_csv"
            if mime_type == 'text/html': return "web_html"
            if mime_type == 'text/css': return "web_css"
            
        if ext == '.py': return "code_python_v3"
        if ext in ['.js', '.jsx', '.ts']: return "code_javascript_es6"
        if ext == '.html': return "web_html"
        if ext == '.css': return "web_css"
        if ext == '.csv': return "web_csv"
        if ext in ['.txt', '.md', '.json', '.xml']: return "text"
        
        return None

    def organize_directory(self, source_dir):
        """Scans a directory and copies files to their respective category folders."""
        print(f"[FileManager] Scanning {source_dir}...")
        processed_count = 0
        
        for root, _, files in os.walk(source_dir):
            for file in files:
                file_path = os.path.join(root, file)
                category = self._detect_category(file_path)
                
                if category:
                    target_dir = self.categories[category]
                    target_path = os.path.join(target_dir, file)
                    
                    # Copy file to organized database
                    if not os.path.exists(target_path):
                        shutil.copy2(file_path, target_path)
                        self.create_shortcut(target_path, category)
                        processed_count += 1
                        
        print(f"[FileManager] Organized {processed_count} new files.")

    def create_shortcut(self, target_path, category):
        """Creates a symlink (shortcut) in the shortcuts directory for quick access."""
        filename = os.path.basename(target_path)
        shortcut_path = os.path.join(self.shortcuts_dir, f"{category}_{filename}")
        
        try:
            if not os.path.exists(shortcut_path):
                os.symlink(target_path, shortcut_path)
        except OSError as e:
            # Symlinks might require admin privileges on Windows
            pass