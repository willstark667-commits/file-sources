import urllib.request
import urllib.parse
import re

class InternalBrowser:
    """
    An internal web browser for Cortana and Ashley to look up information,
    read HTML websites, and gather data for training.
    """
    def __init__(self):
        self.history = []
        self.bookmarks = {}

    def fetch_url(self, url):
        """Fetches the HTML content of a given URL."""
        print(f"[InternalBrowser] Fetching {url}...")
        self.history.append(url)
        
        if not url.startswith('http'):
            url = 'http://' + url
            
        req = urllib.request.Request(
            url, 
            headers={'User-Agent': 'AshleyStudioBrowser/1.0'}
        )
        
        try:
            response = urllib.request.urlopen(req, timeout=10)
            html = response.read().decode('utf-8', errors='ignore')
            return self._extract_text(html)
        except Exception as e:
            print(f"[InternalBrowser] Failed to fetch {url}: {e}")
            return f"Error: {e}"

    def _extract_text(self, html):
        """Extracts readable text from HTML."""
        # Remove scripts and styles
        text = re.sub(r'<script.*?</script>', '', html, flags=re.IGNORECASE | re.DOTALL)
        text = re.sub(r'<style.*?</style>', '', text, flags=re.IGNORECASE | re.DOTALL)
        # Remove HTML tags
        text = re.sub(r'<[^>]+>', ' ', text)
        # Clean up whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        return text

    def search_google(self, query):
        """Simulates a Google search by fetching search results."""
        print(f"[InternalBrowser] Searching Google for: {query}")
        # In a real implementation, this would use a proper search API.
        # For this stub, we'll use a placeholder or a simple DuckDuckGo fallback.
        url = "https://html.duckduckgo.com/html/?q=" + urllib.parse.quote(query)
        return self.fetch_url(url)