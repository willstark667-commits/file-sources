class KnowledgeGraphManager:
    """
    Manages multi-modal knowledge graphs for the AI Studio.
    Maps relationships between audio/voice, text/words, and code/scripts.
    """
    def __init__(self):
        self.graphs = {
            "audio_voice": {},
            "text_word": {},
            "code_scripts": {}
        }
        self.graph_types = list(self.graphs.keys())

    def add_audio_node(self, voice_id, frequencies, tone, pitch, related_emotions):
        """Adds a node to the Audio/Voice graph."""
        print(f"[KnowledgeGraph] Adding Audio Node: {voice_id}")
        self.graphs["audio_voice"][voice_id] = {
            "frequencies": frequencies,
            "tone": tone,
            "pitch": pitch,
            "emotions": related_emotions,
            "connections": []
        }

    def add_text_node(self, word, semantic_vector, related_words):
        """Adds a node to the Text/Word graph."""
        print(f"[KnowledgeGraph] Adding Text Node: {word}")
        self.graphs["text_word"][word] = {
            "vector": semantic_vector,
            "related": related_words,
            "connections": []
        }

    def add_code_node(self, script_name, language, dependencies, logic_flow):
        """Adds a node to the Code/Scripts graph."""
        print(f"[KnowledgeGraph] Adding Code Node: {script_name} ({language})")
        self.graphs["code_scripts"][script_name] = {
            "language": language,
            "dependencies": dependencies,
            "logic_flow": logic_flow,
            "connections": []
        }

    def link_nodes(self, graph_type, node_a, node_b, relationship_weight):
        """Creates a weighted connection between two nodes in a specific graph."""
        if node_a in self.graphs[graph_type] and node_b in self.graphs[graph_type]:
            self.graphs[graph_type][node_a]["connections"].append({"node": node_b, "weight": relationship_weight})
            self.graphs[graph_type][node_b]["connections"].append({"node": node_a, "weight": relationship_weight})
            print(f"[KnowledgeGraph] Linked {node_a} <-> {node_b} in {graph_type} (Weight: {relationship_weight})")

    def list_graphs(self):
        """Returns a summary of all active knowledge graphs and their sizes."""
        summary = "=== Active Knowledge Graphs ===\n"
        for g_type, nodes in self.graphs.items():
            summary += f"- {g_type.replace('_', ' ').title()} Graph: {len(nodes)} nodes\n"
        return summary