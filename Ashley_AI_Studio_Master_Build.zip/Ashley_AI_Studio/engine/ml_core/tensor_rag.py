import torch
import numpy as np
import os
from sklearn.metrics.pairwise import cosine_similarity

class TensorRAG:
    """
    Retrieval-Augmented Generation (RAG) using PyTorch Tensors.
    Converts text files into dense vector embeddings for instant semantic search.
    """
    def __init__(self, embedding_dim=512):
        self.embedding_dim = embedding_dim
        self.document_embeddings = {} # Maps filename to tensor
        self.document_texts = {}      # Maps filename to raw text
        
        # In a real production system, you would use a pre-trained model like BERT or SentenceTransformers here.
        # For this local build, we simulate the embedding layer.
        self.embedding_layer = torch.nn.Embedding(num_embeddings=10000, embedding_dim=embedding_dim)

    def _simulate_text_to_tensor(self, text):
        """Simulates converting text to a dense vector tensor."""
        # Hash the text to create a pseudo-random but deterministic tensor
        np.random.seed(abs(hash(text)) % (2**32))
        vector = np.random.rand(self.embedding_dim)
        return torch.FloatTensor(vector)

    def ingest_directory(self, directory_path):
        """Scans a directory and converts all text files into tensor embeddings."""
        print(f"[TensorRAG] Ingesting files from {directory_path}...")
        for root, _, files in os.walk(directory_path):
            for file in files:
                if file.endswith('.txt') or file.endswith('.md') or file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            text = f.read()
                            tensor = self._simulate_text_to_tensor(text)
                            self.document_embeddings[file] = tensor
                            self.document_texts[file] = text
                            print(f"  - Embedded: {file}")
                    except Exception as e:
                        print(f"  - Failed to read {file}: {e}")

    def search(self, query, top_k=3):
        """Searches the tensor database for the most relevant documents."""
        if not self.document_embeddings:
            return []
            
        query_tensor = self._simulate_text_to_tensor(query).numpy().reshape(1, -1)
        
        results = []
        for filename, doc_tensor in self.document_embeddings.items():
            doc_np = doc_tensor.numpy().reshape(1, -1)
            similarity = cosine_similarity(query_tensor, doc_np)[0][0]
            results.append((similarity, filename, self.document_texts[filename]))
            
        # Sort by highest similarity
        results.sort(key=lambda x: x[0], reverse=True)
        return results[:top_k]