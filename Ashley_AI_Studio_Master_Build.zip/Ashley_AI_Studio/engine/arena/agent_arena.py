import time
from engine.arena.hybrid_chess import HybridChessEngine

class AgentArena:
    """
    A training ground where AI personas (Ashley and Cortana) compete in logical games (like Chess).
    This improves their reasoning, planning, and algorithmic efficiency, which translates to better coding and language skills.
    """
    def __init__(self):
        self.agent_1 = HybridChessEngine("Ashley")
        self.agent_2 = HybridChessEngine("Cortana")
        self.stats = {
            "Ashley": {"wins": 0, "losses": 0, "draws": 0},
            "Cortana": {"wins": 0, "losses": 0, "draws": 0}
        }
        self.total_games = 0

    def play_match(self):
        """Simulates a full chess match between the two agents."""
        self.total_games += 1
        print(f"\n=== Arena Match {self.total_games}: Ashley vs Cortana ===")
        
        # Simulate a game loop
        board_state = "initial_fen"
        
        # Ashley plays White, Cortana plays Black
        move_a, score_a = self.agent_1.calculate_best_move(board_state)
        move_c, score_c = self.agent_2.calculate_best_move(board_state)
        
        time.sleep(1) # Simulate processing time
        
        # Determine winner based on hybrid evaluation scores
        if score_a > score_c + 0.2:
            winner, loser = "Ashley", "Cortana"
            self.agent_1.learn_from_game(won=True)
            self.agent_2.learn_from_game(won=False)
        elif score_c > score_a + 0.2:
            winner, loser = "Cortana", "Ashley"
            self.agent_2.learn_from_game(won=True)
            self.agent_1.learn_from_game(won=False)
        else:
            winner = "Draw"
            
        self._update_stats(winner)
        self._print_stats()

    def _update_stats(self, winner):
        if winner == "Ashley":
            self.stats["Ashley"]["wins"] += 1
            self.stats["Cortana"]["losses"] += 1
            print("Result: Ashley Wins by Checkmate.")
        elif winner == "Cortana":
            self.stats["Cortana"]["wins"] += 1
            self.stats["Ashley"]["losses"] += 1
            print("Result: Cortana Wins by Checkmate.")
        else:
            self.stats["Ashley"]["draws"] += 1
            self.stats["Cortana"]["draws"] += 1
            print("Result: Draw by Stalemate.")

    def _print_stats(self):
        print("\n--- Current Arena Standings ---")
        for agent, data in self.stats.items():
            total = data['wins'] + data['losses'] + data['draws']
            win_rate = (data['wins'] / total * 100) if total > 0 else 0
            print(f"{agent}: {data['wins']}W - {data['losses']}L - {data['draws']}D | Win Rate: {win_rate:.1f}%")
        print("-------------------------------")