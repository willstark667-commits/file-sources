class ChessTokenizer:
    """
    Converts chess moves into neural network tokens and weights.
    Allows the AI to use chess patterns to improve its general probability and prediction engines.
    """
    def __init__(self):
        self.move_weights = {}
        self.token_vocab = set()

    def tokenize_move(self, move_algebraic):
        """Converts a move like 'e2e4' into a token ID."""
        token = f"CHESS_MOVE_{move_algebraic.upper()}"
        self.token_vocab.add(token)
        return token

    def update_weights_from_match(self, match_record):
        """
        Analyzes a match record (who won, who lost, moves played).
        Increases weights for winning moves, decreases for losing moves.
        """
        winner = match_record.get("winner")
        moves = match_record.get("moves", [])
        
        print(f"[ChessTokenizer] Analyzing match. Winner: {winner}. Total moves: {len(moves)}")
        
        for i, move in enumerate(moves):
            token = self.tokenize_move(move)
            if token not in self.move_weights:
                self.move_weights[token] = 0.5 # Default weight
                
            # Simple heuristic: moves by the winner get a boost
            # Assuming even indices are White, odd are Black
            is_white_move = (i % 2 == 0)
            
            if (winner == "White" and is_white_move) or (winner == "Black" and not is_white_move):
                self.move_weights[token] += 0.01
            else:
                self.move_weights[token] -= 0.01
                
            # Clamp weights between 0 and 1
            self.move_weights[token] = max(0.0, min(1.0, self.move_weights[token]))
            
        print("[ChessTokenizer] Neural weights updated based on chess patterns.")
        return self.move_weights