import sys
import traceback
import logging

class ConsoleRouter:
    """
    Advanced Terminal Interface & Console Routing.
    Handles command execution, routes requests to the correct backend 'Wheels',
    and provides rich traceback handling for error fixing.
    """
    def __init__(self):
        self.commands = {}
        self.logger = logging.getLogger("ConsoleRouter")
        self.logger.setLevel(logging.DEBUG)

    def register_command(self, name, func, description=""):
        """Registers a new terminal command."""
        self.commands[name] = {"func": func, "desc": description}

    def execute(self, command_str):
        """Parses and routes a terminal command."""
        if not command_str.strip():
            return ""
            
        parts = command_str.split()
        cmd = parts[0].lower()
        args = parts[1:]
        
        if cmd == "help":
            return self.show_help()
            
        if cmd in self.commands:
            try:
                # Execute the mapped function
                result = self.commands[cmd]["func"](*args)
                return result
            except Exception as e:
                return self.handle_traceback(cmd, e)
        else:
            return f"Error: Command '{cmd}' not recognized. Type 'help' for a list of commands."

    def handle_traceback(self, cmd, exception):
        """Catches errors and formats tracebacks for easy debugging."""
        exc_type, exc_value, exc_traceback = sys.exc_info()
        tb_lines = traceback.format_exception(exc_type, exc_value, exc_traceback)
        formatted_tb = "".join(tb_lines)
        
        error_msg = f"--- TRACEBACK ERROR IN COMMAND '{cmd}' ---\n"
        error_msg += formatted_tb
        error_msg += "-----------------------------------------\n"
        error_msg += "Suggestion: Check the Module Manager hooks and ensure dependencies are loaded."
        
        self.logger.error(error_msg)
        return error_msg

    def show_help(self):
        help_text = "Available Console Commands:\n"
        for name, data in self.commands.items():
            help_text += f"  {name.ljust(15)} - {data['desc']}\n"
        return help_text