import time
import json
import os
from datetime import datetime

class OmniLogger:
    """
    Records absolutely everything the AI agents do: thoughts, plans, tools used,
    patterns, timing, tokens, and generic AI model actions.
    """
    def __init__(self, log_dir="logs/omni"):
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.current_session = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_file = os.path.join(self.log_dir, f"omni_record_{self.current_session}.jsonl")

    def record_event(self, agent_name, event_type, data):
        """
        event_type: 'thought', 'plan', 'tool_use', 'token_gen', 'chess_move', 'error'
        """
        entry = {
            "timestamp": time.time(),
            "agent": agent_name,
            "event_type": event_type,
            "data": data
        }
        
        with open(self.log_file, 'a') as f:
            f.write(json.dumps(entry) + "\n")
            
        # Print critical events to console
        if event_type in ['plan', 'tool_use', 'error']:
            print(f"[OmniLog] {agent_name} | {event_type.upper()} | {str(data)[:100]}")

    def log_chess_match(self, white_agent, black_agent, moves, winner):
        """Specifically logs chess matches for neural weight training."""
        match_data = {
            "white": white_agent,
            "black": black_agent,
            "moves": moves, # List of algebraic moves
            "winner": winner
        }
        self.record_event("System", "chess_match_complete", match_data)