import urllib.request
import urllib.error
import json

class OllamaBridge:
    """
    Connects Ashley AI Studio to a local Ollama instance.
    Replaces the basic probability engine with a true Large Language Model (LLM).
    """
    def __init__(self, host="http://localhost:11434", default_model="llama3"):
        self.host = host
        self.default_model = default_model
        self.api_url = f"{self.host}/api/generate"

    def check_connection(self):
        try:
            req = urllib.request.Request(self.host)
            urllib.request.urlopen(req, timeout=2)
            print("[OllamaBridge] Successfully connected to local Ollama server.")
            return True
        except Exception:
            print("[OllamaBridge] Warning: Could not connect to Ollama. Ensure it is running locally.")
            return False

    def generate_response(self, prompt, persona_system_prompt, model=None):
        """Sends a prompt to the local LLM and returns the response."""
        if not model:
            model = self.default_model
            
        full_prompt = f"System: {persona_system_prompt}\n\nUser: {prompt}\n\nResponse:"
        
        data = {
            "model": model,
            "prompt": full_prompt,
            "stream": False
        }
        
        req = urllib.request.Request(
            self.api_url, 
            data=json.dumps(data).encode('utf-8'),
            headers={'Content-Type': 'application/json'}
        )
        
        try:
            print(f"[OllamaBridge] Sending query to {model}...")
            response = urllib.request.urlopen(req, timeout=30)
            result = json.loads(response.read().decode('utf-8'))
            return result.get("response", "")
        except Exception as e:
            print(f"[OllamaBridge] LLM Generation Error: {e}")
            return "Error: Could not reach the language model. Falling back to generic heuristic engine."