import sqlite3
import json
import uuid
import os
from datetime import datetime

class PromptMemory:
    """
    SQLite-based memory system for storing prompts, responses, scores, and tokens.
    Allows Ashley to remember past interactions and retrieve the best prompts.
    """
    def __init__(self, db_path="data/prompt_memory.db"):
        self.db_path = db_path
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS interactions
                     (id TEXT PRIMARY KEY, provider TEXT, task_type TEXT, 
                      prompt TEXT, response TEXT, score REAL, 
                      tokens TEXT, timestamp TEXT)''')
        conn.commit()
        conn.close()

    def save_interaction(self, provider, task_type, prompt, response, score=0.0, tokens=None):
        if tokens is None: 
            tokens = []
        interaction_id = str(uuid.uuid4())
        timestamp = datetime.utcnow().isoformat()
        
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("INSERT INTO interactions VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                  (interaction_id, provider, task_type, prompt, response, score, json.dumps(tokens), timestamp))
        conn.commit()
        conn.close()
        return interaction_id

    def update_score(self, interaction_id, score, tokens=None):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        if tokens is not None:
            c.execute("UPDATE interactions SET score = ?, tokens = ? WHERE id = ?", (score, json.dumps(tokens), interaction_id))
        else:
            c.execute("UPDATE interactions SET score = ? WHERE id = ?", (score, interaction_id))
        conn.commit()
        conn.close()

    def get_best_prompt(self, task_type):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("SELECT prompt, response, score FROM interactions WHERE task_type = ? ORDER BY score DESC LIMIT 1", (task_type,))
        result = c.fetchone()
        conn.close()
        if result:
            return {"prompt": result[0], "response": result[1], "score": result[2]}
        return None