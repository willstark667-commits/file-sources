import re

class LearningLoop:
    """
    Evaluates AI responses, extracts useful tokens/patterns, 
    and updates the Prompt Memory to improve future generations.
    """
    def __init__(self, memory_module):
        self.memory = memory_module

    def evaluate_and_learn(self, interaction_id, response_text, user_feedback_score=None):
        if not interaction_id:
            return 0.0
            
        # 1. Score the response (use human feedback if available, else heuristic)
        score = user_feedback_score if user_feedback_score is not None else self._heuristic_score(response_text)
        
        # 2. Extract reusable tokens/patterns
        tokens = self._extract_tokens(response_text)
        
        # 3. Update memory database
        self.memory.update_score(interaction_id, score, tokens)
        
        print(f"[LearningLoop] Interaction {interaction_id} scored {score:.2f}. Extracted {len(tokens)} tokens.")
        return score

    def _heuristic_score(self, text):
        """Basic heuristic evaluation of response quality."""
        score = 0.5
        if "Error:" not in text and "failed" not in text.lower():
            score += 0.2
        if len(text.split()) > 20:
            score += 0.1
        if "```" in text: # Contains code blocks
            score += 0.1
        return min(score, 1.0)

    def _extract_tokens(self, text):
        """Extracts significant words or code patterns to build a token library."""
        # Simple extraction: words longer than 6 characters
        words = re.findall(r'\b\w{7,}\b', text.lower())
        # Return unique tokens
        return list(set(words))[:10]