import os
import time
import logging

class MultiAgentRouter:
    """
    Routes queries to official APIs (OpenAI, Claude, Grok, Gemini) 
    and falls back to local Ollama if they fail or are unavailable.
    """
    def __init__(self, memory_module):
        self.memory = memory_module
        self.providers = ["openai", "claude", "grok", "gemini", "ollama"]
        self.provider_stats = {p: {"successes": 0, "failures": 0, "avg_latency": 0.0} for p in self.providers}
        self.logger = logging.getLogger("MultiAgentRouter")

    def query(self, prompt, task_type="general", preferred_provider=None):
        providers_to_try = self.providers.copy()
        
        # Move preferred provider to the front of the queue
        if preferred_provider and preferred_provider in providers_to_try:
            providers_to_try.remove(preferred_provider)
            providers_to_try.insert(0, preferred_provider)

        for provider in providers_to_try:
            try:
                start_time = time.time()
                response = self._call_provider(provider, prompt)
                latency = time.time() - start_time
                
                self._update_stats(provider, True, latency)
                
                # Save to memory
                interaction_id = self.memory.save_interaction(provider, task_type, prompt, response)
                self.logger.info(f"Successfully queried {provider} in {latency:.2f}s")
                
                return {
                    "response": response, 
                    "provider": provider, 
                    "interaction_id": interaction_id, 
                    "latency": latency
                }
            except Exception as e:
                self._update_stats(provider, False, 0.0)
                self.logger.warning(f"Provider {provider} failed: {e}. Trying next fallback...")
        
        return {
            "response": "Error: All AI providers failed. Please check your API keys or ensure Ollama is running locally.", 
            "provider": "none", 
            "interaction_id": None, 
            "latency": 0.0
        }

    def _call_provider(self, provider, prompt):
        """
        Stub for actual API calls. In production, this uses the official SDKs.
        """
        if provider == "ollama":
            # Fallback to local Ollama
            return f"[Ollama Local Fallback] Simulated response to: '{prompt}'"
            
        elif provider == "openai":
            if not os.getenv("OPENAI_API_KEY"): 
                raise ValueError("Missing OPENAI_API_KEY")
            return f"[OpenAI] Simulated response to: '{prompt}'"
            
        elif provider == "claude":
            if not os.getenv("ANTHROPIC_API_KEY"): 
                raise ValueError("Missing ANTHROPIC_API_KEY")
            return f"[Claude] Simulated response to: '{prompt}'"
            
        elif provider == "grok":
            if not os.getenv("XAI_API_KEY"): 
                raise ValueError("Missing XAI_API_KEY")
            return f"[Grok] Simulated response to: '{prompt}'"
            
        elif provider == "gemini":
            if not os.getenv("GEMINI_API_KEY"): 
                raise ValueError("Missing GEMINI_API_KEY")
            return f"[Gemini] Simulated response to: '{prompt}'"
            
        raise ValueError(f"Unknown provider: {provider}")

    def _update_stats(self, provider, success, latency):
        stats = self.provider_stats[provider]
        if success:
            stats["successes"] += 1
            n = stats["successes"]
            stats["avg_latency"] = ((stats["avg_latency"] * (n - 1)) + latency) / n
        else:
            stats["failures"] += 1