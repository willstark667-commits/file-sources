import os
import json

class VoiceDatasetManager:
    """
    Manages the audio files used to train voice models.
    Allows toggling which files to use and assigning them to specific AI agents.
    """
    def __init__(self, dataset_dir="data/audio/datasets", config_file="config/voice_assignments.json"):
        self.dataset_dir = dataset_dir
        self.config_file = config_file
        self.assignments = self._load_assignments()

    def _load_assignments(self):
        if os.path.exists(self.config_file):
            with open(self.config_file, 'r') as f:
                return json.load(f)
        return {"Ashley": [], "Cortana": [], "Generic": []}

    def _save_assignments(self):
        os.makedirs(os.path.dirname(self.config_file), exist_ok=True)
        with open(self.config_file, 'w') as f:
            json.dump(self.assignments, f, indent=4)

    def list_available_audio(self):
        if not os.path.exists(self.dataset_dir):
            return []
        return [f for f in os.listdir(self.dataset_dir) if os.path.isfile(os.path.join(self.dataset_dir, f))]

    def assign_audio_to_agent(self, filename, agent_name):
        """Assigns an audio file to be used for training a specific agent's voice model."""
        if agent_name not in self.assignments:
            self.assignments[agent_name] = []
            
        if filename not in self.assignments[agent_name]:
            self.assignments[agent_name].append(filename)
            self._save_assignments()
            print(f"[DatasetManager] Assigned '{filename}' to {agent_name}'s training dataset.")

    def toggle_audio_usage(self, filename, agent_name, use_for_training=True):
        """Toggles whether an assigned audio file should currently be used in the training loop."""
        if agent_name in self.assignments:
            if use_for_training and filename not in self.assignments[agent_name]:
                self.assignments[agent_name].append(filename)
            elif not use_for_training and filename in self.assignments[agent_name]:
                self.assignments[agent_name].remove(filename)
            self._save_assignments()
            status = "ENABLED" if use_for_training else "DISABLED"
            print(f"[DatasetManager] {filename} for {agent_name} is now {status} for training.")