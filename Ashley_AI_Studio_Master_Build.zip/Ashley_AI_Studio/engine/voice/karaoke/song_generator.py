import random

class SongGenerator:
    """
    Generates lyrics, heuristic music, notes, sounds, and frequencies.
    Uses patterns, probabilities, and onomatopoeia for creative audio generation.
    """
    def __init__(self):
        self.notes = ["do", "re", "mi", "fa", "so", "la", "ti", "do"]
        self.sounds = ["ooh", "ahh", "wow", "pow", "bam", "na", "ra", "la"]
        
    def generate_lyrics(self, theme, lines=4):
        print(f"[SongGen] Generating lyrics for theme: '{theme}'...")
        lyrics = []
        for i in range(lines):
            # Stub: In a real system, the LLM generates these lines
            line = f"This is a generated lyric about {theme} (Line {i+1})"
            if random.random() > 0.5:
                line += f" ... {random.choice(self.sounds)} {random.choice(self.sounds)}!"
            lyrics.append(line)
        return lyrics

    def generate_heuristic_music(self, duration_seconds=10):
        print(f"[SongGen] Generating heuristic music notes for {duration_seconds} seconds...")
        track = []
        for _ in range(duration_seconds * 2): # 2 notes per second
            note = random.choice(self.notes)
            freq = random.randint(200, 800) # Hz
            track.append({"note": note, "frequency": freq})
        print("[SongGen] Music track generated with semantic vectors and probabilities.")
        return track