import os
import shutil

class AudioExtractor:
    """
    Scans the PC for audio and video files.
    Extracts audio from video files and copies them into the voice dataset directory.
    """
    def __init__(self, dataset_dir="data/audio/datasets"):
        self.dataset_dir = dataset_dir
        os.makedirs(self.dataset_dir, exist_ok=True)
        self.supported_audio = ['.mp3', '.wav', '.ogg', '.flac']
        self.supported_video = ['.mp4', '.mkv', '.avi', '.mov']

    def scan_and_import(self, source_directory):
        print(f"[AudioExtractor] Scanning {source_directory} for audio and video files...")
        imported_count = 0
        
        for root, _, files in os.walk(source_directory):
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                file_path = os.path.join(root, file)
                
                if ext in self.supported_audio:
                    self._copy_to_dataset(file_path, file)
                    imported_count += 1
                elif ext in self.supported_video:
                    self._extract_audio_from_video(file_path, file)
                    imported_count += 1
                    
        print(f"[AudioExtractor] Successfully imported/extracted {imported_count} audio files to dataset.")

    def _copy_to_dataset(self, source_path, filename):
        target_path = os.path.join(self.dataset_dir, filename)
        if not os.path.exists(target_path):
            shutil.copy2(source_path, target_path)
            print(f"  -> Copied Audio: {filename}")

    def _extract_audio_from_video(self, video_path, filename):
        """
        Stub for video-to-audio extraction.
        In a production environment, this would use ffmpeg or moviepy.
        """
        audio_filename = os.path.splitext(filename)[0] + "_extracted.wav"
        target_path = os.path.join(self.dataset_dir, audio_filename)
        
        if not os.path.exists(target_path):
            print(f"  -> Extracting Audio from Video: {filename} -> {audio_filename} (Stub)")
            # Simulate extraction by creating an empty file
            with open(target_path, 'w') as f:
                f.write("SIMULATED_AUDIO_DATA")