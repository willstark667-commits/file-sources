import time

class MultiAgentVoiceChat:
    """
    Handles turn-based, multi-agent voice chat (e.g., Ashley and Cortana).
    Includes TTS (Text-to-Speech) and STT (Speech-to-Text) toggles.
    Both agents have persistent memory and can talk back and forth.
    """
    def __init__(self, omni_logger):
        self.omni_logger = omni_logger
        self.agents = ["Ashley", "Cortana"]
        self.conversation_memory = []
        self.tts_enabled = True
        self.stt_enabled = False

    def toggle_tts(self):
        self.tts_enabled = not self.tts_enabled
        print(f"[VoiceChat] TTS is now {'ON' if self.tts_enabled else 'OFF'}")

    def toggle_stt(self):
        self.stt_enabled = not self.stt_enabled
        print(f"[VoiceChat] STT is now {'ON' if self.stt_enabled else 'OFF'}")

    def simulate_conversation(self, topic, turns=3):
        print(f"\n=== Starting Multi-Agent Chat: Topic '{topic}' ===")
        self.conversation_memory.append(f"Topic: {topic}")
        
        current_speaker_idx = 0
        for i in range(turns * 2):
            speaker = self.agents[current_speaker_idx]
            listener = self.agents[1 - current_speaker_idx]
            
            # Simulate thinking and generating response
            time.sleep(1)
            response = f"[{speaker}] I am analyzing the topic '{topic}' and responding to {listener}."
            
            # Log and print
            self.conversation_memory.append(response)
            print(response)
            if self.tts_enabled:
                print(f"  -> (TTS Audio Playing for {speaker}...)")
            
            self.omni_logger.record_event(speaker, "voice_chat", response)
            
            # Switch turns
            current_speaker_idx = 1 - current_speaker_idx
            
        print("=== Conversation Ended ===\n")