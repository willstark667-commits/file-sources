import os
import ast
import json

class CodeGrapher:
    """
    Scans the project directory, parses Python files, and extracts all imports
    to build a dependency graph and blueprint of the architecture.
    """
    def __init__(self, root_dir):
        self.root_dir = root_dir
        self.graph = {}
        self.all_imports = set()

    def scan(self):
        for subdir, _, files in os.walk(self.root_dir):
            for file in files:
                if file.endswith('.py'):
                    filepath = os.path.join(subdir, file)
                    self._parse_file(filepath)
        return self.graph, sorted(list(self.all_imports))

    def _parse_file(self, filepath):
        rel_path = os.path.relpath(filepath, self.root_dir)
        self.graph[rel_path] = {"imports": [], "classes": [], "functions": []}
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read(), filename=filepath)
                
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        self.graph[rel_path]["imports"].append(alias.name)
                        self.all_imports.add(alias.name.split('.')[0])
                elif isinstance(node, ast.ImportFrom):
                    module = node.module if node.module else ""
                    for alias in node.names:
                        full_import = f"{module}.{alias.name}" if module else alias.name
                        self.graph[rel_path]["imports"].append(full_import)
                        if module:
                            self.all_imports.add(module.split('.')[0])
                elif isinstance(node, ast.ClassDef):
                    self.graph[rel_path]["classes"].append(node.name)
                elif isinstance(node, ast.FunctionDef):
                    self.graph[rel_path]["functions"].append(node.name)
        except Exception as e:
            self.graph[rel_path]["error"] = str(e)

    def generate_report(self, output_path):
        self.scan()
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump({
                "total_files": len(self.graph),
                "unique_imports": sorted(list(self.all_imports)), 
                "file_graph": self.graph
            }, f, indent=4)
        print(f"[CodeGrapher] Blueprint generated at {output_path}")