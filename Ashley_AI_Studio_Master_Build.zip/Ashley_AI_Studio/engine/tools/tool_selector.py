import random

class ToolSelectionEngine:
    """
    Decides when an AI agent should use a tool (e.g., Web Search, File Writer, Media Gen).
    Uses probability, vectors, and trial-and-error to improve tool selection over time.
    """
    def __init__(self):
        # Initial weights/probabilities for tool selection
        self.tool_weights = {
            "web_search": 0.5,
            "file_writer": 0.5,
            "media_generator": 0.2,
            "code_diagnostic": 0.6,
            "internal_browser": 0.4
        }
        self.trial_history = []

    def select_tool(self, context_vector, available_tools):
        """
        Selects a tool based on the current context and learned weights.
        Includes a random factor for trial-and-error exploration.
        """
        print("[ToolSelector] Evaluating tool probabilities...")
        
        best_tool = None
        highest_score = -1.0
        
        for tool in available_tools:
            base_weight = self.tool_weights.get(tool, 0.1)
            # Add random exploration factor (Trial and Error)
            exploration_factor = random.uniform(-0.2, 0.2)
            
            # Simulated vector dot product score
            context_score = random.uniform(0.0, 1.0) 
            
            final_score = (base_weight * 0.7) + (context_score * 0.3) + exploration_factor
            
            if final_score > highest_score:
                highest_score = final_score
                best_tool = tool
                
        print(f"[ToolSelector] Selected '{best_tool}' with confidence {highest_score:.2f}")
        return best_tool

    def feedback_loop(self, tool_used, success):
        """Adjusts the probability weights based on whether the tool solved the problem."""
        self.trial_history.append({"tool": tool_used, "success": success})
        
        if success:
            self.tool_weights[tool_used] = min(1.0, self.tool_weights[tool_used] + 0.05)
            print(f"[ToolSelector] Tool '{tool_used}' succeeded. Increased weight to {self.tool_weights[tool_used]:.2f}")
        else:
            self.tool_weights[tool_used] = max(0.0, self.tool_weights[tool_used] - 0.05)
            print(f"[ToolSelector] Tool '{tool_used}' failed. Decreased weight to {self.tool_weights[tool_used]:.2f}")