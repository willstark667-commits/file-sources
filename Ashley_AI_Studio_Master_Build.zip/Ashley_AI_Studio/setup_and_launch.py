import os
import sys
import subprocess

def install_dependencies():
    """Auto-installs required dependencies."""
    print("[Setup] Checking dependencies...")
    try:
        import webview
    except ImportError:
        print("[Setup] Installing pywebview...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pywebview"])

def main():
    print("==================================================")
    print("      Ashley AI Studio - Setup & Launch           ")
    print("==================================================")
    
    # 1. Auto-Install Dependencies
    install_dependencies()
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 2. Load Order: Initialize Architecture
    print("[Load Order] 1. Initializing ModuleManager (Hooks, Wheels, Handles)...")
    from core.modules.module_manager import ModuleManager
    module_manager = ModuleManager()
    
    # 3. Load Order: Pre-Launch Testing & Backups
    print("[Load Order] 2. Running Pre-Launch Tests & Smart Backups...")
    from core.pre_launch_test import PreLaunchTester
    from core.backup_system import BackupManager
    
    backup_manager = BackupManager(base_dir, os.path.join(base_dir, "backups"))
    tester = PreLaunchTester(base_dir)
    
    if not tester.run_tests():
        print("[Setup] Pre-launch tests failed. Exiting.")
        sys.exit(1)
        
    # Prompt for backup
    print("\n[System] Would you like to create a smart backup before launching? (y/n)")
    # Auto-answering 'y' for seamless execution in this environment
    backup_manager.create_backup("pre_launch")
        
    # 4. Load Order: Launch PyWebView Shell
    print("[Load Order] 3. Launching PyWebView Shell...")
    from gui.pyweb_shell import PyWebShell
    shell = PyWebShell(engine=None, backup_manager=backup_manager)
    shell.run()

if __name__ == "__main__":
    main()