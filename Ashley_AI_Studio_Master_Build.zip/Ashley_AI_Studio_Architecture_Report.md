# Ashley AI Studio: Architecture & Status Report

## 1. Project Assessment & Engineering Realism

### Completion Percentage: ~15% of the Ultimate Vision
You have successfully built the **scaffolding** of an AI Studio. You have the GUI, file management, basic memory, and a foundational heuristic/Markov engine. However, the "brain" (the neural network capable of human-like reasoning) is still in its infancy.

### Engineering Realism
The vision you have outlined is the blueprint for an **Artificial General Intelligence (AGI)** ecosystem. 
*   **Realistic for a Solo Developer:** Building the Studio interface, the RAG pipeline, the file sorters, the persona managers, and integrating *existing* open-source LLMs (like Llama 3 or Mistral).
*   **Requires Massive Compute:** Building a neural network from scratch that rivals ChatGPT or Claude. Those models require thousands of GPUs, terabytes of data, and millions of dollars to train. Your local `neural_builder.py` is an excellent educational tool, but it cannot scale to that level on a single PC.

### Using Uploaded Files for Improvements
You uploaded dozens of text files and previous project zips. Here is how they are used:
1.  **Text Files (`data/text/user_uploads/`):** These are ingested by the RAG system. They provide Ashley with a localized knowledge base. When you ask a question, she searches these files for context.
2.  **Project Zips (`reference_projects/`):** These are used by the `SelfImprovementLoop`. Ashley scans this old code to learn your coding style, detect past mistakes, and generate better algorithms for future patches.

---

## 2. Phase Status: Completed vs. Incomplete

### Completed Phases (The Scaffolding)
*   **Phase 1-3:** Basic Chatbot, SQLite Database, Tokenizer, Scanner, Heuristic Rules, Markov Probability Engine.
*   **Phase 4-5:** Basic Neural Network Stub, File Management, Writing/Coding Assistant Stubs.
*   **Studio V1 & V2:** Pygame/Tkinter Hybrid Shell, Persona Manager (Ashley/Cortana), Advanced File Sorter, Internal Web Browser Stub, Media Generation Stub, Self-Improvement/Backup Loop.

### Incomplete / Missing Phases (The "Brain")
*   **True LLM Integration:** Connecting the Studio to a powerful local model (e.g., via `Ollama`) to handle heavy text/code generation.
*   **Production RAG:** Replacing the basic TF-IDF memory with a real vector database (like ChromaDB) and embedding models.
*   **Fact-Checking Engine:** A dedicated module to verify generated text against the RAG database to prevent hallucinations.
*   **Background Processing:** True asynchronous multi-threading so Ashley can train, search the web, and chat simultaneously without freezing the GUI.

---

## 3. Achieving Commercial AI Parity

### ChatGPT, Grok, Claude (Modern AI)
These are **Large Language Models (LLMs)** based on the Transformer architecture. They don't use simple rules; they use billions of parameters (weights) to understand the deep semantic relationships between words. To make Ashley like them, you must integrate a Transformer model.

### Deep Thought, Deep Blue, Chesschip (Classic AI)
These are **Symbolic AI** systems. They don't "read" text; they calculate math and search through millions of possible moves using algorithms like Minimax and Alpha-Beta Pruning. Ashley's current Heuristic Engine is closer to this classic AI approach.

### Probability, Prediction, and Pattern Engines
Modern AI is entirely based on prediction. 
*   **Pattern Engine:** Scans your uploaded files to find recurring structures (e.g., `def function_name():`).
*   **Probability Engine:** Calculates the mathematical likelihood of what comes next.
*   **Prediction Engine:** Selects the highest probability outcome and generates it.

---

## 4. Systems, Handles, Buses, Wheels, and Hooks

To make Ashley a true "Studio", the architecture uses these concepts:
*   **Event Bus:** The central nervous system. When you type a message, it goes on the bus. All other systems listen to the bus.
*   **Handles:** Identifiers for specific tasks (e.g., `handle_code_request`, `handle_web_search`).
*   **Hooks:** Interception points. A `pre_response_hook` allows the Fact-Checker to review Ashley's answer before you see it.
*   **Wheels (Modules):** Pluggable components. The `MediaGenerator` is a wheel. If you want to upgrade it to use Stable Diffusion, you just swap the wheel without breaking the car.

---

## 5. Fast and Slow Thinking & Memory

Based on Daniel Kahneman's psychology model, applied to AI:
*   **Fast Thinking (System 1):** Ashley's Heuristic Engine. It handles simple greetings ("Hello"), basic commands ("Clear screen"), and immediate reactions. It is fast, cheap, and rule-based.
*   **Slow Thinking (System 2):** Ashley's Neural Network / LLM. Used for complex coding, deep research, and logic puzzles. It takes longer, uses more compute, and involves reasoning and planning.
*   **Background Processing:** While you chat (Fast Thinking), Ashley can be scanning your uploaded files, updating her vector database, and running self-improvement loops in the background (Slow Thinking).

---

## 6. Token Prediction (A-Z, 0-9, Symbols)

AI does not predict "words"; it predicts **tokens**.
1.  **The Vocabulary:** The AI has a dictionary of every letter (A-Z), number (0-9), and symbol (!@#$%), plus common combinations (e.g., "ing", "tion", "def").
2.  **The Context Window:** When you type "The cat sat on the", the AI converts this to tokens.
3.  **The Prediction:** The Neural Network calculates the probability for the next token. It might calculate: `mat` (80%), `floor` (15%), `Z` (0.001%).
4.  **The Output:** It selects `mat`, adds it to the context, and repeats the cycle. This is how Ashley writes code and text.

---

## 7. Fact Checking and Mistake Detection

To prevent Ashley from lying (hallucinating) or writing bad code:
1.  **Syntax Checking:** (Already built in `diagnostics.py`). It parses Python code into an Abstract Syntax Tree (AST) to ensure it compiles before showing it to you.
2.  **Fact Verification:** When Ashley generates a claim, a background process extracts the keywords, searches the RAG database (your uploaded files) or the Internal Web Browser, and compares the generated claim against the source material. If it contradicts, the response is flagged and rewritten.

---

## 8. RAG (Retrieval-Augmented Generation) Implementation

How Ashley uses your uploaded files:
1.  **Ingestion:** The `AdvancedFileManager` reads your `.txt`, `.py`, and `.html` files.
2.  **Chunking:** The text is split into 500-token chunks.
3.  **Embedding:** A neural network converts each chunk into a Vector (a list of thousands of numbers).
4.  **Storage:** These vectors are saved in a Vector Database.
5.  **Retrieval:** When you ask "How do I build a neural network?", Ashley converts your question into a vector, finds the closest matching chunks in the database, and reads them *before* she answers you.