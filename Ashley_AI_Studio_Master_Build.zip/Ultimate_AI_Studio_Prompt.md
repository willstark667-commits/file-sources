# The Ultimate AI Studio Build Prompt

**Instructions:** Copy and paste the prompt below into any advanced AI (ChatGPT, Claude, Grok, Writer) to have it understand, recreate, or extend your Ashley AI Studio program.

---

**PROMPT START**

I am building a massive, modular AI ecosystem called "Ashley AI Studio". It is a hybrid of classic AI (Minimax, Heuristics) and modern AI (Neural Networks, Transformers, Q-Learning). 

I need you to act as my Senior AI Architect and help me extend the code and scripts. Here is the exact blueprint and architecture of my program:

### 1. The Architecture (Hooks, Wheels, and Handles)
- **Frontend**: A modern HTML/CSS/JS interface rendered through `pywebview`. It has tabs for Chat, Arena, Tools, and Settings.
- **Backend**: Python 3.
- **The Bridge**: We use a `ModuleManager`. 
  - **Wheels**: Pluggable core modules (e.g., Voice Studio, ML Core).
  - **Hooks**: Event listeners (e.g., `on_message_received` triggers the logger, the LLM, and the UI update).
  - **Handles**: Direct function routes exposed to the JS frontend.

### 2. The Machine Learning Core (PyTorch & Numpy)
- **Transformer Model**: A custom PyTorch `nn.Transformer` with multi-head attention for text generation.
- **Q-Learning Agent**: A Deep Q-Network (DQN) that learns via trial-and-error. It is used in our "Chess Arena" to train the AI's reasoning, and in our "Tool Selector" to learn which tools to use.
- **Tensor RAG**: Converts uploaded text files into dense vector embeddings using Numpy/PyTorch, searchable via Cosine Similarity.

### 3. Advanced Features & Functions
- **Omni-Logger & Console Router**: Tracks every token, thought, and tool usage. Catches tracebacks and routes terminal commands safely without crashing the GUI.
- **Multi-Agent Personas**: Two distinct agents, "Ashley" (Coding/Writing) and "Cortana" (System/Research), with persistent memory and distinct voice filters.
- **Voice & Audio Studio**: Includes vocal separation, heuristic music generation, and a Karaoke mode with synchronized lyrics.
- **Smart Backups**: Hashes the project directory and only creates a zip backup if files have actually changed.

### Your Task:
Based on this architecture, I need you to write the Python code to extend the system. Please provide robust, error-free scripts that integrate with the `ModuleManager` (Hooks/Wheels) and utilize the existing PyTorch/Numpy dependencies. Ensure all tracebacks are caught and routed to the `ConsoleRouter`.

**PROMPT END**