class ModuleManager:
    """
    Finalizes the architecture by managing Hooks, Wheels, and Handles.
    - Hooks: Event triggers (e.g., pre_chat, post_chat, on_error).
    - Wheels: Pluggable modules (e.g., MediaGenerator, InternalBrowser).
    - Handles: Identifiers for specific functions or routes.
    """
    def __init__(self):
        self.hooks = {
            "pre_chat": [],
            "post_chat": [],
            "on_error": [],
            "pre_backup": []
        }
        self.wheels = {}
        self.handles = {}

    def register_hook(self, event_name, callback):
        """Registers a function to be called when an event occurs."""
        if event_name in self.hooks:
            self.hooks[event_name].append(callback)
            print(f"[ModuleManager] Registered hook for '{event_name}'")

    def trigger_hook(self, event_name, *args, **kwargs):
        """Triggers all callbacks associated with an event."""
        for callback in self.hooks.get(event_name, []):
            callback(*args, **kwargs)

    def load_wheel(self, wheel_name, module_instance):
        """Loads a pluggable module (Wheel) into the system."""
        self.wheels[wheel_name] = module_instance
        print(f"[ModuleManager] Loaded wheel: {wheel_name}")

    def get_wheel(self, wheel_name):
        return self.wheels.get(wheel_name)

    def register_handle(self, handle_id, function_ref):
        """Registers a specific function handle for routing."""
        self.handles[handle_id] = function_ref
        print(f"[ModuleManager] Registered handle: {handle_id}")