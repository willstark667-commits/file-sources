import os
import sys

# Add the current directory to the path so imports work correctly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.persona_manager import PersonaManager
from gui.hybrid_shell import HybridShell
from core.file_manager import AdvancedFileManager
from core.neural_builder import NeuralNetworkBuilder
from core.web_research import WebResearchAgent
from core.self_improvement import SelfImprovementLoop
from core.backup_system import BackupManager
from core.internal_browser import InternalBrowser
from core.media_generator import MediaGenerator

def main():
    print("==================================================")
    print("        Initializing Ashley AI Studio V2          ")
    print("==================================================")
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Initialize Core Modules
    persona_manager = PersonaManager()
    file_manager = AdvancedFileManager(base_dir)
    neural_builder = NeuralNetworkBuilder()
    web_research = WebResearchAgent()
    internal_browser = InternalBrowser()
    media_generator = MediaGenerator(os.path.join(base_dir, "data"))
    
    # 2. Initialize Self-Improvement & Backups
    backup_dir = os.path.join(base_dir, "backups")
    backup_manager = BackupManager(base_dir, backup_dir)
    self_improvement = SelfImprovementLoop(base_dir)
    
    # 3. Create an initial startup backup
    backup_manager.create_backup("startup_v2")
    
    # 4. Run a quick self-diagnostic cycle
    issues = self_improvement.analyze_codebase()
    patch = self_improvement.generate_patch(issues)
    self_improvement.apply_patch(patch)
    
    # 5. Launch the Hybrid GUI (Pygame / Tkinter)
    print("\n[System] Launching Studio Interface V2...")
    shell = HybridShell(persona_manager)
    shell.run()

if __name__ == "__main__":
    main()