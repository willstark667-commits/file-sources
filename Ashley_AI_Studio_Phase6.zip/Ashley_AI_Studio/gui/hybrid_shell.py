import os
import sys
import tkinter as tk
from tkinter import scrolledtext

try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False

class HybridShell:
    """
    A hybrid GUI that attempts to use Pygame for a rich, hardware-accelerated interface,
    but falls back to Tkinter if Pygame is unavailable or fails to initialize (e.g., headless servers).
    """
    def __init__(self, persona_manager):
        self.persona_manager = persona_manager
        self.mode = "pygame" if PYGAME_AVAILABLE else "tkinter"

    def run(self):
        if self.mode == "pygame":
            try:
                self._run_pygame()
            except Exception as e:
                print(f"Pygame failed to initialize: {e}. Falling back to Tkinter.")
                self.mode = "tkinter"
                self._run_tkinter()
        else:
            self._run_tkinter()

    def _run_pygame(self):
        pygame.init()
        screen = pygame.display.set_mode((800, 600))
        pygame.display.set_caption(f"AI Studio - {self.persona_manager.current_persona['name']}")
        
        font = pygame.font.SysFont("consolas", 16)
        clock = pygame.time.Clock()
        running = True
        
        input_text = ""
        chat_log = [f"System: Welcome to AI Studio. Active Persona: {self.persona_manager.current_persona['name']}"]

        while running:
            screen.fill((30, 30, 30)) # Dark background
            
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        chat_log.append(f"User: {input_text}")
                        chat_log.append(f"{self.persona_manager.current_persona['name']}: Processing...")
                        input_text = ""
                    elif event.key == pygame.K_BACKSPACE:
                        input_text = input_text[:-1]
                    else:
                        input_text += event.unicode

            # Render Chat Log
            y_offset = 20
            for line in chat_log[-20:]: # Show last 20 lines
                text_surface = font.render(line, True, (0, 255, 0))
                screen.blit(text_surface, (20, y_offset))
                y_offset += 25

            # Render Input Box
            pygame.draw.rect(screen, (50, 50, 50), (20, 550, 760, 30))
            input_surface = font.render(f"> {input_text}", True, (255, 255, 255))
            screen.blit(input_surface, (25, 555))

            pygame.display.flip()
            clock.tick(30)
            
        pygame.quit()

    def _run_tkinter(self):
        root = tk.Tk()
        root.title(f"AI Studio - {self.persona_manager.current_persona['name']} (Tkinter Fallback)")
        root.geometry("800x600")
        root.configure(bg="#1e1e1e")

        chat_area = scrolledtext.ScrolledText(root, bg="#1e1e1e", fg="#00ff00", font=("Consolas", 12))
        chat_area.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        chat_area.insert(tk.END, f"System: Welcome to AI Studio. Active Persona: {self.persona_manager.current_persona['name']}\n")
        chat_area.configure(state='disabled')

        input_var = tk.StringVar()
        input_box = tk.Entry(root, textvariable=input_var, bg="#333333", fg="#ffffff", font=("Consolas", 12))
        input_box.pack(padx=10, pady=10, fill=tk.X)

        def on_enter(event):
            user_text = input_var.get()
            if not user_text: return
            
            chat_area.configure(state='normal')
            chat_area.insert(tk.END, f"User: {user_text}\n")
            chat_area.insert(tk.END, f"{self.persona_manager.current_persona['name']}: Processing...\n")
            chat_area.see(tk.END)
            chat_area.configure(state='disabled')
            input_var.set("")

        input_box.bind("<Return>", on_enter)
        root.mainloop()