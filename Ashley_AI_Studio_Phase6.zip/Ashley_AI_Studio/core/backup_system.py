import os
import shutil
import datetime

class BackupManager:
    """
    Handles automatic backups of the AI Studio before self-improvement patches are applied.
    Ensures that previous versions and original programs are never lost.
    """
    def __init__(self, project_dir, backup_dir):
        self.project_dir = project_dir
        self.backup_dir = backup_dir
        os.makedirs(self.backup_dir, exist_ok=True)

    def create_backup(self, version_tag="auto"):
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"backup_{version_tag}_{timestamp}"
        backup_path = os.path.join(self.backup_dir, backup_name)
        
        print(f"[BackupManager] Creating backup: {backup_name}...")
        
        try:
            # Create a zip archive of the project directory
            shutil.make_archive(backup_path, 'zip', self.project_dir)
            print(f"[BackupManager] Backup saved successfully to {backup_path}.zip")
            return f"{backup_path}.zip"
        except Exception as e:
            print(f"[BackupManager] Failed to create backup: {e}")
            return None