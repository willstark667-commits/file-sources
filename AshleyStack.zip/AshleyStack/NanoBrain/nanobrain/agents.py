"""
Three internal agents, each a full (Network + Persona) pair, wired
into one shared GlobalWorkspace ("multiplayer workspace" -- more than
one agent able to work on the same task/request, each seeing the
others' broadcast "thoughts"):

  - Ashley   -- warm, expressive persona (unchanged from earlier build)
  - Cortana  -- logical, terse counterpart persona (new)
  - Generic  -- an unbranded baseline agent, useful as a template for
                spinning up further agents, and as a control to compare
                Ashley/Cortana's persona-shaped behavior against

Each agent:
  - owns its own Network (nodes, training, own file assignments)
  - owns its own Persona (trait weights, keyword tracking)
  - registers with the shared GlobalWorkspace so it can propose
    "thoughts" (e.g. a high-confidence prediction, a keyword hit, a
    training-completion event) and receive broadcasts from the other
    agents' proposals

This is the concrete "hierarchy and architecture" for multi-agent
coordination: siblings under one workspace, not one agent controlling
the others.
"""

import random

from .network import Network
from .persona import Persona
from .workspace import GlobalWorkspace


class Agent:
    def __init__(self, name, persona: Persona, workspace: GlobalWorkspace, num_nodes=3):
        self.name = name
        self.persona = persona
        self.network = Network(num_nodes=num_nodes)
        self.workspace = workspace
        self.inbox = []  # broadcasts received from other agents this session

        workspace.register(name, self._on_broadcast)

    def _on_broadcast(self, item):
        """Called by the GlobalWorkspace when another agent's proposal
        wins a cycle. This agent can react to it (or just log it)."""
        self.inbox.append(item.to_dict())
        if len(self.inbox) > 50:
            self.inbox.pop(0)

    def think_and_propose(self, stimulus_bit=None):
        """One 'thinking' step: run the network on a stimulus, and if
        the result is confident/salient enough, propose it to the
        shared workspace so other agents can see it."""
        bit = stimulus_bit if stimulus_bit is not None else random.choice([0, 1])
        output = self.network.predict_next(bit)
        avg_conf = sum(n.confidence for n in self.network.nodes) / len(self.network.nodes)

        # salience = how much this agent "wants" to broadcast this --
        # tied to its own confidence, so uncertain agents defer to
        # more confident ones during the workspace's competition step
        salience = avg_conf * abs(output - 0.5) * 2
        self.workspace.propose(
            source=self.name,
            content={"stimulus": bit, "output": round(output, 4), "agent": self.name},
            salience=salience,
            item_type="thought",
        )
        return output, salience

    def status(self):
        s = self.network.status()
        s["name"] = self.name
        s["persona_traits"] = self.persona.traits
        s["inbox_size"] = len(self.inbox)
        return s


def build_default_hierarchy(workspace=None):
    """Creates the three standard agents sharing one workspace."""
    workspace = workspace or GlobalWorkspace(capacity=1, buffer_size=7)

    ashley_persona = Persona.load_or_create_ashley()

    cortana_persona = Persona(
        name="Cortana",
        role=("a logical, terse AI persona/agent -- Ashley's counterpart: "
              "precise and economical where Ashley leans warm and expressive"),
        traits={"identity": 0.6, "language": 0.6, "coding": 0.75, "reasoning": 0.8,
                "creativity": 0.35, "memory": 0.7, "planning": 0.75, "warmth": 0.3, "logic": 0.85},
    )

    generic_persona = Persona(
        name="Generic",
        role="an unbranded baseline internal agent, with neutral default trait weights -- useful as a template and as a control for comparing persona-shaped behavior",
        traits={k: 0.5 for k in ["identity", "language", "coding", "reasoning",
                                  "creativity", "memory", "planning", "warmth", "logic"]},
    )

    ashley = Agent("Ashley", ashley_persona, workspace)
    cortana = Agent("Cortana", cortana_persona, workspace)
    generic = Agent("Generic", generic_persona, workspace)

    return {"Ashley": ashley, "Cortana": cortana, "Generic": generic}, workspace
