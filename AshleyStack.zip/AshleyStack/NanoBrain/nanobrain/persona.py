"""
Persona = a stored, weighted trait profile plus a keyword tracker --
not a claim that personality lives inside the toy neuron weights.
This is the same mechanism real persona-driven assistants use: an
identity profile that shapes the system prompt handed to the language
model (here, Ollama), plus a memory of what's been said/found about
that persona so it can be searched later.
"""

import json
import os
import time

from . import config

DEFAULT_KEYWORDS = [
    "ashley", "ashley ai", "ashley agent", "ashley studio",
    "cortana", "persona", "ai agent", "internal neural network",
]


class Persona:
    def __init__(self, name, role, traits=None, keywords=None):
        self.name = name
        self.role = role
        # trait -> weight 0.0-1.0, mirrors the "identity 60%, language 80%..." idea
        self.traits = traits or {
            "identity": 0.6, "language": 0.7, "coding": 0.5,
            "reasoning": 0.6, "creativity": 0.6, "memory": 0.6,
            "planning": 0.5, "warmth": 0.7, "logic": 0.5,
        }
        self.keywords = list(dict.fromkeys((keywords or []) + DEFAULT_KEYWORDS))

    def system_prompt(self):
        trait_desc = ", ".join(f"{k}={v:.0%}" for k, v in self.traits.items())
        return (
            f"You are {self.name}, {self.role}. "
            f"Your current trait profile: {trait_desc}. "
            f"Respond in a way consistent with these traits."
        )

    def add_keyword(self, kw):
        kw = kw.strip().lower()
        if kw and kw not in self.keywords:
            self.keywords.append(kw)

    def adjust_trait(self, trait, delta):
        current = self.traits.get(trait, 0.5)
        self.traits[trait] = max(0.0, min(1.0, current + delta))

    def to_dict(self):
        return {"name": self.name, "role": self.role, "traits": self.traits, "keywords": self.keywords}

    @classmethod
    def from_dict(cls, d):
        return cls(d["name"], d["role"], d.get("traits"), d.get("keywords"))

    def save(self, path=None):
        path = path or config.PERSONA_FILE
        with open(path, "w") as fh:
            json.dump(self.to_dict(), fh, indent=2)

    @classmethod
    def load_or_create_ashley(cls, path=None):
        path = path or config.PERSONA_FILE
        if os.path.exists(path):
            with open(path, "r") as fh:
                return cls.from_dict(json.load(fh))
        ashley = cls(
            name="Ashley",
            role=("a warm, human-leaning AI persona/agent -- Cortana's counterpart: "
                  "more expressive and personable where Cortana leans logical"),
            traits={"identity": 0.6, "language": 0.75, "coding": 0.55, "reasoning": 0.6,
                    "creativity": 0.65, "memory": 0.6, "planning": 0.5, "warmth": 0.8, "logic": 0.45},
        )
        ashley.save(path)
        return ashley


class KeywordTracker:
    """Scans text (file previews, chat messages) for tracked keywords
    and keeps counts + first/last seen -- lets you ask 'what have we
    found related to Ashley' later."""

    def __init__(self, keywords=None, path=None):
        self.path = path or config.KEYWORD_FILE
        self.hits = {}  # keyword -> {"count": int, "first_seen": str, "last_seen": str, "sources": [str]}
        self.keywords = list(keywords or DEFAULT_KEYWORDS)
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, "r") as fh:
                data = json.load(fh)
                self.hits = data.get("hits", {})
                self.keywords = data.get("keywords", self.keywords)

    def save(self):
        with open(self.path, "w") as fh:
            json.dump({"keywords": self.keywords, "hits": self.hits}, fh, indent=2)

    def add_keyword(self, kw):
        kw = kw.strip().lower()
        if kw and kw not in self.keywords:
            self.keywords.append(kw)
            self.save()

    def scan_text(self, text, source):
        if not text:
            return []
        text_lower = text.lower()
        found = []
        now = time.strftime("%Y-%m-%d %H:%M:%S")
        for kw in self.keywords:
            if kw in text_lower:
                entry = self.hits.setdefault(kw, {"count": 0, "first_seen": now, "last_seen": now, "sources": []})
                entry["count"] += 1
                entry["last_seen"] = now
                if source not in entry["sources"]:
                    entry["sources"].append(source)
                    if len(entry["sources"]) > 25:
                        entry["sources"].pop(0)
                found.append(kw)
        if found:
            self.save()
        return found

    def report(self):
        return {kw: v for kw, v in sorted(self.hits.items(), key=lambda kv: -kv[1]["count"])}
