"""
Wires a handful of Neuron nodes into a simple chain and trains them in
two phases, per the original design:

  1. Node-local pretraining -- each node trains alone first.
  2. Joint training -- the whole chain trains together afterward.

The toy task here is next-bit prediction over a small binary sequence
(a real, tiny, honestly-scoped stand-in for "the network learns
patterns from data"). It is not a language model. It's small enough to
run instantly and to actually watch learn.
"""

import json
import random

from . import config
from .neuron import Neuron


class Network:
    def __init__(self, num_nodes=None):
        num_nodes = num_nodes or config.MIN_NODES
        num_nodes = max(config.MIN_NODES, min(config.MAX_NODES, num_nodes))
        self.nodes = [Neuron(i) for i in range(num_nodes)]
        self.generation = 0
        self.training_steps = 0
        self.loss_history = []

    # -- scaling nodes to indexed file count -----------------------------
    @classmethod
    def sized_for_file_count(cls, file_count):
        """More scanned files -> more nodes, within sane prototype bounds."""
        n = max(config.MIN_NODES, min(config.MAX_NODES, 1 + file_count // config.FILES_PER_NODE))
        return cls(num_nodes=n)

    def grow(self):
        """Add one more node, up to the max, with the next free id."""
        if len(self.nodes) >= config.MAX_NODES:
            return None
        new_id = max(n.id for n in self.nodes) + 1
        node = Neuron(new_id)
        self.nodes.append(node)
        return node

    # -- toy training data -------------------------------------------------
    @staticmethod
    def _toy_sequence(length=16):
        """A simple repeating pattern with a bit of noise -- something a
        tiny chain of nodes can actually learn to predict."""
        base = [1, 0, 1, 1, 0, 0, 1, 0]
        seq = (base * ((length // len(base)) + 1))[:length]
        return seq

    # -- prediction of how many nodes a scan will need, with ETA ----------
    @staticmethod
    def predict_nodes_and_eta(file_count, epochs_per_node=None):
        epochs_per_node = epochs_per_node or config.TRAIN_EPOCHS_PER_STEP
        needed = max(config.MIN_NODES, min(config.MAX_NODES, 1 + file_count // config.FILES_PER_NODE))
        eta_seconds = needed * epochs_per_node * config.SECONDS_PER_EPOCH_ESTIMATE * 40
        return {"predicted_nodes": needed, "eta_seconds": round(eta_seconds, 2)}

    def generate_nodes_incrementally(self, target_count, on_node_created=None):
        """Add nodes one at a time up to target_count, calling
        on_node_created(node) after each so a GUI can update live
        (progress bar, 2D visualizer, etc.) instead of blocking."""
        created = []
        while len(self.nodes) < target_count and len(self.nodes) < config.MAX_NODES:
            node = self.grow()
            if node is None:
                break
            created.append(node)
            if on_node_created:
                on_node_created(node)
        return created

    # -- dividing scanned files across nodes for organized, parallel-feeling
    #    per-node training -------------------------------------------------
    def divide_files_across_nodes(self, file_records):
        """Round-robin assignment: each node gets its own slice of the
        scanned files, mirroring the 'divide and separate directories
        per node' idea. Purely organizational -- files are not moved,
        only their paths are recorded per node."""
        buckets = {n.id: [] for n in self.nodes}
        for i, record in enumerate(file_records):
            node = self.nodes[i % len(self.nodes)]
            buckets[node.id].append(record)
        for node in self.nodes:
            node.assign_files(buckets[node.id])
        return {nid: len(files) for nid, files in buckets.items()}

    # -- pretrain nodes ONE AT A TIME, with per-epoch logging --------------
    def pretrain_nodes_sequentially(self, epochs=None, on_epoch=None, on_node_done=None):
        """Like pretrain_nodes_independently, but processes one node at a
        time and reports every epoch -- so a GUI can show a live
        progress bar / ETA / status per node instead of a single blocking
        call. on_epoch(node, epoch, loss) and on_node_done(node, report)
        are optional callbacks."""
        epochs = epochs or config.TRAIN_EPOCHS_PER_STEP
        seq = self._toy_sequence()
        results = {}
        for node in self.nodes:
            last_loss = 0.0
            for epoch in range(epochs):
                x = random.choice(seq)
                target = 1 - x if random.random() < 0.5 else x
                out = node.activate(float(x))
                error = out - float(target)
                node.nudge(error, config.LEARNING_RATE)
                last_loss = error * error
                node.log_epoch(epoch, last_loss)
                if on_epoch:
                    on_epoch(node, epoch, last_loss)

            # "grokking" pass: if this node converged well, keep training
            # extra epochs past the normal budget and log it distinctly
            grokked = False
            if last_loss < config.GROK_LOSS_THRESHOLD:
                grokked = True
                for extra_epoch in range(config.GROK_EXTRA_EPOCHS):
                    x = random.choice(seq)
                    target = 1 - x if random.random() < 0.5 else x
                    out = node.activate(float(x))
                    error = out - float(target)
                    node.nudge(error, config.LEARNING_RATE * 0.3)  # gentler grok-phase LR
                    last_loss = error * error
                    node.log_epoch(epochs + extra_epoch, last_loss)

            report = {"final_loss": round(last_loss, 5), "grokked": grokked,
                      "files_trained_on": len(node.assigned_files)}
            results[node.id] = report
            if on_node_done:
                on_node_done(node, report)
        return results

    def pretrain_nodes_independently(self, epochs=None):
        epochs = epochs or config.TRAIN_EPOCHS_PER_STEP
        seq = self._toy_sequence()
        report = {}
        for node in self.nodes:
            local_loss = 0.0
            for _ in range(epochs):
                x = random.choice(seq)
                target = 1 - x if random.random() < 0.5 else x  # local noisy task
                out = node.activate(float(x))
                error = out - float(target)
                node.nudge(error, config.LEARNING_RATE)
                local_loss = error * error
            report[node.id] = round(local_loss, 5)
        return report

    # -- phase 2: joint training across the whole chain --------------------
    def train_joint(self, epochs=None):
        epochs = epochs or config.TRAIN_EPOCHS_PER_STEP
        seq = self._toy_sequence()
        losses = []
        for step in range(epochs):
            idx = random.randint(0, len(seq) - 2)
            x = float(seq[idx])
            target = float(seq[idx + 1])

            signal = x
            for node in self.nodes:
                signal = node.activate(signal)

            error = signal - target
            for node in self.nodes:
                node.nudge(error, config.LEARNING_RATE)

            loss = error * error
            losses.append(loss)
            self.training_steps += 1

        self.generation += 1
        avg_loss = sum(losses) / len(losses) if losses else 0.0
        self.loss_history.append(round(avg_loss, 5))
        if len(self.loss_history) > 50:
            self.loss_history.pop(0)
        return avg_loss

    def predict_next(self, bit: int) -> float:
        signal = float(bit)
        for node in self.nodes:
            signal = node.activate(signal)
        return signal

    # -- status / self-evaluation ------------------------------------------
    def status(self):
        avg_conf = sum(n.confidence for n in self.nodes) / len(self.nodes)
        maturity_pct = round(min(100.0, (self.training_steps / 500) * 100), 1)
        return {
            "nodes": len(self.nodes),
            "generation": self.generation,
            "training_steps": self.training_steps,
            "avg_confidence": round(avg_conf, 3),
            "last_loss": self.loss_history[-1] if self.loss_history else None,
            "maturity_pct": maturity_pct,
        }

    # -- persistence ----------------------------------------------------
    def save(self, path=None):
        path = path or config.CHECKPOINT_FILE
        data = {
            "generation": self.generation,
            "training_steps": self.training_steps,
            "loss_history": self.loss_history,
            "nodes": [n.to_dict() for n in self.nodes],
        }
        with open(path, "w") as fh:
            json.dump(data, fh, indent=2)
        return path

    @classmethod
    def load(cls, path=None):
        path = path or config.CHECKPOINT_FILE
        with open(path, "r") as fh:
            data = json.load(fh)
        net = cls.__new__(cls)
        net.generation = data["generation"]
        net.training_steps = data["training_steps"]
        net.loss_history = data["loss_history"]
        net.nodes = [Neuron.from_dict(d) for d in data["nodes"]]
        return net
