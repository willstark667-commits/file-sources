"""
Global Workspace -- an implementation of the *architecture pattern*
described by Global Workspace Theory (Baars/Dehaene), not a claim of
machine consciousness.

The pattern, concretely:
  1. Multiple "specialists" (here: neuron-nodes, personas/agents, or
     any callable that can score+propose content) run independently
     and in parallel.
  2. Each specialist can post a candidate item to the workspace with
     a salience score ("how much do I want this broadcast right now").
  3. Competition: the highest-salience item(s) within a cycle win
     access to the shared workspace.
  4. Broadcast: the winning item is pushed out to *all* registered
     specialists (a callback), and kept in a small persistent buffer
     ("mental whiteboard" / working-memory analog) so it stays
     available for a few cycles even if nothing currently needs it --
     this is the concrete version of "a word lights up and is kept in
     mind even if not going to be used yet."

What this is NOT:
  - Not a claim that broadcasting = subjective experience. That's an
    open, contested research question (see README note on the
    "logit lens" interpretability technique, which is the real
    existing tool closest to what you described as words "lighting
    up").
  - Not AGI. This is a coordination/scheduling pattern, same rough
    shape as a shared blackboard system or a pub/sub bus with a
    scarcity constraint (only N winners per cycle) -- the scarcity is
    what makes it GWT-flavored rather than plain pub/sub.
"""

import json
import time
import threading

from . import config


class WorkspaceItem:
    def __init__(self, source, content, salience, item_type="thought"):
        self.source = source          # which specialist proposed this (node id / agent name)
        self.content = content        # arbitrary payload: text, vector, file ref, etc.
        self.salience = salience      # float, higher = more likely to win competition
        self.item_type = item_type    # "thought" | "perception" | "goal" | "memory" | "action"
        self.created_at = time.time()
        self.broadcast_count = 0      # how many cycles it has stayed in the spotlight

    def to_dict(self):
        return {
            "source": self.source, "content": self.content, "salience": self.salience,
            "item_type": self.item_type, "created_at": self.created_at,
            "broadcast_count": self.broadcast_count,
        }


class GlobalWorkspace:
    """The shared bottleneck. Specialists register a callback; each
    cycle, competing proposals are collected, the winner(s) broadcast
    to every registered callback, and a small buffer of recent winners
    persists as working memory (decays over cycles, not instantly)."""

    def __init__(self, capacity=1, buffer_size=7, decay_per_cycle=0.85):
        self.capacity = capacity              # how many items can win per cycle (GWT: usually ~1)
        self.buffer_size = buffer_size        # "7 +/- 2" working-memory-sized buffer, deliberately
        self.decay_per_cycle = decay_per_cycle

        self._specialists = {}   # name -> callback(item)
        self._proposals = []     # pending WorkspaceItem this cycle
        self._buffer = []        # recently broadcast items, salience decays each cycle
        self._lock = threading.Lock()
        self._cycle_count = 0
        self._log = []           # history of what won, for diagnostics/replay

    # -- registration --------------------------------------------------
    def register(self, name, callback):
        """A specialist (a node, a persona/agent, a tool) subscribes to
        broadcasts. callback receives a WorkspaceItem."""
        self._specialists[name] = callback

    def unregister(self, name):
        self._specialists.pop(name, None)

    # -- proposing (the "competition" side) -----------------------------
    def propose(self, source, content, salience, item_type="thought"):
        with self._lock:
            self._proposals.append(WorkspaceItem(source, content, salience, item_type))

    # -- running one competition + broadcast cycle -----------------------
    def run_cycle(self):
        with self._lock:
            candidates = self._proposals + self._buffer
            self._proposals = []

            if not candidates:
                self._decay_buffer()
                self._cycle_count += 1
                return []

            candidates.sort(key=lambda it: it.salience, reverse=True)
            winners = candidates[: self.capacity]

            for w in winners:
                w.broadcast_count += 1

            # broadcast winners to every registered specialist
            for w in winners:
                for name, callback in list(self._specialists.items()):
                    if name == w.source:
                        continue  # don't echo back to the proposer
                    try:
                        callback(w)
                    except Exception as e:
                        # a broken specialist must never take down the workspace
                        self._log.append({"cycle": self._cycle_count, "error": f"{name}: {e}"})

            # winners persist into the buffer (working memory), others fade
            self._buffer = winners + [c for c in self._buffer if c not in winners]
            self._buffer = self._buffer[: self.buffer_size]
            self._decay_buffer()

            self._log.append({
                "cycle": self._cycle_count,
                "winners": [w.to_dict() for w in winners],
            })
            if len(self._log) > 200:
                self._log.pop(0)

            self._cycle_count += 1
            return winners

    def _decay_buffer(self):
        for item in self._buffer:
            item.salience *= self.decay_per_cycle
        self._buffer = [it for it in self._buffer if it.salience > 0.05]

    # -- introspection ("what's currently in mind") ------------------------
    def whiteboard(self):
        """The current working-memory buffer -- items still 'in mind'
        even if they didn't win this exact cycle."""
        return [it.to_dict() for it in self._buffer]

    def status(self):
        return {
            "cycle": self._cycle_count,
            "specialists": list(self._specialists.keys()),
            "buffer_size": len(self._buffer),
            "recent_winners": self._log[-5:],
        }

    def save_log(self, path=None):
        path = path or (config.DATA_DIR + "/workspace_log.json")
        with open(path, "w") as fh:
            json.dump(self._log, fh, indent=2)
        return path
