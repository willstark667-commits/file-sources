"""
Thin Ollama client using only the standard library (urllib) -- no
extra pip dependency required just to talk to a local Ollama server.

Used for two things in this project:
  1. Chat responses (the actual "intelligence" behind the persona).
  2. As a lightweight "management" pass over scan/training results --
     asking the model to summarize what a batch of files are about,
     or to give a one-line status readout of the network's progress.

If Ollama isn't running (or the model isn't pulled), every call fails
soft and returns a clear explanatory string instead of raising into
the GUI.
"""

import json
import urllib.request
import urllib.error

from . import config


class OllamaError(Exception):
    pass


def _post(path, payload, timeout=30):
    url = config.OLLAMA_HOST.rstrip("/") + path
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.URLError as e:
        raise OllamaError(f"can't reach Ollama at {config.OLLAMA_HOST} ({e}). "
                           f"Is `ollama serve` running, and is '{config.OLLAMA_MODEL}' pulled?") from e


def is_available():
    try:
        req = urllib.request.Request(config.OLLAMA_HOST.rstrip("/") + "/api/tags")
        with urllib.request.urlopen(req, timeout=2):
            return True
    except Exception:
        return False


def chat(messages, model=None, system=None):
    """messages: list of {"role": "user"/"assistant", "content": str}
    Returns the assistant's reply text, or a clear fallback string."""
    model = model or config.OLLAMA_MODEL
    payload_messages = []
    if system:
        payload_messages.append({"role": "system", "content": system})
    payload_messages.extend(messages)

    try:
        result = _post("/api/chat", {
            "model": model,
            "messages": payload_messages,
            "stream": False,
        })
        return result.get("message", {}).get("content", "").strip() or "(empty response from Ollama)"
    except OllamaError as e:
        return f"[Ollama unavailable] {e}"


def summarize(text, instruction="Summarize this in one or two sentences.", model=None):
    """Used as the 'management system' pass -- e.g. summarizing what a
    node's batch of assigned files are about."""
    model = model or config.OLLAMA_MODEL
    try:
        result = _post("/api/generate", {
            "model": model,
            "prompt": f"{instruction}\n\n{text}",
            "stream": False,
        })
        return result.get("response", "").strip() or "(no summary produced)"
    except OllamaError as e:
        return f"[Ollama unavailable] {e}"
