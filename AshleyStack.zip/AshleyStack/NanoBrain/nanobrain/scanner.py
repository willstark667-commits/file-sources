"""
Non-destructive file scanner. Golden rule, carried straight over from
the design docs: never modify original file content. This only reads
metadata (and, for small text files, a short preview) and writes that
information into a separate index file -- the source files themselves
are never touched.
"""

import os
import json
import hashlib
import time

from . import config

TEXT_EXTENSIONS = {".txt", ".md", ".py", ".json", ".csv", ".log"}
ARCHIVE_EXTENSIONS = {".zip", ".rar", ".7z", ".tar", ".gz", ".xz", ".iso"}


def _hash_file(path, block_size=65536):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while chunk := f.read(block_size):
                h.update(chunk)
        return h.hexdigest()[:16]
    except (OSError, PermissionError):
        return None


def scan_directory(root=None, max_files=500):
    """Walk `root` (default: the project's own workspace/ folder) and
    build metadata records. Read-only: never writes to, renames, or
    deletes anything under `root`.
    """
    root = root or config.WORKSPACE_DIR
    records = []
    count = 0
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            if count >= max_files:
                break
            full = os.path.join(dirpath, name)
            ext = os.path.splitext(name)[1].lower()
            try:
                stat = os.stat(full)
            except OSError:
                continue

            record = {
                "filename": name,
                "path": full,
                "extension": ext,
                "size_bytes": stat.st_size,
                "modified": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(stat.st_mtime)),
                "hash": _hash_file(full),
                "is_archive": ext in ARCHIVE_EXTENSIONS,
                "preview": None,
            }
            if ext in TEXT_EXTENSIONS and stat.st_size < 20000:
                try:
                    with open(full, "r", errors="ignore") as fh:
                        record["preview"] = fh.read(200)
                except OSError:
                    pass

            records.append(record)
            count += 1
        if count >= max_files:
            break

    _save_index(records)
    return records


def _save_index(records):
    with open(config.SCAN_INDEX_FILE, "w") as fh:
        json.dump({"scanned_at": time.strftime("%Y-%m-%d %H:%M:%S"), "files": records}, fh, indent=2)


def load_index():
    if not os.path.exists(config.SCAN_INDEX_FILE):
        return []
    with open(config.SCAN_INDEX_FILE, "r") as fh:
        return json.load(fh).get("files", [])


def search_keyword(keyword, records=None):
    records = records if records is not None else load_index()
    keyword_lower = keyword.lower()
    hits = []
    for r in records:
        if keyword_lower in r["filename"].lower() or (r["preview"] and keyword_lower in r["preview"].lower()):
            hits.append(r)
    return hits
