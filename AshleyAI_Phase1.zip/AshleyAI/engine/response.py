import random
from database.database import search_words

def generate_response(message):
    """Very basic response generator."""
    msg_lower = message.lower().strip()
    
    if any(g in msg_lower for g in ['hello', 'hi', 'hey']):
        return "Hello! How can I help you today?"
    elif any(q in msg_lower for q in ['how are you', 'how r u']):
        return "I'm doing well, thanks for asking! And you?"
    elif '?' in message:
        return "That's an interesting question. Let me think..."
    elif any(w in msg_lower for w in ['thank', 'thanks']):
        return "You're welcome!"
    else:
        # Simple echo or default
        words = search_words(msg_lower[:10])
        if words:
            return f"I recognize words like {words[0]['word']}. Tell me more!"
        return "I'm still learning. What would you like to talk about?"