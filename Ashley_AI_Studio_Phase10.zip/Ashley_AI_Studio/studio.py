import os
import sys

# Add the current directory to the path so imports work correctly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from core.persona_manager import PersonaManager
from gui.pyweb_shell import PyWebShell
from core.file_manager import AdvancedFileManager
from core.neural_builder import NeuralNetworkBuilder
from core.web_research import WebResearchAgent
from core.self_improvement import SelfImprovementLoop
from core.backup_system import BackupManager
from core.internal_browser import InternalBrowser
from core.media_generator import MediaGenerator
from core.modules.module_manager import ModuleManager

def main():
    print("==================================================")
    print("        Initializing Ashley AI Studio V3          ")
    print("==================================================")
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    
    # 1. Initialize Core Modules
    module_manager = ModuleManager()
    persona_manager = PersonaManager()
    file_manager = AdvancedFileManager(base_dir)
    neural_builder = NeuralNetworkBuilder()
    web_research = WebResearchAgent()
    internal_browser = InternalBrowser()
    media_generator = MediaGenerator(os.path.join(base_dir, "data"))
    
    # 2. Initialize Self-Improvement & Backups
    backup_dir = os.path.join(base_dir, "backups")
    backup_manager = BackupManager(base_dir, backup_dir)
    self_improvement = SelfImprovementLoop(base_dir)
    
    # 3. Create an initial startup backup
    backup_manager.create_backup("startup_v3")
    
    # 4. Run a quick self-diagnostic cycle
    issues = self_improvement.analyze_codebase()
    patch = self_improvement.generate_patch(issues)
    self_improvement.apply_patch(patch)
    
    # 5. Launch the PyWebView GUI
    print("\n[System] Launching Studio Interface (PyWebView)...")
    shell = PyWebShell(engine=None, backup_manager=backup_manager)
    shell.run()

if __name__ == "__main__":
    main()