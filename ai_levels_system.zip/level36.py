
# Level 36: Self-Generating Symbolic Universe (simplified)

import random

SYMBOLS = ["A", "B", "C", "⊕", "⊗"]

def generate_rule():
    return {
        "input": random.choice(SYMBOLS),
        "output": random.choice(SYMBOLS),
        "op": random.choice(["replace", "duplicate"])
    }

def step(universe, rules):
    new = []
    for s in universe:
        applied = False
        for r in rules:
            if s == r["input"]:
                new.append(r["output"])
                applied = True
        if not applied:
            new.append(s)
    return new

def run():
    universe = SYMBOLS.copy()
    rules = [generate_rule() for _ in range(3)]
    for _ in range(5):
        universe = step(universe, rules)
        rules.append(generate_rule())
    return universe
