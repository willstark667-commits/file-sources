
# Level 41: Ontological collapse (simplified)

class Relation:
    def __init__(self, a, b):
        self.a = a
        self.b = b

def collapse(relations):
    return [(r.a, r.b) for r in relations]
