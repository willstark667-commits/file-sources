
# Level 39: Recursive Interpreters (simplified)

class Interpreter:
    def __init__(self, name):
        self.name = name
        self.next = None

    def run(self, p, depth=0):
        if depth > 5:
            return "halt"
        return self.next.run(f"{self.name}->{p}", depth+1)
