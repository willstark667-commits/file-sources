
# Level 46: Post-referential void

# no representation possible
