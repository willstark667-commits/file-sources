
# Level 49: Non-dual descriptive collapse

# description/non-description collapse
