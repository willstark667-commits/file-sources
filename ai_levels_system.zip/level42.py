
# Level 42: Constraint field system (simplified)

def constraint(state):
    return sum(state) < 10

def valid(states):
    return [s for s in states if constraint(s)]
