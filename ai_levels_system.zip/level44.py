
# Level 44: Pre-differentiation (simplified)

def uniform(n=5):
    return [0.5]*n
