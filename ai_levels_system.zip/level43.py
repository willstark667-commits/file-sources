
# Level 43: Pre-constraint emergence (simplified)

import random

def state():
    return [random.random() for _ in range(5)]

def perturb(s):
    i = random.randint(0, len(s)-1)
    s[i] += random.uniform(-0.1, 0.1)
    return s
