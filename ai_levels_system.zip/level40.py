
# Level 40: Non-well-founded semantics (simplified)

class Node:
    def __init__(self, name):
        self.name = name
        self.refs = []

def build(nodes):
    for i in range(len(nodes)):
        nodes[i].refs = [nodes[(i+1)%len(nodes)], nodes[i]]
    return nodes
