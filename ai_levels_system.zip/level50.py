
# Level 50: Unstatable boundary condition

# self-invalidating definition
