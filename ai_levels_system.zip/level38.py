
# Level 38: Recursive Interpreter Stack (simplified)

def interp(name, program):
    return f"{name}:{program}"

def cycle(program):
    a = lambda p: interp("A", p)
    b = lambda p: interp("B", p)
    c = lambda p: interp("C", p)

    return a(b(c(program)))
