
# AI Levels System Entry Point

from level36 import run as run36

def main():
    print("Running Level 36 demo:")
    print(run36())

if __name__ == "__main__":
    main()
