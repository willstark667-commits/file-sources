
# Level 47: Non-indexable absence

# no ordering
