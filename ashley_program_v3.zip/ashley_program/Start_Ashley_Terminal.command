#!/bin/bash
cd "$(dirname "$0")"
echo "==================================================="
echo "Starting Ashley AI Terminal Shell..."
echo "==================================================="
if [ ! -d "venv" ]; then
    echo "[First Time Setup] Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
echo "[Setup] Checking dependencies..."
pip install -r requirements.txt -q
echo "[Starting] Launching Terminal..."
python3 main.py --mode cli
