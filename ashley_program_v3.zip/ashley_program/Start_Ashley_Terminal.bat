@echo off
title Ashley Omni AI - Terminal Shell
echo ===================================================
echo Starting Ashley AI Terminal Shell...
echo ===================================================
if not exist venv (
    echo [First Time Setup] Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat
echo [Setup] Checking dependencies...
pip install -r requirements.txt -q
echo [Starting] Launching Terminal...
python main.py --mode cli
pause
