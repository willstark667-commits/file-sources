@echo off
title Ashley Omni AI - Web Interface
echo ===================================================
echo Starting Ashley AI Web Interface...
echo ===================================================
if not exist venv (
    echo [First Time Setup] Creating virtual environment...
    python -m venv venv
)
call venv\Scripts\activate.bat
echo [Setup] Checking dependencies...
pip install -r requirements.txt -q
echo [Starting] Launching Web Server...
start http://127.0.0.1:5000
python main.py --mode web --port 5000
pause
