#!/bin/bash
cd "$(dirname "$0")"
echo "==================================================="
echo "Starting Ashley AI Web Interface..."
echo "==================================================="
if [ ! -d "venv" ]; then
    echo "[First Time Setup] Creating virtual environment..."
    python3 -m venv venv
fi
source venv/bin/activate
echo "[Setup] Checking dependencies..."
pip install -r requirements.txt -q
echo "[Starting] Launching Web Server..."
sleep 2 && open http://127.0.0.1:5000 &
python3 main.py --mode web --port 5000
