# Ashley AI - Phase 1

Simple Tkinter-based chatbot with basic NLP features: scanner, tokenizer, SQLite database for words, sentences, patterns.

## Setup
1. Run `python Ashley.py` to start.
2. Use the GUI to chat, import files, train.

## Features
- Tkinter GUI chat shell
- SQLite databases (generic and ashley)
- Basic scanner and tokenizer
- Chat history
- File import (TXT, etc.)
- Simple rule-based responses
- Logging