import sqlite3
import os
from config import DATABASE_GENERIC, DATABASE_ASHLEY

def get_connection(db_path):
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_databases():
    # Generic DB
    conn = get_connection(DATABASE_GENERIC)
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS words (
            id INTEGER PRIMARY KEY,
            word TEXT UNIQUE,
            category TEXT,
            count INTEGER DEFAULT 1,
            last_seen TEXT
        );
        
        CREATE TABLE IF NOT EXISTS sentences (
            id INTEGER PRIMARY KEY,
            sentence TEXT UNIQUE,
            length INTEGER,
            count INTEGER DEFAULT 1
        );
        
        CREATE TABLE IF NOT EXISTS patterns (
            id INTEGER PRIMARY KEY,
            pattern TEXT UNIQUE,
            frequency INTEGER DEFAULT 1
        );
        
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY,
            speaker TEXT,
            message TEXT,
            timestamp TEXT
        );
    ''')
    conn.commit()
    conn.close()
    
    # Ashley DB (for personal memory)
    conn = get_connection(DATABASE_ASHLEY)
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS memory (
            id INTEGER PRIMARY KEY,
            fact TEXT,
            importance INTEGER,
            date TEXT
        );
    ''')
    conn.commit()
    conn.close()

def add_word(word, category='unknown'):
    conn = get_connection(DATABASE_GENERIC)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO words (word, category, count, last_seen)
        VALUES (?, ?, 1, datetime('now'))
        ON CONFLICT(word) DO UPDATE SET 
            count = count + 1,
            last_seen = datetime('now')
    ''', (word.lower(), category))
    conn.commit()
    conn.close()

def add_sentence(sentence):
    conn = get_connection(DATABASE_GENERIC)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO sentences (sentence, length, count)
        VALUES (?, ?, 1)
        ON CONFLICT(sentence) DO UPDATE SET count = count + 1
    ''', (sentence.strip(), len(sentence.split())))
    conn.commit()
    conn.close()

def add_pattern(pattern):
    conn = get_connection(DATABASE_GENERIC)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO patterns (pattern, frequency)
        VALUES (?, 1)
        ON CONFLICT(pattern) DO UPDATE SET frequency = frequency + 1
    ''', (pattern.strip(),))
    conn.commit()
    conn.close()

def get_chat_history(limit=50):
    conn = get_connection(DATABASE_GENERIC)
    cursor = conn.cursor()
    cursor.execute('SELECT speaker, message, timestamp FROM chat_history ORDER BY id DESC LIMIT ?', (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def save_chat_message(speaker, message):
    conn = get_connection(DATABASE_GENERIC)
    conn.execute('INSERT INTO chat_history (speaker, message, timestamp) VALUES (?, ?, datetime("now"))', 
                 (speaker, message))
    conn.commit()
    conn.close()

def search_words(query):
    conn = get_connection(DATABASE_GENERIC)
    cursor = conn.cursor()
    cursor.execute("SELECT word, category, count FROM words WHERE word LIKE ? ORDER BY count DESC LIMIT 20", (f'%{query}%',))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]