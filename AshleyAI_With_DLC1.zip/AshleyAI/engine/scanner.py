import re
from database.database import add_word, add_sentence
from tools.logger import log_info

def scan_text(text):
    """Basic scanner: normalize, split sentences and words."""
    if not text:
        return []
    
    # Normalize
    text = text.strip().lower()
    log_info(f"Scanning text: {text[:100]}...")
    
    # Split sentences (simple)
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    
    for sentence in sentences:
        add_sentence(sentence)
        words = re.findall(r'\b\w+\b', sentence)
        for word in words:
            add_word(word)
    
    return sentences, [w for s in sentences for w in re.findall(r'\b\w+\b', s)]