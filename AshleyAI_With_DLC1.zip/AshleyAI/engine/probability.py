from collections import defaultdict
import random
from database.database import get_connection

class ProbabilityEngine:
    def __init__(self):
        self.markov = defaultdict(lambda: defaultdict(int))
    
    def train_from_history(self):
        conn = get_connection('database/generic.db')
        cursor = conn.cursor()
        cursor.execute("SELECT message FROM chat_history WHERE speaker='User'")
        for row in cursor.fetchall():
            words = row[0].lower().split()
            for i in range(len(words)-1):
                self.markov[words[i]][words[i+1]] += 1
        conn.close()
    
    def predict_next(self, word):
        if word in self.markov and self.markov[word]:
            next_words = list(self.markov[word].keys())
            weights = list(self.markov[word].values())
            return random.choices(next_words, weights=weights, k=1)[0]
        return random.choice(['the', 'a', 'you', 'i', 'and'])

prob_engine = ProbabilityEngine()