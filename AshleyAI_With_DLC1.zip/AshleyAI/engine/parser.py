from engine.tokenizer import tokenize
from engine.scanner import scan_text
from database.database import add_pattern

def parse_message(message):
    """Parse user message."""
    tokens = tokenize(message)
    sentences, words = scan_text(message)
    
    # Simple pattern
    if len(tokens) > 2:
        pattern = ' '.join(tokens[:3])  # basic pattern
        add_pattern(pattern)
    
    return {
        'tokens': tokens,
        'sentences': sentences,
        'words': words
    }