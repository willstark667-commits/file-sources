import re

def tokenize(text):
    """Simple tokenizer."""
    if not text:
        return []
    # Split on whitespace and punctuation
    tokens = re.findall(r'\b\w+\b|[^\w\s]', text)
    return [t.strip() for t in tokens if t.strip()]