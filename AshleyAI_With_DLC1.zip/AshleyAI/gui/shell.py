import tkinter as tk
from tkinter import scrolledtext, messagebox, filedialog
from engine.chatbot import ChatBot
from tools.importer import import_file, import_all
from memory.history import get_recent_history
from database.database import init_databases, search_words
from tools.logger import log_info
import os
from config import IMPORTS_DIR

class AshleyShell:
    def __init__(self):
        init_databases()
        self.chatbot = ChatBot()
        
        self.root = tk.Tk()
        self.root.title("Ashley AI - Phase 1")
        self.root.geometry("800x600")
        
        # Menu
        menubar = tk.Menu(self.root)
        self.root.config(menu=menubar)
        
        file_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="File", menu=file_menu)
        file_menu.add_command(label="Import File", command=self.import_file_dialog)
        file_menu.add_command(label="Import All", command=import_all)
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self.root.quit)
        
        db_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Database", menu=db_menu)
        db_menu.add_command(label="Search Words", command=self.search_words)
        
        # Chat display
        self.chat_display = scrolledtext.ScrolledText(self.root, wrap=tk.WORD, height=20)
        self.chat_display.pack(padx=10, pady=10, fill=tk.BOTH, expand=True)
        
        # Input
        input_frame = tk.Frame(self.root)
        input_frame.pack(padx=10, pady=5, fill=tk.X)
        
        self.input_entry = tk.Entry(input_frame, font=("Arial", 12))
        self.input_entry.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.input_entry.bind("<Return>", self.send_message)
        
        send_btn = tk.Button(input_frame, text="Send", command=self.send_message)
        send_btn.pack(side=tk.RIGHT, padx=5)
        
        # Buttons
        btn_frame = tk.Frame(self.root)
        btn_frame.pack(pady=5)
        
        tk.Button(btn_frame, text="Clear Chat", command=self.clear_chat).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Show History", command=self.show_history).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Train", command=self.train).pack(side=tk.LEFT, padx=5)
        
        self.load_initial_messages()
    
    def load_initial_messages(self):
        self.chat_display.insert(tk.END, "Ashley: Hello! I'm Ashley, your AI assistant. How can I help?\n\n")
    
    def send_message(self, event=None):
        user_msg = self.input_entry.get().strip()
        if not user_msg:
            return
        
        self.chat_display.insert(tk.END, f"You: {user_msg}\n")
        self.input_entry.delete(0, tk.END)
        
        response = self.chatbot.respond(user_msg)
        self.chat_display.insert(tk.END, f"Ashley: {response}\n\n")
        self.chat_display.see(tk.END)
    
    def import_file_dialog(self):
        file_path = filedialog.askopenfilename(
            initialdir=IMPORTS_DIR,
            filetypes=[("Text files", "*.txt *.md *.py"), ("All files", "*.*")]
        )
        if file_path:
            if import_file(file_path):
                messagebox.showinfo("Success", "File imported and scanned!")
            else:
                messagebox.showerror("Error", "Failed to import file.")
    
    def search_words(self):
        query = tk.simpledialog.askstring("Search", "Enter word to search:")
        if query:
            results = search_words(query)
            if results:
                msg = "\n".join([f"{r['word']}: {r['count']} ({r['category']})" for r in results])
                messagebox.showinfo("Search Results", msg)
            else:
                messagebox.showinfo("Search", "No results found.")
    
    def show_history(self):
        history = get_recent_history(10)
        msg = "\n".join([f"{h['speaker']}: {h['message'][:100]}" for h in history])
        messagebox.showinfo("Recent History", msg or "No history yet.")
    
    def train(self):
        messagebox.showinfo("Training", "Basic training complete (scanning done on imports).")
        log_info("Manual train triggered.")
    
    def clear_chat(self):
        self.chat_display.delete(1.0, tk.END)
        self.load_initial_messages()
    
    def run(self):
        self.root.mainloop()