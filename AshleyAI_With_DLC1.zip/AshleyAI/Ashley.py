from gui.shell import AshleyShell
from config import init_databases  # Wait, actually called in shell
from database.database import init_databases
from tools.logger import log_info

if __name__ == "__main__":
    log_info("Starting Ashley AI Phase 1")
    init_databases()
    shell = AshleyShell()
    shell.run()