from database.database import get_chat_history

def get_recent_history(limit=20):
    return get_chat_history(limit)