import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

DATABASE_GENERIC = os.path.join(BASE_DIR, 'database', 'generic.db')
DATABASE_ASHLEY = os.path.join(BASE_DIR, 'database', 'ashley.db')

IMPORTS_DIR = os.path.join(BASE_DIR, 'imports')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
BACKUPS_DIR = os.path.join(BASE_DIR, 'backups')

# Create dirs if not exist
for d in [IMPORTS_DIR, LOGS_DIR, BACKUPS_DIR]:
    os.makedirs(d, exist_ok=True)