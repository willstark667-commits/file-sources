import logging
import os
from datetime import datetime
from config import LOGS_DIR

logging.basicConfig(
    filename=os.path.join(LOGS_DIR, f'ashley_{datetime.now().strftime("%Y%m%d")}.log'),
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

def log_info(msg):
    logging.info(msg)

def log_error(msg):
    logging.error(msg)