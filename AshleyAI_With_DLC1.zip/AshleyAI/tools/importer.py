import os
import glob
from engine.scanner import scan_text
from tools.logger import log_info
from config import IMPORTS_DIR

def import_file(file_path):
    """Import text from file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        scan_text(content)
        log_info(f"Imported and scanned: {file_path}")
        return True
    except Exception as e:
        log_info(f"Import error: {e}")
        return False

def import_all():
    """Import all files in imports dir."""
    for ext in ['*.txt', '*.md', '*.py']:
        for file in glob.glob(os.path.join(IMPORTS_DIR, ext)):
            import_file(file)