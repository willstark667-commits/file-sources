# Genesis OS — Phase 1 Prototype

A self-contained Python "virtual desktop OS": a simulated CPU/RAM/disk, a
BIOS boot sequence, a diagnostics/self-repair engine, a small growable
neural network, and a tkinter desktop shell in your amber/green CRT style.

Nothing here touches your real hardware or filesystem beyond the
`storage/`, `logs/`, and `generated/` folders inside this project.

## Run it

**Easiest — one command, handles everything:**

```bash
python3 launcher.py
```

This checks your Python version, checks for `numpy` (offers to `pip install`
it if missing), checks for `tkinter` (offers to run the right OS package
command if missing, e.g. `sudo apt install python3-tk`), then boots
Genesis OS. It always asks before installing anything — pass `--yes` to
skip the prompts, or `--no-fix` to only report problems without offering
to fix them.

**Double-click wrappers** (do the same thing, no terminal typing needed):
- Windows: `run.bat`
- macOS / Linux: `run.sh`

**Manual / advanced:**

```bash
pip install -r requirements.txt
python3 boot.py
```

`boot.py` on its own still checks for tkinter/numpy first and prints a
clear fix if either is missing — it just won't offer to auto-install for
you the way `launcher.py` does.

**Isolated environment:** `python3 launcher.py --venv` creates/uses a local
`.venv` folder and installs packages there instead of system-wide.

Requires Python 3.9+ with tkinter available (tkinter ships with the
standard python.org installer on Windows/Mac; on Linux you may need
`sudo apt install python3-tk`, which the launcher will offer to run).

## What happens on boot

1. **BIOS POST** — checks the virtual CPU (register arithmetic), virtual
   RAM (write/readback test), and virtual disk (checksum table) before
   anything else runs. Results are appended to `logs/boot.log`.
2. **Neural core load** — loads `storage/checkpoints/neural_core.json` if
   it exists, otherwise seeds a fresh network and saves it.
3. **Diagnostics pass** — scans RAM/disk/neural checkpoint for problems and
   auto-repairs anything fixable (recompute a bad checksum, remount the
   disk, reset RAM, or reinitialize a corrupted neural checkpoint).
4. **Desktop launches** — the exact boot log types itself onto the boot
   screen, then hands off to the desktop with four apps.

## The four apps

- **Terminal** — a real shell over the virtual system. Commands: `ls`,
  `cat <path>`, `write <path> <text>`, `run <asm ; separated>`,
  `neuralstat`, `train [n]`, `grow`, `scan`, `repair`, `clear`, `exit`.
- **Neural Monitor** — live stats (generation, hidden neuron count,
  training steps, last loss) plus a loss-history graph and buttons to
  train on a freshly self-generated bit sequence, grow a neuron, or save
  a checkpoint.
- **Diagnostics** — run a scan, see issues by subsystem/severity, and
  trigger repair.
- **File Manager** — browse and view files on the virtual disk (backed by
  `storage/disk_image.json` on your real disk).

## Architecture

```
launcher.py                 one-command setup: checks/installs deps, then runs boot.py
run.sh / run.bat             double-click wrappers around launcher.py
boot.py                     entry point: BIOS -> kernel -> neural -> desktop
genesis_os/
    config.py                paths (anchored to this file, not cwd) + theme
    bios.py                  POST sequence (CPU/RAM/disk checks)
    kernel/
        cpu.py                virtual CPU: registers, PC, tiny instruction set
        memory.py             virtual RAM (bounds-checked byte array)
        filesystem.py         virtual disk (JSON image + sha256 checksums)
        diagnostics.py        scan / analyze / detect / repair pipeline
        scheduler.py          priority task scheduler (for future bg work)
    ai/
        neural_core.py        growable numpy feedforward net + checkpoints
    desktop/
        desktop.py            tkinter boot screen + 4 app windows
```

## The virtual CPU's instruction set

```
MOV  Rd, value      ADD  Rd, Rs        SUB  Rd, Rs
MUL  Rd, Rs         LOAD Rd, addr      STORE addr, Rs
CMP  Rd, Rs         JMP  label         JZ   label
PRINT Rd            HALT
```

Try it in the Terminal:
```
run MOV R0, 5 ; MOV R1, 3 ; ADD R0, R1 ; PRINT R0 ; HALT
```

## The neural core (Phase 1 scope)

Per the build plan's "Binary Learning" stage, the network's task is: given
the previous 8 bits of a sequence, predict the next bit. It:

- **Generates its own training data** locally (`train` command / button) —
  no outside datasets, ever.
- **Grows in place** (`grow`) — adds a hidden neuron while preserving
  existing learned weights, rather than resetting.
- **Checkpoints to disk** (`storage/checkpoints/neural_core.json`) so
  learning persists across reboots.
- **Self-validates** — `is_valid()` checks weight shapes and finiteness;
  the diagnostics engine calls `reset_to_seed()` as a repair action if a
  checkpoint is corrupted.

This is intentionally a small, honest starting point — a real toy task the
network actually learns, not a simulated one. Later phases (per the build
plan's roadmap) would extend this toward instruction-sequence prediction,
then generation.

## What's NOT implemented yet (by design, so this stays honest)

- The neural network does not write or generate the CPU/OS code itself —
  it currently only predicts bits. Code generation, self-mutation, and the
  world model described in the concept doc are future phases.
- No sandboxed self-patch/rollback loop yet (`repair` in diagnostics fixes
  known-shape issues like a bad checksum, not arbitrary code).
- No custom assembler-to-machine-code compiler beyond the direct
  interpreter in `cpu.py`.

These are natural next phases (Phase 3+ in the build plan) — happy to keep
building on any of them next.
