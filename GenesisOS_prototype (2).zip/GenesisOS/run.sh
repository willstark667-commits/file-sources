#!/usr/bin/env bash
# Genesis OS launcher for Linux/macOS.
# Finds a python3 interpreter, then runs launcher.py (dependency checks +
# auto-install + boot).
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if command -v python3 >/dev/null 2>&1; then
    PY=python3
elif command -v python >/dev/null 2>&1; then
    PY=python
else
    echo "No Python interpreter found. Install Python 3.9+ from https://www.python.org/downloads/"
    exit 1
fi

"$PY" launcher.py "$@"
