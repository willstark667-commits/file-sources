"""
launcher.py
------------
One-command setup + launch for Genesis OS.

    python3 launcher.py

What it does, in order:
  1. Checks the Python version.
  2. Checks for pip packages listed in requirements.txt; auto-installs any
     that are missing (asks first, unless --yes is passed).
  3. Checks for tkinter. tkinter is a system package, not a pip package,
     so it can't be pip-installed -- if it's missing, this offers to run
     the correct OS package-manager command for you (again, asks first),
     or prints the manual fix if it can't or you decline.
  4. Launches boot.py in this same interpreter.

Flags:
  --yes       don't prompt before installing anything (non-interactive)
  --no-fix    never attempt to install anything; only report problems
  --venv      create/use a local .venv before installing packages
"""

import subprocess
import sys
import venv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REQUIREMENTS = ROOT / "requirements.txt"
VENV_DIR = ROOT / ".venv"


def _venv_python():
    if sys.platform.startswith("win"):
        return VENV_DIR / "Scripts" / "python.exe"
    return VENV_DIR / "bin" / "python"


def _confirm(prompt, auto_yes):
    if auto_yes:
        return True
    if not sys.stdin.isatty():
        return False  # non-interactive session with no --yes: don't guess
    try:
        return input(f"{prompt} [y/N] ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


def _ensure_venv(auto_yes):
    if VENV_DIR.exists():
        return
    if not _confirm(f"No .venv found. Create one at {VENV_DIR}?", auto_yes):
        print("Continuing without a virtual environment (using system Python).")
        return
    print(f"Creating virtual environment at {VENV_DIR} ...")
    venv.create(VENV_DIR, with_pip=True)
    print("Virtual environment created.")


def _relaunch_in_venv():
    """If a .venv exists and we're not already running inside it, re-exec
    this script with the venv's interpreter."""
    vpy = _venv_python()
    if not vpy.exists():
        return
    if Path(sys.executable).resolve() == vpy.resolve():
        return  # already inside the venv
    print(f"Relaunching with virtual environment interpreter: {vpy}")
    result = subprocess.run([str(vpy), str(Path(__file__).resolve())] + sys.argv[1:])
    sys.exit(result.returncode)


def _check_python_version():
    if sys.version_info < (3, 9):
        print(f"Genesis OS requires Python 3.9+. You have {sys.version.split()[0]}.")
        print("Install a newer Python from https://www.python.org/downloads/ and re-run.")
        sys.exit(1)


def _missing_pip_packages():
    missing = []
    if not REQUIREMENTS.exists():
        return missing
    for line in REQUIREMENTS.read_text(encoding="utf-8").splitlines():
        pkg = line.strip()
        if not pkg or pkg.startswith("#"):
            continue
        # strip a version specifier like "numpy>=1.24" down to the import name
        name = pkg.split(">=")[0].split("==")[0].split("<")[0].strip()
        try:
            __import__(name)
        except ImportError:
            missing.append(pkg)
    return missing


def _install_pip_packages(packages, auto_yes):
    if not packages:
        return True
    print(f"Missing Python packages: {', '.join(packages)}")
    if not _confirm("Install them now with pip?", auto_yes):
        print(f"Skipped. Install manually with: pip install {' '.join(packages)}")
        return False
    cmd = [sys.executable, "-m", "pip", "install"] + packages
    print(f"Running: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    return result.returncode == 0


def _check_tkinter():
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        return False


def _tkinter_fix_command():
    if sys.platform.startswith("linux"):
        for mgr, cmd in [
            ("apt", ["sudo", "apt", "install", "-y", "python3-tk"]),
            ("dnf", ["sudo", "dnf", "install", "-y", "python3-tkinter"]),
            ("pacman", ["sudo", "pacman", "-S", "--noconfirm", "tk"]),
            ("zypper", ["sudo", "zypper", "install", "-y", "python3-tk"]),
        ]:
            if subprocess.run(["which", mgr], capture_output=True).returncode == 0:
                return cmd
        return None
    if sys.platform == "darwin":
        if subprocess.run(["which", "brew"], capture_output=True).returncode == 0:
            return ["brew", "install", "python-tk"]
        return None
    return None  # Windows: tkinter ships with python.org installer; no auto-fix


def _ensure_tkinter(auto_yes, no_fix):
    if _check_tkinter():
        return True
    print("tkinter is not available in this Python installation.")
    if no_fix:
        print("--no-fix set: skipping auto-install.")
    else:
        fix_cmd = _tkinter_fix_command()
        if fix_cmd and _confirm(f"Attempt to install it with: {' '.join(fix_cmd)} ?", auto_yes):
            result = subprocess.run(fix_cmd)
            if result.returncode == 0 and _check_tkinter():
                print("tkinter installed successfully.")
                return True
            print("Automatic install did not succeed.")

    if sys.platform.startswith("linux"):
        print("Manual fix: sudo apt install python3-tk   (or dnf/pacman/zypper equivalent)")
    elif sys.platform == "darwin":
        print("Manual fix: brew install python-tk   (or reinstall Python from python.org)")
    else:
        print("Manual fix: reinstall Python from https://www.python.org/downloads/ "
              "and make sure 'tcl/tk and IDLE' is checked during install.")
    return False


def main():
    args = sys.argv[1:]
    auto_yes = "--yes" in args
    no_fix = "--no-fix" in args
    use_venv = "--venv" in args

    print("Genesis OS launcher")
    print("=" * 40)

    _check_python_version()

    if use_venv:
        _ensure_venv(auto_yes)
        _relaunch_in_venv()

    missing = _missing_pip_packages()
    if missing:
        ok = _install_pip_packages(missing, auto_yes)
        if not ok:
            print("Cannot continue without required packages.")
            sys.exit(1)

    if not _ensure_tkinter(auto_yes, no_fix):
        print("Cannot continue without tkinter.")
        sys.exit(1)

    print("All requirements satisfied. Booting Genesis OS...")
    print("=" * 40)

    boot_script = ROOT / "boot.py"
    result = subprocess.run([sys.executable, str(boot_script)])
    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
