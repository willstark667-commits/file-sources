"""
boot.py
--------
Genesis OS entry point.

    python3 boot.py

Sequence: load BIOS -> run POST on virtual CPU/RAM/disk -> mount filesystem
-> load or seed the neural core -> run one diagnostics pass (repairing
anything fixable) -> hand off to the tkinter desktop shell.

All boot text is collected into `boot_lines` and replayed as a typewriter
animation in the desktop shell, so what you see on screen is exactly what
really happened during boot, not a canned script.
"""

import sys
import traceback
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))


def _preflight():
    """Check dependencies BEFORE importing anything that needs them, so a
    missing package produces one clear message instead of a raw traceback
    from deep inside the import chain."""
    problems = []

    if sys.version_info < (3, 9):
        problems.append(
            f"Python 3.9+ is required (you have {sys.version.split()[0]}). "
            "Install a newer Python and re-run with that interpreter."
        )

    try:
        import tkinter  # noqa: F401
    except ImportError:
        if sys.platform.startswith("linux"):
            fix = "sudo apt install python3-tk   (Debian/Ubuntu)\n  sudo dnf install python3-tkinter   (Fedora)"
        elif sys.platform == "darwin":
            fix = "brew install python-tk"
        else:
            fix = "Reinstall Python from python.org with the 'tcl/tk' option checked."
        problems.append(f"tkinter is not installed/available.\n  Fix: {fix}")

    try:
        import numpy  # noqa: F401
    except ImportError:
        problems.append("numpy is not installed.\n  Fix: pip install -r requirements.txt   (or: pip install numpy)")

    if problems:
        print("=" * 60)
        print("Genesis OS cannot start -- missing requirements:")
        print("=" * 60)
        for i, p in enumerate(problems, 1):
            print(f"{i}. {p}")
        print("=" * 60)
        sys.exit(1)


_preflight()

from genesis_os import config, bios
from genesis_os.kernel.memory import VirtualRAM
from genesis_os.kernel.filesystem import VirtualFileSystem
from genesis_os.kernel.cpu import VirtualCPU
from genesis_os.kernel.diagnostics import DiagnosticsEngine
from genesis_os.kernel.scheduler import Scheduler
from genesis_os.ai.neural_core import GrowingNeuralNetwork
from genesis_os.desktop import desktop


def main():
    config.ensure_dirs()
    boot_lines = []
    log = boot_lines.append

    log("GENESIS OS")
    log("=" * 40)

    # 1. Hardware
    ram = VirtualRAM()
    disk = VirtualFileSystem()
    cpu = VirtualCPU(ram)

    # 2. BIOS / POST
    post = bios.BIOS(ram, disk, cpu, log_fn=log)
    report = post.run()

    # 3. Neural core: load existing checkpoint, or seed a new one
    log("")
    log("Loading neural core...")
    try:
        if config.NEURAL_WEIGHTS_PATH.exists():
            net = GrowingNeuralNetwork.load()
            log(f"  checkpoint found: generation={net.generation} "
                f"hidden={net.hidden_size} steps={net.training_steps}")
        else:
            net = GrowingNeuralNetwork()
            net.save()
            log("  no checkpoint found -- seeded a fresh network and saved it.")
    except Exception as exc:  # noqa: BLE001
        log(f"  checkpoint load failed ({exc}); seeding fresh network.")
        net = GrowingNeuralNetwork()
        net.save()

    # 4. Diagnostics pass (scan + auto-repair anything fixable)
    log("")
    log("Running boot diagnostics...")
    diagnostics = DiagnosticsEngine(ram, disk, neural_core=net, log_fn=log)
    diag_report = diagnostics.scan()
    if diag_report.healthy:
        log("  no issues found.")
    else:
        for issue in diag_report.issues:
            log(f"  issue: [{issue['severity']}] {issue['subsystem']}: {issue['problem']}")
        diagnostics.attempt_repair(diag_report)
        for rep in diag_report.repairs:
            log(f"  repair: {rep['subsystem']} -> {rep['action']} ({rep['result']})")

    # 5. Scheduler (available to the desktop for future background tasks)
    scheduler = Scheduler()

    log("")
    log(f"POST: {'PASSED' if report['post_passed'] else 'FAILED (see diagnostics)'}")
    log("Starting desktop environment...")

    system = {
        "ram": ram,
        "disk": disk,
        "cpu": cpu,
        "neural": net,
        "diagnostics": diagnostics,
        "scheduler": scheduler,
        "bios_report": report,
    }

    desktop.launch(system, boot_lines)


if __name__ == "__main__":
    try:
        main()
    except Exception:  # noqa: BLE001
        print("=" * 60)
        print("Genesis OS crashed during boot. Full traceback:")
        print("=" * 60)
        traceback.print_exc()
        try:
            config.ensure_dirs()
            crash_log = config.LOGS_DIR / "crash.log"
            with open(crash_log, "a", encoding="utf-8") as f:
                f.write(traceback.format_exc() + "\n")
            print(f"\n(also written to {crash_log})")
        except Exception:  # noqa: BLE001
            pass
        if sys.platform.startswith("win"):
            input("\nPress Enter to close...")
        sys.exit(1)
