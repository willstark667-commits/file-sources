"""Genesis OS - a self-contained Python virtual desktop/OS simulator."""

__version__ = "0.1.0-phase1"
