"""
genesis_os.kernel.memory
--------------------------
A flat virtual RAM: a fixed-size array of integer cells (0-255, byte-sized).
Simple, bounds-checked, and easy for the neural core to eventually predict
the state of.
"""

from .. import config


class MemoryError_(Exception):
    """Raised on out-of-bounds or invalid memory access."""


class VirtualRAM:
    def __init__(self, size=None):
        self.size = size or config.RAM_SIZE
        self.cells = [0] * self.size

    def _check_bounds(self, addr):
        if not (0 <= addr < self.size):
            raise MemoryError_(f"address {addr} out of bounds (0..{self.size - 1})")

    def read(self, addr):
        self._check_bounds(addr)
        return self.cells[addr]

    def write(self, addr, value):
        self._check_bounds(addr)
        self.cells[addr] = value & 0xFF  # clamp to a byte

    def dump(self, start=0, length=32):
        end = min(start + length, self.size)
        return self.cells[start:end]

    def reset(self):
        self.cells = [0] * self.size

    def used_cells(self):
        return sum(1 for c in self.cells if c != 0)
