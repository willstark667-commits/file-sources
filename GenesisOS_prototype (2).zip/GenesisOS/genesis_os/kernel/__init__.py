"""Genesis OS kernel subsystems: CPU, RAM, filesystem, diagnostics, scheduler."""
