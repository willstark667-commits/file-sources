"""
genesis_os.kernel.cpu
------------------------
A tiny virtual CPU. Registers R0..R7, a program counter, a zero flag, and a
minimal instruction set. This is the "Stage 2 - Instruction Discovery"
layer from the build plan: something simple enough that a learning system
could eventually generate valid programs for it.

Supported instructions (assembly text, one per line, comments with `;`):

    MOV  Rd, value        R d = value
    ADD  Rd, Rs            R d = Rd + Rs
    SUB  Rd, Rs            R d = Rd - Rs
    MUL  Rd, Rs            R d = Rd * Rs
    LOAD Rd, addr          R d = RAM[addr]
    STORE addr, Rs         RAM[addr] = Rs
    CMP  Rd, Rs            sets zero flag if Rd == Rs
    JMP  label
    JZ   label              jump if zero flag set
    PRINT Rd
    HALT
"""

from .. import config


class CPUError(Exception):
    pass


class VirtualCPU:
    def __init__(self, ram, output_fn=None):
        self.ram = ram
        self.output_fn = output_fn or (lambda text: None)
        self.registers = {f"R{i}": 0 for i in range(config.REGISTER_COUNT)}
        self.pc = 0
        self.zero_flag = False
        self.halted = False
        self.program = []
        self.labels = {}
        self.steps_executed = 0

    def reset(self):
        self.registers = {f"R{i}": 0 for i in range(config.REGISTER_COUNT)}
        self.pc = 0
        self.zero_flag = False
        self.halted = False
        self.steps_executed = 0

    # -- assembly --------------------------------------------------------
    def assemble(self, source: str):
        """Parse assembly text into (op, args) tuples and resolve labels."""
        program = []
        labels = {}
        for raw_line in source.splitlines():
            line = raw_line.split(";", 1)[0].strip()
            if not line:
                continue
            if line.endswith(":"):
                labels[line[:-1]] = len(program)
                continue
            parts = line.replace(",", " ").split()
            op, args = parts[0].upper(), parts[1:]
            program.append((op, args))
        self.program = program
        self.labels = labels
        return program

    def load(self, source: str):
        self.reset()
        self.assemble(source)

    # -- value resolution --------------------------------------------------
    def _val(self, token):
        if token in self.registers:
            return self.registers[token]
        return int(token)

    # -- execution ---------------------------------------------------------
    def step(self):
        if self.halted:
            return False
        if self.pc >= len(self.program):
            self.halted = True
            return False

        op, args = self.program[self.pc]
        next_pc = self.pc + 1

        try:
            if op == "MOV":
                self.registers[args[0]] = self._val(args[1])
            elif op == "ADD":
                self.registers[args[0]] += self._val(args[1])
            elif op == "SUB":
                self.registers[args[0]] -= self._val(args[1])
            elif op == "MUL":
                self.registers[args[0]] *= self._val(args[1])
            elif op == "LOAD":
                self.registers[args[0]] = self.ram.read(self._val(args[1]))
            elif op == "STORE":
                self.ram.write(self._val(args[0]), self._val(args[1]))
            elif op == "CMP":
                self.zero_flag = self._val(args[0]) == self._val(args[1])
            elif op == "JMP":
                next_pc = self.labels[args[0]]
            elif op == "JZ":
                if self.zero_flag:
                    next_pc = self.labels[args[0]]
            elif op == "PRINT":
                self.output_fn(str(self._val(args[0])))
            elif op == "HALT":
                self.halted = True
            else:
                raise CPUError(f"unknown instruction '{op}'")
        except (KeyError, IndexError, ValueError) as exc:
            raise CPUError(f"error executing '{op} {args}' at pc={self.pc}: {exc}") from exc

        self.pc = next_pc
        self.steps_executed += 1
        return not self.halted

    def run(self, max_steps=10000):
        while self.step() and self.steps_executed < max_steps:
            pass
        if self.steps_executed >= max_steps and not self.halted:
            raise CPUError(f"program exceeded max_steps={max_steps} (possible infinite loop)")
        return dict(self.registers)
