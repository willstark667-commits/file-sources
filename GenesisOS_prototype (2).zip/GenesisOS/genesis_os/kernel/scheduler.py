"""
genesis_os.kernel.scheduler
------------------------------
A minimal cooperative task scheduler. Tasks are plain callables registered
with a priority; run_once() executes them in priority order. This is
intentionally simple -- it exists so the desktop shell and any background
"neural evolution loop" have a single place to hook periodic work.
"""

import heapq
import itertools


class Task:
    def __init__(self, name, fn, priority=5):
        self.name = name
        self.fn = fn
        self.priority = priority

    def run(self):
        return self.fn()


class Scheduler:
    def __init__(self):
        self._tasks = []
        self._counter = itertools.count()
        self.log = []

    def register(self, name, fn, priority=5):
        task = Task(name, fn, priority)
        heapq.heappush(self._tasks, (priority, next(self._counter), task))
        return task

    def run_once(self):
        """Run every registered task a single time, in priority order
        (lower number = higher priority). Returns list of (name, result_or_error)."""
        results = []
        ordered = sorted(self._tasks, key=lambda t: (t[0], t[1]))
        for _, _, task in ordered:
            try:
                result = task.run()
                results.append((task.name, "ok", result))
            except Exception as exc:  # noqa: BLE001
                results.append((task.name, "error", str(exc)))
        self.log.extend(results)
        return results

    def clear(self):
        self._tasks = []
