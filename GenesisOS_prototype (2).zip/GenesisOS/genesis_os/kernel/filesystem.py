"""
genesis_os.kernel.filesystem
-------------------------------
A virtual disk stored as a single JSON "disk image" file on the host
filesystem. Provides a small file API plus per-file checksums so the
diagnostics engine can detect corruption.
"""

import hashlib
import json

from .. import config


class FSError(Exception):
    pass


def _checksum(content: str) -> str:
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class VirtualFileSystem:
    def __init__(self, image_path=None):
        self.image_path = image_path or config.DISK_IMAGE_PATH
        self.files = {}       # path -> content (str)
        self.checksums = {}   # path -> sha256
        self.mounted = False

    # -- lifecycle -----------------------------------------------------
    def mount(self):
        config.ensure_dirs()
        if self.image_path.exists():
            try:
                with open(self.image_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.files = data.get("files", {})
                self.checksums = data.get("checksums", {})
            except (json.JSONDecodeError, OSError):
                # Corrupt or unreadable image: start fresh but do not
                # silently delete the bad file -- rename it aside instead.
                bad_path = self.image_path.with_suffix(".corrupt.json")
                try:
                    self.image_path.rename(bad_path)
                except OSError:
                    pass
                self.files, self.checksums = {}, {}
                self.format()
        else:
            self.format()
        self.mounted = True

    def format(self):
        """Create a fresh disk image with a couple of starter files."""
        self.files = {
            "/README.txt": (
                "Genesis OS virtual disk.\n"
                "This file lives inside storage/disk_image.json on the host.\n"
            ),
            "/boot/welcome.txt": "Welcome to Genesis OS.\n",
        }
        self.checksums = {path: _checksum(content) for path, content in self.files.items()}
        self.flush()

    def flush(self):
        config.ensure_dirs()
        payload = {"files": self.files, "checksums": self.checksums}
        tmp_path = self.image_path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        tmp_path.replace(self.image_path)  # atomic-ish swap

    # -- file ops --------------------------------------------------------
    def list_dir(self, prefix="/"):
        return sorted(p for p in self.files if p.startswith(prefix))

    def read_file(self, path):
        if path not in self.files:
            raise FSError(f"no such file: {path}")
        return self.files[path]

    def write_file(self, path, content):
        self.files[path] = content
        self.checksums[path] = _checksum(content)
        self.flush()

    def delete_file(self, path):
        if path in self.files:
            del self.files[path]
            del self.checksums[path]
            self.flush()

    # -- integrity -----------------------------------------------------
    def verify_integrity(self):
        for path, content in self.files.items():
            expected = self.checksums.get(path)
            if expected != _checksum(content):
                return False
        return True

    def corrupted_files(self):
        bad = []
        for path, content in self.files.items():
            expected = self.checksums.get(path)
            if expected != _checksum(content):
                bad.append(path)
        return bad

    def repair_file(self, path, fallback_content=""):
        """Recompute the checksum from current content (self-heals a
        mismatched checksum) or, if the file is missing entirely, recreate
        it with fallback content."""
        if path not in self.files:
            self.files[path] = fallback_content
        self.checksums[path] = _checksum(self.files[path])
        self.flush()
