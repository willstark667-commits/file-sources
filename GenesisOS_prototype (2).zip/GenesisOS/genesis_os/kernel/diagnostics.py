"""
genesis_os.kernel.diagnostics
--------------------------------
Scan / analyze / detect / repair pipeline described in the build plan.

DiagnosticsEngine checks each subsystem (RAM, disk/filesystem, neural
checkpoint) and can attempt bounded, logged repairs. Every repair attempt
is recorded so nothing silently mutates state.
"""

import json
from datetime import datetime, timezone

from .. import config


class DiagnosticReport:
    def __init__(self):
        self.timestamp = datetime.now(timezone.utc).isoformat() + "Z"
        self.issues = []       # list of dicts: {subsystem, problem, severity}
        self.repairs = []      # list of dicts: {subsystem, action, result}

    def add_issue(self, subsystem, problem, severity="warning"):
        self.issues.append({"subsystem": subsystem, "problem": problem, "severity": severity})

    def add_repair(self, subsystem, action, result):
        self.repairs.append({"subsystem": subsystem, "action": action, "result": result})

    @property
    def healthy(self):
        return len(self.issues) == 0

    def to_dict(self):
        return {
            "timestamp": self.timestamp,
            "healthy": self.healthy,
            "issues": self.issues,
            "repairs": self.repairs,
        }


class DiagnosticsEngine:
    def __init__(self, ram, disk, neural_core=None, log_fn=None):
        self.ram = ram
        self.disk = disk
        self.neural_core = neural_core
        self.log_fn = log_fn or (lambda msg: None)

    def scan(self) -> DiagnosticReport:
        report = DiagnosticReport()
        self.log_fn("[DIAG] scanning RAM...")
        self._scan_ram(report)
        self.log_fn("[DIAG] scanning filesystem...")
        self._scan_disk(report)
        if self.neural_core is not None:
            self.log_fn("[DIAG] scanning neural checkpoint...")
            self._scan_neural(report)
        self._write_log(report)
        return report

    def _scan_ram(self, report):
        if len(self.ram.cells) != self.ram.size:
            report.add_issue("ram", "cell array size mismatch", "critical")

    def _scan_disk(self, report):
        if not self.disk.mounted:
            report.add_issue("disk", "filesystem not mounted", "critical")
            return
        bad_files = self.disk.corrupted_files()
        for path in bad_files:
            report.add_issue("disk", f"checksum mismatch: {path}", "warning")

    def _scan_neural(self, report):
        if not self.neural_core.is_valid():
            report.add_issue("neural_core", "checkpoint failed validation", "warning")

    def attempt_repair(self, report: DiagnosticReport) -> DiagnosticReport:
        """Attempt to fix each issue found. Mutates and returns the report
        with repair entries appended."""
        for issue in list(report.issues):
            subsystem = issue["subsystem"]
            if subsystem == "disk" and issue["problem"].startswith("checksum mismatch"):
                path = issue["problem"].split(": ", 1)[1]
                try:
                    self.disk.repair_file(path)
                    report.add_repair("disk", f"recomputed checksum for {path}", "success")
                except Exception as exc:  # noqa: BLE001
                    report.add_repair("disk", f"repair failed for {path}", f"error: {exc}")
            elif subsystem == "disk" and issue["problem"] == "filesystem not mounted":
                try:
                    self.disk.mount()
                    report.add_repair("disk", "remounted filesystem", "success")
                except Exception as exc:  # noqa: BLE001
                    report.add_repair("disk", "remount failed", f"error: {exc}")
            elif subsystem == "ram":
                try:
                    self.ram.reset()
                    report.add_repair("ram", "reset RAM to clean state", "success")
                except Exception as exc:  # noqa: BLE001
                    report.add_repair("ram", "reset failed", f"error: {exc}")
            elif subsystem == "neural_core" and self.neural_core is not None:
                try:
                    self.neural_core.reset_to_seed()
                    report.add_repair("neural_core", "reinitialized from seed", "success")
                except Exception as exc:  # noqa: BLE001
                    report.add_repair("neural_core", "reinit failed", f"error: {exc}")
        self._write_log(report)
        return report

    def _write_log(self, report):
        config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
        with open(config.DIAGNOSTICS_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(report.to_dict()) + "\n")
