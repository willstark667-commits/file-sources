"""
genesis_os.bios
----------------
Simulated BIOS / POST (Power-On Self-Test).

Runs a sequence of hardware checks against the virtual devices before the
kernel takes over. Produces a structured report that boot.py and the
diagnostics engine can act on.
"""

import json
import time
from datetime import datetime, timezone

from . import config


class POSTResult:
    def __init__(self, name, ok, detail=""):
        self.name = name
        self.ok = ok
        self.detail = detail

    def to_dict(self):
        return {"name": self.name, "ok": self.ok, "detail": self.detail}


class BIOS:
    """Very small, dependency-free POST sequence."""

    VERSION = "Genesis BIOS v0.1"

    def __init__(self, ram, disk, cpu, log_fn=None):
        self.ram = ram
        self.disk = disk
        self.cpu = cpu
        self.log_fn = log_fn or (lambda msg: None)
        self.results = []

    def _check(self, name, fn):
        try:
            ok, detail = fn()
        except Exception as exc:  # noqa: BLE001 - POST must never crash the boot
            ok, detail = False, f"exception: {exc}"
        result = POSTResult(name, ok, detail)
        self.results.append(result)
        status = "OK" if ok else "FAIL"
        self.log_fn(f"[POST] {name:<24} ... {status}  {detail}")
        return ok

    def _check_cpu(self):
        self.cpu.reset()
        self.cpu.registers["R0"] = 2
        self.cpu.registers["R1"] = 2
        total = self.cpu.registers["R0"] + self.cpu.registers["R1"]
        return (total == 4), f"register arithmetic sane ({total}==4)"

    def _check_ram(self):
        test_addr = 0
        self.ram.write(test_addr, 0xA5)
        readback = self.ram.read(test_addr)
        self.ram.write(test_addr, 0)  # clear test pattern
        return (readback == 0xA5), f"write/readback test pattern 0xA5 -> {hex(readback)}"

    def _check_disk(self):
        self.disk.mount()
        healthy = self.disk.verify_integrity()
        return healthy, "filesystem checksum table verified" if healthy else "checksum mismatch detected"

    def run(self):
        config.ensure_dirs()
        self.log_fn(f"{self.VERSION}")
        self.log_fn(f"Boot time: {datetime.now(timezone.utc).isoformat()}Z")
        self.log_fn("Running Power-On Self-Test...")
        time.sleep(0.05)

        cpu_ok = self._check("CPU Registers", self._check_cpu)
        ram_ok = self._check("RAM", self._check_ram)
        disk_ok = self._check("Disk / Filesystem", self._check_disk)

        all_ok = cpu_ok and ram_ok and disk_ok
        report = {
            "bios_version": self.VERSION,
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
            "checks": [r.to_dict() for r in self.results],
            "post_passed": all_ok,
        }

        config.BOOT_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(config.BOOT_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(report) + "\n")

        if all_ok:
            self.log_fn("POST complete. All systems nominal.")
        else:
            self.log_fn("POST complete. One or more checks FAILED. Handing off to diagnostics/repair.")

        return report
