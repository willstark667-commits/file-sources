"""Genesis OS desktop shell (tkinter): boot screen, terminal, neural
monitor, diagnostics window, file manager."""
