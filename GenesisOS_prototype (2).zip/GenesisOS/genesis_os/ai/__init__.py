"""Genesis OS AI core: a small, growable neural network used for the
'Neural Monitor' and future binary/pattern-learning experiments."""
