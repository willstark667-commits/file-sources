"""
genesis_os.ai.neural_core
----------------------------
A small, genuinely-trainable feedforward network with two properties the
build plan asks for:

1. It can GROW: add_hidden_neuron() / add_hidden_layer() expand the network
   in place, preserving existing learned weights instead of discarding them.
2. It can be CHECKPOINTED: save()/load() persist weights as JSON so state
   survives a reboot, and reset_to_seed() gives diagnostics a known-good
   fallback to repair to.

Task (Phase 1 scope, matches "Binary Learning" in the build plan): predict
the next bit in a binary sequence given the previous N bits. This is a toy
task on purpose -- it's the smallest possible thing that lets the network
actually learn something from numbers it generates and stores itself,
without pulling in any outside data or pretrained weights.
"""

import json
import random

import numpy as np

from .. import config

SEQUENCE_WINDOW = 8   # how many previous bits are fed in as input


def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-np.clip(x, -60, 60)))


class GrowingNeuralNetwork:
    def __init__(self, input_size=SEQUENCE_WINDOW, hidden_size=6, seed=42):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = 1
        self.seed = seed
        self.generation = 0          # increments each time the net grows
        self.training_steps = 0
        self.history = []            # recent (loss) values, for the monitor
        self._init_weights()

    # -- init / growth ---------------------------------------------------
    def _init_weights(self):
        rng = np.random.default_rng(self.seed)
        self.W1 = rng.normal(0, 0.5, size=(self.input_size, self.hidden_size))
        self.b1 = np.zeros(self.hidden_size)
        self.W2 = rng.normal(0, 0.5, size=(self.hidden_size, self.output_size))
        self.b2 = np.zeros(self.output_size)

    def add_hidden_neuron(self):
        """Grow the hidden layer by one neuron, keeping existing weights
        intact (new connections start small/random rather than zero, so
        the new neuron can actually learn something distinct)."""
        rng = np.random.default_rng(self.seed + self.generation + 1)
        new_col = rng.normal(0, 0.5, size=(self.input_size, 1))
        self.W1 = np.hstack([self.W1, new_col])
        self.b1 = np.append(self.b1, 0.0)
        new_row = rng.normal(0, 0.5, size=(1, self.output_size))
        self.W2 = np.vstack([self.W2, new_row])
        self.hidden_size += 1
        self.generation += 1

    # -- forward / training ------------------------------------------------
    def forward(self, x):
        x = np.asarray(x, dtype=float)
        h = _sigmoid(x @ self.W1 + self.b1)
        y = _sigmoid(h @ self.W2 + self.b2)
        return h, y

    def train_step(self, x, target, lr=0.4):
        x = np.asarray(x, dtype=float)
        h, y = self.forward(x)
        error = target - y[0]
        loss = float(error ** 2)

        d_y = error * y[0] * (1 - y[0])
        d_W2 = np.outer(h, d_y)
        d_b2 = d_y

        d_h = (self.W2[:, 0] * d_y) * h * (1 - h)
        d_W1 = np.outer(x, d_h)
        d_b1 = d_h

        self.W2 += lr * d_W2
        self.b2 += lr * d_b2
        self.W1 += lr * d_W1
        self.b1 += lr * d_b1

        self.training_steps += 1
        self.history.append(loss)
        self.history = self.history[-200:]
        return loss

    # -- self-generated training data ---------------------------------------
    def generate_training_bit_sequence(self, length=64, rng_seed=None):
        """Generate a pseudo-random binary sequence entirely locally (no
        outside data) and save it to generated/code/ so it can be reused
        as a checkpointable 'experience'."""
        rng = random.Random(rng_seed)
        bits = [rng.randint(0, 1) for _ in range(length)]
        config.GENERATED_CODE_DIR.mkdir(parents=True, exist_ok=True)
        path = config.GENERATED_CODE_DIR / f"bitseq_gen{self.generation}_{self.training_steps}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"bits": bits}, f)
        return bits, path

    def train_on_sequence(self, bits, lr=0.4):
        losses = []
        for i in range(len(bits) - self.input_size):
            window = bits[i:i + self.input_size]
            target = bits[i + self.input_size]
            losses.append(self.train_step(window, target, lr=lr))
        return losses

    def predict_next_bit(self, recent_bits):
        window = recent_bits[-self.input_size:]
        if len(window) < self.input_size:
            window = [0] * (self.input_size - len(window)) + list(window)
        _, y = self.forward(window)
        return int(y[0] >= 0.5), float(y[0])

    # -- persistence -------------------------------------------------------
    def to_dict(self):
        return {
            "input_size": self.input_size,
            "hidden_size": self.hidden_size,
            "output_size": self.output_size,
            "seed": self.seed,
            "generation": self.generation,
            "training_steps": self.training_steps,
            "W1": self.W1.tolist(),
            "b1": self.b1.tolist(),
            "W2": self.W2.tolist(),
            "b2": self.b2.tolist(),
        }

    def save(self, path=None):
        path = path or config.NEURAL_WEIGHTS_PATH
        config.CHECKPOINTS_DIR.mkdir(parents=True, exist_ok=True)
        tmp_path = path.with_suffix(".tmp")
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f)
        tmp_path.replace(path)

    @classmethod
    def load(cls, path=None):
        path = path or config.NEURAL_WEIGHTS_PATH
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        net = cls(input_size=data["input_size"], hidden_size=data["hidden_size"], seed=data["seed"])
        net.generation = data["generation"]
        net.training_steps = data["training_steps"]
        net.W1 = np.array(data["W1"])
        net.b1 = np.array(data["b1"])
        net.W2 = np.array(data["W2"])
        net.b2 = np.array(data["b2"])
        return net

    def is_valid(self):
        """Sanity check used by the diagnostics engine: shapes must be
        consistent and weights must be finite (no NaN/inf from a corrupted
        checkpoint or a bad training step)."""
        try:
            shapes_ok = (
                self.W1.shape == (self.input_size, self.hidden_size)
                and self.W2.shape == (self.hidden_size, self.output_size)
                and self.b1.shape == (self.hidden_size,)
                and self.b2.shape == (self.output_size,)
            )
            finite_ok = all(
                np.all(np.isfinite(arr)) for arr in (self.W1, self.b1, self.W2, self.b2)
            )
            return shapes_ok and finite_ok
        except Exception:  # noqa: BLE001
            return False

    def reset_to_seed(self):
        """Known-good fallback used by the repair engine."""
        self.hidden_size = 6
        self.generation = 0
        self.training_steps = 0
        self.history = []
        self._init_weights()
        self.save()
