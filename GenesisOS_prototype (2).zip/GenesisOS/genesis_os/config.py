"""
genesis_os.config
------------------
Single source of truth for paths and theme constants.

IMPORTANT: ROOT is anchored to this file's location on disk, not to the
current working directory. This avoids the classic bug where a bare
relative Path("genesis_os") only works if you happen to launch the
process from the right folder.
"""

from pathlib import Path

# genesis_os/config.py -> parent is genesis_os/ -> parent of that is the project root
PACKAGE_DIR = Path(__file__).resolve().parent
ROOT = PACKAGE_DIR.parent

STORAGE_DIR = ROOT / "storage"
LOGS_DIR = ROOT / "logs"
CHECKPOINTS_DIR = STORAGE_DIR / "checkpoints"
GENERATED_DIR = ROOT / "generated"
GENERATED_CODE_DIR = GENERATED_DIR / "code"
GENERATED_REPAIRS_DIR = GENERATED_DIR / "repairs"

DISK_IMAGE_PATH = STORAGE_DIR / "disk_image.json"
KNOWLEDGE_DB_PATH = STORAGE_DIR / "knowledge.json"
NEURAL_WEIGHTS_PATH = CHECKPOINTS_DIR / "neural_core.json"
BOOT_LOG_PATH = LOGS_DIR / "boot.log"
DIAGNOSTICS_LOG_PATH = LOGS_DIR / "diagnostics.log"

REQUIRED_DIRS = [
    STORAGE_DIR,
    LOGS_DIR,
    CHECKPOINTS_DIR,
    GENERATED_DIR,
    GENERATED_CODE_DIR,
    GENERATED_REPAIRS_DIR,
]


def ensure_dirs():
    """Create required directories if missing. Idempotent, no side effects
    beyond mkdir -- does NOT create __init__.py stubs or touch anything
    under genesis_os/ itself, so it can never shadow the real package."""
    for d in REQUIRED_DIRS:
        d.mkdir(parents=True, exist_ok=True)


# --- CRT / terminal theme -------------------------------------------------
class Theme:
    BG = "#0a0d0a"
    PANEL_BG = "#0f140f"
    AMBER = "#ffb000"
    GREEN = "#5ffbc0"
    DIM_GREEN = "#2e6f56"
    RED = "#ff5f5f"
    FONT = ("Consolas", 11)
    FONT_MONO = ("Consolas", 11)
    FONT_TITLE = ("Consolas", 14, "bold")
    CURSOR = GREEN


# --- Virtual hardware sizing -----------------------------------------------
RAM_SIZE = 4096          # number of addressable memory cells
REGISTER_COUNT = 8       # R0..R7
BOOT_TYPE_DELAY_MS = 8   # per-character delay for the boot text animation
