@echo off
REM Genesis OS launcher for Windows.
REM Finds a python interpreter, then runs launcher.py (dependency checks +
REM auto-install + boot). Window stays open if something fails.

cd /d "%~dp0"

where python >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    python launcher.py %*
    goto :end
)

where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    py -3 launcher.py %*
    goto :end
)

echo No Python interpreter found. Install Python 3.9+ from https://www.python.org/downloads/
echo IMPORTANT: check "Add python.exe to PATH" and "tcl/tk and IDLE" during install.
pause
exit /b 1

:end
if %ERRORLEVEL% NEQ 0 pause
