import sqlite3
import os

class DatabaseManager:
    def __init__(self, db_dir):
        self.db_dir = db_dir
        os.makedirs(self.db_dir, exist_ok=True)
        self.history_db = os.path.join(self.db_dir, "history.db")
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.history_db)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chat_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                speaker TEXT,
                message TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        conn.commit()
        conn.close()

    def log_history(self, speaker, message):
        conn = sqlite3.connect(self.history_db)
        cursor = conn.cursor()
        cursor.execute('INSERT INTO chat_history (speaker, message) VALUES (?, ?)', (speaker, message))
        conn.commit()
        conn.close()