import os
import sys

# Ensure imports work correctly
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from database.db_manager import DatabaseManager
from engine.core import AshleyEngine
from gui.modern_shell import ModernShell

def main():
    print("Initializing Ashley AI Modern Studio...")
    
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_dir = os.path.join(base_dir, "database")
    
    # Initialize Database
    db_manager = DatabaseManager(db_dir)
    
    # Initialize Core Engine (Phases 1-3 merged)
    engine = AshleyEngine(db_manager)
    
    # Launch Modern GUI
    print("Launching Modern Interface...")
    app = ModernShell(engine)
    app.run()

if __name__ == "__main__":
    main()