import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
from gui.theme import Theme

class ModernShell:
    def __init__(self, engine):
        self.engine = engine
        self.root = tk.Tk()
        self.root.title("Ashley AI Studio - Modern Interface")
        self.root.geometry("1100x750")
        self.root.configure(bg=Theme.CHAT_BG)
        
        # Configure styles
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TCombobox", fieldbackground=Theme.INPUT_BG, background=Theme.INPUT_BG, foreground=Theme.TEXT_COLOR)
        
        self._build_ui()
        self._welcome_message()

    def _build_ui(self):
        # Main Container
        self.main_paned = tk.PanedWindow(self.root, orient=tk.HORIZONTAL, bd=0, sashwidth=2, bg="#000000")
        self.main_paned.pack(fill=tk.BOTH, expand=True)

        # --- Sidebar ---
        self.sidebar = tk.Frame(self.main_paned, bg=Theme.SIDEBAR_BG, width=260)
        self.main_paned.add(self.sidebar, minsize=200)
        
        # New Chat Button
        self.btn_new_chat = tk.Button(self.sidebar, text="+ New Chat", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR, 
                                      font=Theme.FONT_MAIN, relief=tk.FLAT, borderwidth=1, 
                                      activebackground=Theme.INPUT_BG, activeforeground=Theme.TEXT_COLOR,
                                      command=self._clear_chat)
        self.btn_new_chat.pack(fill=tk.X, padx=10, pady=15, ipady=8)
        
        # History List
        self.history_label = tk.Label(self.sidebar, text="Recent Sessions", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_MUTED, font=("Segoe UI", 9, "bold"))
        self.history_label.pack(anchor=tk.W, padx=15, pady=(10, 5))
        
        self.history_list = tk.Listbox(self.sidebar, bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR, bd=0, highlightthickness=0, font=Theme.FONT_MAIN, selectbackground=Theme.INPUT_BG)
        self.history_list.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        self.history_list.insert(tk.END, "💬 Architecture Planning")
        self.history_list.insert(tk.END, "💬 Code Debugging")
        self.history_list.insert(tk.END, "💬 General Chat")
        
        # Settings / Toolbar at bottom of sidebar
        self.sidebar_bottom = tk.Frame(self.sidebar, bg=Theme.SIDEBAR_BG)
        self.sidebar_bottom.pack(fill=tk.X, side=tk.BOTTOM, pady=15)
        
        self.btn_settings = tk.Button(self.sidebar_bottom, text="⚙ Settings", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR, 
                                      font=Theme.FONT_MAIN, relief=tk.FLAT, anchor=tk.W, command=self._open_settings)
        self.btn_settings.pack(fill=tk.X, padx=10, pady=2, ipady=5)
        
        self.btn_train = tk.Button(self.sidebar_bottom, text="⟳ Train Model", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR, 
                                      font=Theme.FONT_MAIN, relief=tk.FLAT, anchor=tk.W, command=self._train_model)
        self.btn_train.pack(fill=tk.X, padx=10, pady=2, ipady=5)

        # --- Main Chat Area ---
        self.chat_container = tk.Frame(self.main_paned, bg=Theme.CHAT_BG)
        self.main_paned.add(self.chat_container)
        
        # Top Toolbar (Model Selector like ChatGPT)
        self.top_toolbar = tk.Frame(self.chat_container, bg=Theme.CHAT_BG, height=50)
        self.top_toolbar.pack(fill=tk.X, side=tk.TOP, pady=10, padx=20)
        
        self.model_var = tk.StringVar(value="Ashley-v1 (Local)")
        self.model_selector = ttk.Combobox(self.top_toolbar, textvariable=self.model_var, values=["Ashley-v1 (Local)", "Cortana-v1 (Local)", "LLM-Backend (DLC)"], state="readonly", font=Theme.FONT_MAIN, width=20)
        self.model_selector.pack(side=tk.LEFT)
        
        self.btn_export = tk.Button(self.top_toolbar, text="⤓ Export Chat", bg=Theme.CHAT_BG, fg=Theme.TEXT_MUTED, font=("Segoe UI", 9), relief=tk.FLAT, command=self._export_chat)
        self.btn_export.pack(side=tk.RIGHT)

        # Chat Display
        self.chat_display = scrolledtext.ScrolledText(self.chat_container, bg=Theme.CHAT_BG, fg=Theme.TEXT_COLOR, 
                                                      font=Theme.FONT_MAIN, bd=0, highlightthickness=0, wrap=tk.WORD, padx=40, pady=20)
        self.chat_display.pack(fill=tk.BOTH, expand=True)
        self.chat_display.configure(state='disabled')
        
        # Input Area Container
        self.input_container = tk.Frame(self.chat_container, bg=Theme.CHAT_BG)
        self.input_container.pack(fill=tk.X, side=tk.BOTTOM, padx=60, pady=30)
        
        # Input Box (Multi-line)
        self.input_box = tk.Text(self.input_container, bg=Theme.INPUT_BG, fg=Theme.TEXT_COLOR, 
                                 font=Theme.FONT_MAIN, bd=0, highlightthickness=1, highlightbackground="#565869", 
                                 height=3, wrap=tk.WORD, padx=15, pady=15, insertbackground=Theme.TEXT_COLOR)
        self.input_box.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.input_box.bind("<Return>", self._handle_return)
        self.input_box.bind("<Shift-Return>", self._handle_shift_return)
        
        # Send Button
        self.btn_send = tk.Button(self.input_container, text="➤", bg=Theme.ACCENT_COLOR, fg="white", 
                                  font=Theme.FONT_HEADER, relief=tk.FLAT, command=self._send_message, cursor="hand2")
        self.btn_send.pack(side=tk.RIGHT, padx=(15, 0), ipadx=15, ipady=10)

    def _welcome_message(self):
        self._append_message("Ashley", "Hello! I am Ashley, your AI assistant. I am running on the Phase 1-3 Core Engine. How can I help you today?", Theme.AI_MSG_BG)

    def _clear_chat(self):
        self.chat_display.configure(state='normal')
        self.chat_display.delete(1.0, tk.END)
        self.chat_display.configure(state='disabled')
        self._welcome_message()

    def _handle_return(self, event):
        self._send_message()
        return "break" # Prevent default newline

    def _handle_shift_return(self, event):
        return # Allow default newline

    def _send_message(self):
        user_text = self.input_box.get(1.0, tk.END).strip()
        if not user_text:
            return
            
        self.input_box.delete(1.0, tk.END)
        
        # Display User Message
        self._append_message("You", user_text, Theme.USER_MSG_BG)
        
        # Process via Engine
        response = self.engine.process_input(user_text)
        
        # Display AI Response
        self._append_message("Ashley", response, Theme.AI_MSG_BG)

    def _append_message(self, sender, text, bg_color):
        self.chat_display.configure(state='normal')
        
        # We use tags to style the background of the message block
        tag_name = f"msg_{sender}_{tk.END}"
        self.chat_display.tag_configure(tag_name, background=bg_color, lmargin1=20, lmargin2=20, rmargin=20, spacing1=15, spacing3=15)
        self.chat_display.tag_configure("bold", font=("Segoe UI", 12, "bold"))
        
        self.chat_display.insert(tk.END, f"{sender}\n", ("bold", tag_name))
        self.chat_display.insert(tk.END, f"{text}\n\n", tag_name)
        
        self.chat_display.see(tk.END)
        self.chat_display.configure(state='disabled')

    def _open_settings(self):
        settings_win = tk.Toplevel(self.root)
        settings_win.title("Settings")
        settings_win.geometry("400x300")
        settings_win.configure(bg=Theme.SIDEBAR_BG)
        
        tk.Label(settings_win, text="System Settings", bg=Theme.SIDEBAR_BG, fg="white", font=Theme.FONT_HEADER).pack(pady=15)
        
        tk.Label(settings_win, text="Theme:", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR).pack(anchor=tk.W, padx=20)
        ttk.Combobox(settings_win, values=["Dark (Default)", "Light"], state="readonly").pack(fill=tk.X, padx=20, pady=5)
        
        tk.Label(settings_win, text="System Prompt:", bg=Theme.SIDEBAR_BG, fg=Theme.TEXT_COLOR).pack(anchor=tk.W, padx=20, pady=(10,0))
        tk.Entry(settings_win, bg=Theme.INPUT_BG, fg="white", insertbackground="white").pack(fill=tk.X, padx=20, pady=5)
        
        tk.Button(settings_win, text="Save", bg=Theme.ACCENT_COLOR, fg="white", relief=tk.FLAT, command=settings_win.destroy).pack(pady=20, ipadx=20)

    def _train_model(self):
        messagebox.showinfo("Training", "Scanning imports directory...\nUpdating Probability Engine and Vectors...\nTraining Complete!")

    def _export_chat(self):
        messagebox.showinfo("Export", "Chat history exported to logs/chat_export.txt")

    def run(self):
        self.root.mainloop()