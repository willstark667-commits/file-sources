# Modern Dark Theme (Inspired by ChatGPT / Claude)
class Theme:
    # Colors
    SIDEBAR_BG = "#202123"
    CHAT_BG = "#343541"
    INPUT_BG = "#40414F"
    TEXT_COLOR = "#ECECF1"
    TEXT_MUTED = "#8E8EA0"
    ACCENT_COLOR = "#10A37F"  # ChatGPT Green
    ACCENT_HOVER = "#1A7F64"
    USER_MSG_BG = "#343541"
    AI_MSG_BG = "#444654"
    
    # Fonts
    FONT_MAIN = ("Segoe UI", 11)
    FONT_CODE = ("Consolas", 10)
    FONT_HEADER = ("Segoe UI", 14, "bold")