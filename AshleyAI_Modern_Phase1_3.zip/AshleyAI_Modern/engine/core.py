import re
import random

class Scanner:
    def normalize(self, text):
        return text.strip().lower()

class Tokenizer:
    def tokenize(self, text):
        # Split into words and punctuation
        return re.findall(r'\w+|[^\w\s]', text)

class NLPProcessor:
    def __init__(self):
        self.greetings = ["hello", "hi", "hey", "greetings"]
        self.questions = ["what", "how", "why", "who", "when", "where", "?"]
        
    def analyze(self, tokens):
        intent = "statement"
        if any(g in tokens for g in self.greetings):
            intent = "greeting"
        elif any(q in tokens for q in self.questions):
            intent = "question"
        return intent

class ProbabilityEngine:
    def __init__(self):
        # Simple Markov chain stub for Phase 1-3
        self.patterns = {
            "greeting": ["Hello there!", "Hi! How can I assist you?", "Greetings!"],
            "question": ["That's an interesting question. Let me think...", "I can help with that.", "Let me check my database."],
            "statement": ["I understand.", "Tell me more.", "Noted. I have saved that to my memory."]
        }
        
    def generate(self, intent, tokens):
        if intent in self.patterns:
            return random.choice(self.patterns[intent])
        return "I am processing your input."

class AshleyEngine:
    """
    Combined Core Engine for Phases 1-3.
    Integrates Scanner, Tokenizer, NLP, and Probability.
    """
    def __init__(self, db_manager):
        self.db = db_manager
        self.scanner = Scanner()
        self.tokenizer = Tokenizer()
        self.nlp = NLPProcessor()
        self.prob_engine = ProbabilityEngine()
        
    def process_input(self, user_text):
        # 1. Scan & Normalize
        normalized_text = self.scanner.normalize(user_text)
        
        # 2. Tokenize
        tokens = self.tokenizer.tokenize(normalized_text)
        
        # 3. NLP Analysis (Intent, POS, etc.)
        intent = self.nlp.analyze(tokens)
        
        # 4. Save to DB (Memory)
        self.db.log_history("User", user_text)
        
        # 5. Generate Response
        response = self.prob_engine.generate(intent, tokens)
        
        # 6. Save AI Response
        self.db.log_history("Ashley", response)
        
        return response