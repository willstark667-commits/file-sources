#!/usr/bin/env bash
cd "$(dirname "$0")"
if command -v python3 >/dev/null 2>&1; then
    python3 launcher.py "$@"
elif command -v python >/dev/null 2>&1; then
    python launcher.py "$@"
else
    echo "No Python interpreter found. Install Python 3.9+ (python3)."
    exit 1
fi
