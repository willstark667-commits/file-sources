"""
Ashley AI Studio -- the front-end console for the whole stack.

Composes two already-working sibling projects instead of rebuilding
from the old ashley_ai_studio.py monolith (which still has
DatasetBuilder/TokenizerManager/VectorEngine/AshleyStudio each defined
2-3 times over -- see ../MASTER_STATUS_REPORT.md for the full audit):

  NanoBrain  -- the cognitive layer: nodes, personas (Ashley/Cortana/
                Generic), the Global Workspace, chat via Ollama
  GenesisOS  -- the deterministic substrate: virtual filesystem, CPU

Plus two modules ported in from the earlier extensions package
(tested standalone, now actually wired in):
  system_monitor.py     -- CPU/RAM/GPU snapshot + plain-language advice
  duplicate_detector.py -- exact (hash) + near (difflib) duplicate finder
"""

__version__ = "0.1.0"
