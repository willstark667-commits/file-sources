"""
Config for Ashley AI Studio. Sets up sys.path so Studio can import the
sibling NanoBrain and GenesisOS projects without them being installed
as packages -- all three live under one parent folder:

  AshleyStack/
  ├── AshleyStudio/   (this project)
  ├── NanoBrain/
  └── GenesisOS/
"""

import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT = os.path.dirname(ROOT)

NANOBRAIN_PATH = os.path.join(PARENT, "NanoBrain")
GENESISOS_PATH = os.path.join(PARENT, "GenesisOS")

for p in (NANOBRAIN_PATH, GENESISOS_PATH):
    if os.path.isdir(p) and p not in sys.path:
        sys.path.insert(0, p)

DATA_DIR = os.path.join(ROOT, "data")
LOGS_DIR = os.path.join(ROOT, "logs")


def ensure_dirs():
    for d in (DATA_DIR, LOGS_DIR):
        os.makedirs(d, exist_ok=True)


def nanobrain_available():
    return os.path.isdir(NANOBRAIN_PATH)


def genesisos_available():
    return os.path.isdir(GENESISOS_PATH)
