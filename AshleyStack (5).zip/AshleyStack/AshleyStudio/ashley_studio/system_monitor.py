#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
system_monitor.py — CPU / RAM / GPU inventory & live monitoring
════════════════════════════════════════════════════════════════════════════
Honest scope note up front: Python (even with psutil) can read temperatures,
utilization, and memory safely through the OS's own sensor APIs — that's all
real and implemented below. It CANNOT safely read or control raw voltage
regulator registers, VRM behavior, or do low-level "damage detection" —
that requires vendor tools with direct hardware access (HWiNFO64, GPU-Z,
OpenHardwareMonitor on Windows; `lm-sensors` / `nvidia-smi` on Linux) because
it needs kernel-level drivers this process doesn't have and shouldn't try to
get. This module reads what's safely exposed and tells you which vendor tool
to reach for when you need voltage/VRM-level detail.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import platform
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class GPUInfo:
    name: str
    vendor: str                       # "nvidia" | "amd" | "apple" | "unknown"
    memory_total_mb: Optional[int] = None
    memory_used_mb: Optional[int] = None
    utilization_pct: Optional[float] = None
    temperature_c: Optional[float] = None
    power_draw_w: Optional[float] = None


@dataclass
class SystemSnapshot:
    os_name: str
    cpu_name: str
    cpu_cores_physical: int
    cpu_cores_logical: int
    cpu_utilization_pct: float
    ram_total_gb: float
    ram_used_gb: float
    ram_available_gb: float
    cpu_temp_c: Optional[float] = None
    gpus: List[GPUInfo] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)


def _nvidia_smi_query() -> List[GPUInfo]:
    """Parse `nvidia-smi --query-gpu=...` if the binary exists — works on
    Windows and Linux with NVIDIA drivers installed. No custom driver access,
    just the vendor's own reporting tool."""
    if not shutil.which("nvidia-smi"):
        return []
    fields = "name,memory.total,memory.used,utilization.gpu,temperature.gpu,power.draw"
    try:
        out = subprocess.check_output(
            ["nvidia-smi", f"--query-gpu={fields}", "--format=csv,noheader,nounits"],
            timeout=5, text=True,
        )
    except Exception:
        return []
    gpus = []
    for line in out.strip().splitlines():
        parts = [p.strip() for p in line.split(",")]
        if len(parts) != 6:
            continue
        name, mem_t, mem_u, util, temp, power = parts
        gpus.append(GPUInfo(
            name=name, vendor="nvidia",
            memory_total_mb=_to_int(mem_t), memory_used_mb=_to_int(mem_u),
            utilization_pct=_to_float(util), temperature_c=_to_float(temp),
            power_draw_w=_to_float(power),
        ))
    return gpus


def _to_int(s: str) -> Optional[int]:
    try:
        return int(float(s))
    except Exception:
        return None


def _to_float(s: str) -> Optional[float]:
    try:
        return float(s)
    except Exception:
        return None


def _cpu_temp_via_psutil() -> Optional[float]:
    """psutil.sensors_temperatures() only works on Linux; returns None
    elsewhere (macOS blocks this at the OS level, Windows needs a
    vendor DLL psutil doesn't ship)."""
    try:
        import psutil
        temps = psutil.sensors_temperatures()
        for _, entries in temps.items():
            for entry in entries:
                if entry.current:
                    return entry.current
    except Exception:
        pass
    return None


class SystemMonitor:
    """
    snapshot() -> SystemSnapshot        one-shot read, safe to poll every
                                         few seconds for a live dashboard
    recommend() -> List[str]            plain-language efficiency suggestions
                                         based on the current snapshot
    """

    def snapshot(self) -> SystemSnapshot:
        notes = []
        try:
            import psutil
        except ImportError:
            notes.append("psutil not installed — run: pip install psutil")
            return SystemSnapshot(
                os_name=platform.system(), cpu_name=platform.processor() or "unknown",
                cpu_cores_physical=0, cpu_cores_logical=0, cpu_utilization_pct=0.0,
                ram_total_gb=0.0, ram_used_gb=0.0, ram_available_gb=0.0, notes=notes,
            )

        vm = psutil.virtual_memory()
        snap = SystemSnapshot(
            os_name=f"{platform.system()} {platform.release()}",
            cpu_name=platform.processor() or platform.machine(),
            cpu_cores_physical=psutil.cpu_count(logical=False) or 0,
            cpu_cores_logical=psutil.cpu_count(logical=True) or 0,
            cpu_utilization_pct=psutil.cpu_percent(interval=0.3),
            ram_total_gb=round(vm.total / (1024 ** 3), 2),
            ram_used_gb=round(vm.used / (1024 ** 3), 2),
            ram_available_gb=round(vm.available / (1024 ** 3), 2),
            cpu_temp_c=_cpu_temp_via_psutil(),
        )
        snap.gpus = _nvidia_smi_query()
        if not snap.gpus:
            if platform.system() == "Darwin" and "Apple" in (platform.processor() or ""):
                snap.gpus = [GPUInfo(name="Apple Silicon (unified memory)", vendor="apple")]
                notes.append("Apple Silicon shares RAM/VRAM — use Activity Monitor's "
                             "GPU history for utilization, not a separate VRAM figure.")
            else:
                notes.append("No nvidia-smi found — either no NVIDIA GPU, or drivers "
                              "not installed. AMD GPU detail needs `rocm-smi` (Linux) "
                              "or GPU-Z (Windows) — not implemented here.")
        snap.notes = notes
        return snap

    def recommend(self, snap: Optional[SystemSnapshot] = None) -> List[str]:
        """Plain suggestions — not a scoring system, just readable thresholds."""
        snap = snap or self.snapshot()
        out = []
        if snap.ram_available_gb < 2:
            out.append(f"Only {snap.ram_available_gb} GB RAM free — a mid/large "
                       f"Ollama model may fail to load or swap heavily. Close other "
                       f"apps or pick a smaller/more quantized model.")
        if snap.cpu_utilization_pct > 90:
            out.append("CPU near saturation — if Ollama is running on CPU only, "
                       "this is expected during generation; if it's high while idle, "
                       "something else is competing for cores.")
        for gpu in snap.gpus:
            if gpu.memory_total_mb and gpu.memory_used_mb:
                used_pct = 100 * gpu.memory_used_mb / gpu.memory_total_mb
                if used_pct > 90:
                    out.append(f"{gpu.name} VRAM at {used_pct:.0f}% — model may be "
                               f"spilling to system RAM (slow). Use a smaller "
                               f"quantization (e.g. Q4_K_M instead of Q8) to fit fully "
                               f"in VRAM.")
            if gpu.temperature_c and gpu.temperature_c > 83:
                out.append(f"{gpu.name} at {gpu.temperature_c}°C — check case airflow; "
                           f"sustained high temps throttle performance before they "
                           f"damage anything, so a temp-driven slowdown is often your "
                           f"first real warning sign.")
        if not out:
            out.append("Nothing concerning in this snapshot.")
        return out


if __name__ == "__main__":
    import json as _json
    from dataclasses import asdict
    mon = SystemMonitor()
    s = mon.snapshot()
    print(_json.dumps(asdict(s), indent=2))
    print("\nRecommendations:")
    for r in mon.recommend(s):
        print(" -", r)
