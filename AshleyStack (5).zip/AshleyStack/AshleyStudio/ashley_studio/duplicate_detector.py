#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
duplicate_detector.py — Find exact and near-duplicate files, code, and drafts
════════════════════════════════════════════════════════════════════════════
Covers two different jobs you described, because they need different
techniques:

  1. EXACT duplicates (same file copied twice, same code pasted into two
     scripts) -> content hash comparison. Fast, no false positives.
  2. NEAR duplicates (multiple drafts/versions of the same story, dialogue,
     or chat response with small edits between them) -> similarity scoring,
     because these are never byte-identical. Uses your existing VectorIndex
     embeddings if available (best quality), falls back to difflib's
     SequenceMatcher (no dependencies, works everywhere, just slower/cruder).
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import difflib
import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@dataclass
class DuplicateGroup:
    kind: str                 # "exact" | "near"
    similarity: float         # 1.0 for exact, 0.0-1.0 for near
    paths: List[str] = field(default_factory=list)


class DuplicateDetector:
    def __init__(self, near_duplicate_threshold: float = 0.85):
        self.near_duplicate_threshold = near_duplicate_threshold

    # ── Exact duplicates ─────────────────────────────────────────────────
    def find_exact_duplicates(self, root: str, extensions: Optional[List[str]] = None) -> List[DuplicateGroup]:
        """Walks `root`, hashes file content, groups files with identical hashes."""
        root_path = Path(root)
        hash_to_paths: Dict[str, List[str]] = {}
        for path in root_path.rglob("*"):
            if not path.is_file():
                continue
            if extensions and path.suffix not in extensions:
                continue
            try:
                content = path.read_bytes()
            except Exception:
                continue
            h = hashlib.sha256(content).hexdigest()
            hash_to_paths.setdefault(h, []).append(str(path))

        return [DuplicateGroup(kind="exact", similarity=1.0, paths=paths)
                for paths in hash_to_paths.values() if len(paths) > 1]

    # ── Near duplicates (text/code/drafts) ───────────────────────────────
    def find_near_duplicates_difflib(self, texts: Dict[str, str]) -> List[DuplicateGroup]:
        """
        texts: {label_or_path: content}. O(n^2) pairwise comparison via
        difflib — fine for tens to a couple hundred items (chat drafts,
        story versions); for thousands of files use find_near_duplicates_vector
        instead, which is O(n log n) via the vector index.
        """
        items = list(texts.items())
        groups: List[DuplicateGroup] = []
        seen = set()
        for i in range(len(items)):
            if items[i][0] in seen:
                continue
            cluster = [items[i][0]]
            for j in range(i + 1, len(items)):
                if items[j][0] in seen:
                    continue
                ratio = difflib.SequenceMatcher(None, items[i][1], items[j][1]).ratio()
                if ratio >= self.near_duplicate_threshold:
                    cluster.append(items[j][0])
                    seen.add(items[j][0])
            if len(cluster) > 1:
                seen.add(items[i][0])
                groups.append(DuplicateGroup(kind="near",
                                              similarity=self.near_duplicate_threshold,
                                              paths=cluster))
        return groups

    def find_near_duplicates_vector(self, texts: Dict[str, str], vector_index) -> List[DuplicateGroup]:
        """
        Higher-quality near-duplicate detection using your existing
        VectorIndex's embeddings (semantic similarity, not just character
        overlap — catches reworded drafts that difflib would miss). Pass
        your live VectorIndex instance in; requires ChromaDB/SentenceTransformers
        to actually be installed (falls back to difflib results otherwise).
        """
        if not getattr(vector_index, "_encoder", None):
            return self.find_near_duplicates_difflib(texts)

        import numpy as np
        labels = list(texts.keys())
        embeddings = vector_index._encoder.encode(list(texts.values()))
        groups: List[DuplicateGroup] = []
        seen = set()
        for i in range(len(labels)):
            if labels[i] in seen:
                continue
            cluster = [labels[i]]
            for j in range(i + 1, len(labels)):
                if labels[j] in seen:
                    continue
                a, b = embeddings[i], embeddings[j]
                cos_sim = float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-9))
                if cos_sim >= self.near_duplicate_threshold:
                    cluster.append(labels[j])
                    seen.add(labels[j])
            if len(cluster) > 1:
                seen.add(labels[i])
                groups.append(DuplicateGroup(kind="near",
                                              similarity=self.near_duplicate_threshold,
                                              paths=cluster))
        return groups

    # ── Chat history specific: multiple drafts of the same response ─────
    def find_draft_versions(self, history: List[dict]) -> List[DuplicateGroup]:
        """
        history: your AshleyShell/LLMBridge history list of
        {"role": ..., "content": ...} dicts. Groups assistant messages that
        look like re-drafts of the same answer (useful after several
        `draft_verify.py` revision cycles, or comparing outputs across
        different models/agents for the same prompt).
        """
        assistant_msgs = {f"turn_{i}": m["content"] for i, m in enumerate(history)
                          if m.get("role") == "assistant"}
        return self.find_near_duplicates_difflib(assistant_msgs)


if __name__ == "__main__":
    dd = DuplicateDetector(near_duplicate_threshold=0.8)
    samples = {
        "draft_v1": "Ashley is a warm and curious AI assistant who helps with coding.",
        "draft_v2": "Ashley is a warm, curious AI assistant that helps with coding.",
        "draft_v3": "Cortana is a logical, precise assistant focused on analysis.",
    }
    for g in dd.find_near_duplicates_difflib(samples):
        print(g)
