@echo off
REM Ashley AI Studio launcher for Windows.

cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 goto trypy
python launcher.py %*
goto end

:trypy
where py >nul 2>nul
if errorlevel 1 goto nopython
py -3 launcher.py %*
goto end

:nopython
echo No Python interpreter found. Install Python 3.9+ from https://www.python.org/downloads/
echo IMPORTANT: check "Add python.exe to PATH" and "tcl/tk and IDLE" during install.
pause
exit /b 1

:end
if errorlevel 1 pause
