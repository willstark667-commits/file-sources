#!/usr/bin/env python3
"""
Ashley AI Studio launcher.

    python3 launcher.py

Checks tkinter is present, best-effort auto-installs psutil (used by
the Performance tab -- everything else degrades gracefully without
it), then launches the Studio GUI. Any crash during startup is caught
and printed clearly instead of a raw traceback, and logged to
data/crash.log.
"""

import sys
import os
import subprocess
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_tkinter():
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        return False


def print_tkinter_fix():
    print("tkinter is not available in this Python installation.")
    print("Install it with your system package manager, e.g.:")
    print("  Debian/Ubuntu:  sudo apt-get install python3-tk")
    print("  Fedora:         sudo dnf install python3-tkinter")
    print("  macOS/Windows python.org installers include it already.")


def auto_install_optional(auto=True):
    import importlib
    try:
        importlib.import_module("psutil")
        return
    except ImportError:
        pass
    print("optional package 'psutil' not found (used by the Performance tab).")
    if not auto:
        return
    print("attempting auto-install (pip install --user psutil)...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "--user", "psutil"],
                       check=True, timeout=120)
        print("  installed psutil")
    except Exception as e:
        print(f"  could not auto-install psutil ({e}) -- Performance tab will show "
              f"reduced detail, everything else still runs.")


def main():
    if not check_tkinter():
        print_tkinter_fix()
        sys.exit(1)

    skip_install = "--no-auto-install" in sys.argv
    auto_install_optional(auto=not skip_install)

    from ashley_studio import config
    config.ensure_dirs()

    try:
        from ashley_studio.gui import run
        run()
    except Exception:
        tb = traceback.format_exc()
        print("=" * 60)
        print("Ashley AI Studio crashed during startup:")
        print("=" * 60)
        print(tb)
        try:
            log_path = os.path.join(config.LOGS_DIR, "crash.log")
            with open(log_path, "a") as fh:
                fh.write(tb + "\n")
            print(f"(also logged to {log_path})")
        except Exception:
            pass
        if os.name == "nt":
            input("Press Enter to close...")
        sys.exit(1)


if __name__ == "__main__":
    main()
