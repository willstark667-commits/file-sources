#!/usr/bin/env python3
"""
NanoBrain launcher.

Run with:
    python3 launcher.py

This project uses only the Python standard library (tkinter included),
so there is nothing to auto-install for the base prototype -- this
launcher checks that anyway and prints a clear message if tkinter is
missing (some minimal Linux Python installs omit it), rather than
crashing with a confusing traceback.
"""

import sys
import os
import subprocess

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


def check_tkinter():
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        return False


def try_install_tkinter():
    """tkinter can't be pip-installed -- it's a system package. Tell the
    user the real fix instead of pretending pip can solve it."""
    print("tkinter is not available in this Python installation.")
    print("It ships with Python but some minimal Linux installs split it out.")
    print("Install it with your system package manager, e.g.:")
    print("  Debian/Ubuntu:  sudo apt-get install python3-tk")
    print("  Fedora:         sudo dnf install python3-tkinter")
    print("  macOS/Windows python.org installers include it already.")


OPTIONAL_PACKAGES = {
    "pyttsx3": "pyttsx3",                     # TTS
    "speech_recognition": "SpeechRecognition",  # STT
}


def auto_install_optional(auto=True):
    """Best-effort pip install of optional voice packages. Never blocks
    launch if it fails -- voice.py degrades gracefully either way."""
    import importlib
    missing = []
    for module_name, pip_name in OPTIONAL_PACKAGES.items():
        try:
            importlib.import_module(module_name)
        except ImportError:
            missing.append(pip_name)

    if not missing:
        return
    print(f"optional voice packages not found: {missing}")
    if not auto:
        return
    print("attempting auto-install (pip install --user)...")
    for pip_name in missing:
        try:
            subprocess.run(
                [sys.executable, "-m", "pip", "install", "--user", pip_name],
                check=True, timeout=120,
            )
            print(f"  installed {pip_name}")
        except Exception as e:
            print(f"  could not auto-install {pip_name} ({e}) -- voice features "
                  f"involving it will show as unavailable, everything else still runs.")


def main():
    if not check_tkinter():
        try_install_tkinter()
        sys.exit(1)

    skip_install = "--no-auto-install" in sys.argv
    auto_install_optional(auto=not skip_install)

    from nanobrain import config
    config.ensure_dirs()

    from nanobrain.gui import run
    run()


if __name__ == "__main__":
    main()
