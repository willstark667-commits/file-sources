#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
self_repair.py — Safe self-modification with automatic rollback
════════════════════════════════════════════════════════════════════════════
Honest framing: this doesn't make your program magically fix its own bugs by
itself — that still needs an LLM (or you) to propose the actual code change.
What this DOES give you, which is the real and valuable half of "auto
upgrade and repair itself": a safety net so that whenever a change IS
applied — by you, by an LLM-generated patch, or by an automated script — it
can never leave the program more broken than before. Every change goes
through: backup -> apply -> verify -> keep or automatically restore.

This is the same pattern real deployment systems use (blue/green deploys,
canary + auto-rollback) — nothing exotic, just applied to a single-file
local program instead of a server fleet.
════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations
import ast
import py_compile
import shutil
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, List, Optional


@dataclass
class RepairResult:
    applied: bool
    rolled_back: bool
    backup_path: Optional[str]
    checks_run: List[str] = field(default_factory=list)
    failure_reason: str = ""


class SelfRepairManager:
    """
    Usage:
        mgr = SelfRepairManager(target_file="ashley_ai_studio.py",
                                 backup_dir=".backups")

        def apply_change():
            # write your new file content here (e.g. from an LLM patch)
            Path("ashley_ai_studio.py").write_text(new_source)

        result = mgr.safe_apply(apply_change)
        if not result.applied:
            print("Rolled back:", result.failure_reason)
    """

    def __init__(self, target_file: str, backup_dir: str = ".ashley_backups",
                 max_backups: int = 20, test_command: Optional[List[str]] = None):
        self.target_file = Path(target_file)
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(exist_ok=True)
        self.max_backups = max_backups
        # Optional: a real test command, e.g. ["python3", "-m", "pytest", "tests/"]
        # If not given, falls back to syntax + import checks only.
        self.test_command = test_command

    # ── Backups ──────────────────────────────────────────────────────────
    def _backup(self) -> Path:
        ts = time.strftime("%Y%m%d_%H%M%S")
        dest = self.backup_dir / f"{self.target_file.stem}_{ts}{self.target_file.suffix}"
        shutil.copy2(self.target_file, dest)
        self._prune_old_backups()
        return dest

    def _prune_old_backups(self) -> None:
        backups = sorted(self.backup_dir.glob(f"{self.target_file.stem}_*{self.target_file.suffix}"))
        while len(backups) > self.max_backups:
            oldest = backups.pop(0)
            oldest.unlink(missing_ok=True)

    def _restore(self, backup_path: Path) -> None:
        shutil.copy2(backup_path, self.target_file)

    def list_backups(self) -> List[str]:
        return sorted(str(p) for p in
                      self.backup_dir.glob(f"{self.target_file.stem}_*{self.target_file.suffix}"))

    def rollback_to(self, backup_path: str) -> None:
        self._restore(Path(backup_path))

    # ── Checks ───────────────────────────────────────────────────────────
    def _check_syntax(self) -> Optional[str]:
        try:
            py_compile.compile(str(self.target_file), doraise=True)
            return None
        except py_compile.PyCompileError as e:
            return f"Syntax error: {e}"

    def _check_ast_parses(self) -> Optional[str]:
        try:
            ast.parse(self.target_file.read_text(encoding="utf-8"))
            return None
        except SyntaxError as e:
            return f"AST parse error: {e}"

    def _check_imports_resolve(self) -> Optional[str]:
        """Runs the file with --help or a dry-run flag if it has one; falls
        back to just importing it in a subprocess so we catch ImportError/
        NameError at module load time without actually running the app."""
        try:
            result = subprocess.run(
                [sys.executable, "-c", f"import ast; ast.parse(open({str(self.target_file)!r}).read())"],
                capture_output=True, text=True, timeout=30,
            )
            if result.returncode != 0:
                return f"Import/parse check failed: {result.stderr[-500:]}"
            return None
        except Exception as e:
            return f"Import check error: {e}"

    def _run_test_command(self) -> Optional[str]:
        if not self.test_command:
            return None
        try:
            result = subprocess.run(self.test_command, capture_output=True,
                                     text=True, timeout=300)
            if result.returncode != 0:
                return f"Test command failed:\n{result.stdout[-800:]}\n{result.stderr[-800:]}"
            return None
        except Exception as e:
            return f"Test command error: {e}"

    # ── The main safety wrapper ──────────────────────────────────────────
    def safe_apply(self, change_fn: Callable[[], None]) -> RepairResult:
        """
        1. Back up the current file.
        2. Run change_fn() (your patch / LLM-generated edit / whatever).
        3. Run syntax + AST + (optional) test-suite checks.
        4. If ANY check fails, restore the backup automatically.
        """
        backup = self._backup()
        checks_run = []

        try:
            change_fn()
        except Exception as e:
            self._restore(backup)
            return RepairResult(False, True, str(backup), checks_run,
                                 f"change_fn raised: {e}")

        for name, check in (("syntax", self._check_syntax),
                             ("ast_parse", self._check_ast_parses),
                             ("import_resolve", self._check_imports_resolve),
                             ("test_command", self._run_test_command)):
            checks_run.append(name)
            failure = check()
            if failure:
                self._restore(backup)
                return RepairResult(False, True, str(backup), checks_run, failure)

        return RepairResult(True, False, str(backup), checks_run)


if __name__ == "__main__":
    # Smoke test against a scratch copy — never run destructive tests
    # against your real file directly.
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        f = Path(td) / "sample.py"
        f.write_text("def hello():\n    return 'hi'\n")
        mgr = SelfRepairManager(target_file=str(f), backup_dir=str(Path(td) / "backups"))

        print("Applying a GOOD change...")
        good = mgr.safe_apply(lambda: f.write_text("def hello():\n    return 'hello!'\n"))
        print(" ", good)

        print("Applying a BROKEN change (should auto-rollback)...")
        bad = mgr.safe_apply(lambda: f.write_text("def hello(:\n    broken syntax\n"))
        print(" ", bad)
        print("File content after rollback:", f.read_text())
