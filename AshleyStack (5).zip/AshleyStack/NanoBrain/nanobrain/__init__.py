"""NanoBrain - a tiny prototype internal neural network agent.

Small, honest scope: a handful of neuron-nodes, each with its own
storage folder and a couple of learned vectors, wired into a network
that can be trained on a toy task, plus a non-destructive file scanner
and a CRT-style Tkinter shell to drive it all.
"""

__version__ = "0.1.0"
