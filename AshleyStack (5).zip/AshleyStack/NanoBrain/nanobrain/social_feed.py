"""
A local, self-contained "social feed" for the agents -- Ashley, Cortana,
and Generic can post short text (thoughts, things they generated,
reactions to a workspace broadcast) and comment on each other's posts.

Honest scope: this is NOT connected to any real social media platform,
email service, or the internet. It's a local JSON-backed feed, the
same kind of local data structure as chat history or the decision
log -- "social" in the sense of agent-to-agent interaction you can
read, not in the sense of posting anywhere public.
"""

import json
import os
import time

from . import config

FEED_FILE = os.path.join(config.DATA_DIR, "social_feed.json")


class Post:
    def __init__(self, author, content, post_id=None):
        self.id = post_id or f"post_{int(time.time() * 1000)}"
        self.author = author
        self.content = content
        self.timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
        self.comments = []  # list of {author, content, timestamp}

    def to_dict(self):
        return {"id": self.id, "author": self.author, "content": self.content,
                "timestamp": self.timestamp, "comments": self.comments}

    @classmethod
    def from_dict(cls, d):
        p = cls(d["author"], d["content"], post_id=d["id"])
        p.timestamp = d["timestamp"]
        p.comments = d.get("comments", [])
        return p


class SocialFeed:
    def __init__(self, path=None):
        self.path = path or FEED_FILE
        self.posts = []
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, "r") as fh:
                self.posts = [Post.from_dict(d) for d in json.load(fh)]

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as fh:
            json.dump([p.to_dict() for p in self.posts], fh, indent=2)

    def post(self, author, content):
        p = Post(author, content)
        self.posts.append(p)
        self.posts = self.posts[-100:]  # cap history
        self.save()
        return p

    def comment(self, post_id, author, content):
        for p in self.posts:
            if p.id == post_id:
                p.comments.append({"author": author, "content": content,
                                   "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")})
                self.save()
                return True
        return False

    def recent(self, n=20):
        return self.posts[-n:]

    def agent_reacts(self, agent, post: Post):
        """Have `agent` (a nanobrain.agents.Agent) generate an in-character
        comment on a post, via Ollama, using its own persona system prompt."""
        from . import ollama_bridge
        prompt = f"{post.author} posted: \"{post.content}\"\n\nWrite a short, one-sentence in-character reaction/comment."
        reply = ollama_bridge.chat([{"role": "user", "content": prompt}], system=agent.persona.system_prompt())
        self.comment(post.id, agent.name, reply)
        return reply
