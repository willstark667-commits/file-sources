"""
Choice/decision engine: given a scenario and a set of options, the
persona (via Ollama, using its system prompt) picks one and gives a
reason, in character. Every decision is logged, and feeds back into
the persona's trait weights slightly -- e.g. picking the cautious
option nudges "planning" up, picking the bold option nudges
"creativity" up. This is the real, bounded version of "let agents
make choices that affect how they behave" -- it does not simulate
free will or genuine agency; it's an LLM call plus a logged record
plus a small numeric nudge, the same mechanism used everywhere else
in this project.
"""

import json
import os
import time

from . import config
from . import ollama_bridge

DECISION_LOG_FILE = os.path.join(config.DATA_DIR, "decision_log.json")

# option_type -> trait nudged when that type of option is chosen
TRAIT_NUDGE_MAP = {
    "cautious": ("planning", 0.02),
    "bold": ("creativity", 0.02),
    "logical": ("logic", 0.02),
    "warm": ("warmth", 0.02),
    "analytical": ("reasoning", 0.02),
}


class Decision:
    def __init__(self, scenario, options, chosen, reasoning, agent_name):
        self.scenario = scenario
        self.options = options
        self.chosen = chosen
        self.reasoning = reasoning
        self.agent_name = agent_name
        self.timestamp = time.strftime("%Y-%m-%d %H:%M:%S")

    def to_dict(self):
        return {"scenario": self.scenario, "options": self.options, "chosen": self.chosen,
                "reasoning": self.reasoning, "agent_name": self.agent_name, "timestamp": self.timestamp}


def decide(agent, scenario: str, options: list, option_types: dict = None):
    """agent: a nanobrain.agents.Agent (has .persona, .network).
    options: list of short option strings.
    option_types: optional {option_string: type} where type is one of
    TRAIT_NUDGE_MAP's keys, to drive the small trait feedback.
    """
    option_types = option_types or {}
    options_text = "\n".join(f"{i+1}. {opt}" for i, opt in enumerate(options))
    prompt = (f"Scenario: {scenario}\n\nOptions:\n{options_text}\n\n"
             f"Pick exactly one option (by its number) and give a one-sentence reason, "
             f"staying in character.")

    reply = ollama_bridge.chat([{"role": "user", "content": prompt}], system=agent.persona.system_prompt())

    chosen = options[0]  # safe fallback if parsing fails
    for i, opt in enumerate(options):
        if f"{i+1}." in reply or f"{i+1})" in reply or opt.lower() in reply.lower():
            chosen = opt
            break

    decision = Decision(scenario, options, chosen, reply, agent.name)
    _append_log(decision)

    opt_type = option_types.get(chosen)
    if opt_type in TRAIT_NUDGE_MAP:
        trait, delta = TRAIT_NUDGE_MAP[opt_type]
        agent.persona.adjust_trait(trait, delta)
        agent.persona.save()

    return decision


def _append_log(decision: Decision):
    os.makedirs(os.path.dirname(DECISION_LOG_FILE), exist_ok=True)
    log = []
    if os.path.exists(DECISION_LOG_FILE):
        with open(DECISION_LOG_FILE, "r") as fh:
            log = json.load(fh)
    log.append(decision.to_dict())
    log = log[-200:]
    with open(DECISION_LOG_FILE, "w") as fh:
        json.dump(log, fh, indent=2)


def history(agent_name=None, n=20):
    if not os.path.exists(DECISION_LOG_FILE):
        return []
    with open(DECISION_LOG_FILE, "r") as fh:
        log = json.load(fh)
    if agent_name:
        log = [d for d in log if d["agent_name"] == agent_name]
    return log[-n:]
