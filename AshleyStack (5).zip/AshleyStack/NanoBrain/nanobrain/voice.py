"""
Voice I/O for the agent's own generic synthetic voice -- text-to-speech
output and speech-to-text input. Scope note, deliberately: this wraps
existing, general-purpose engines (pyttsx3 for TTS, SpeechRecognition
for STT) to give the agent *a* voice. It does not attempt to clone or
reproduce any specific real person's voice -- that would need a
different, identity-mimicry pipeline this project intentionally
doesn't build, for the same reason an earlier session declined
scraping real people's photos for biometric measurement.

Both engines are optional. If the packages aren't installed, `.available`
is False and speak()/listen() return a clear message instead of crashing.
"""

import queue
import threading

try:
    import pyttsx3
    _TTS_OK = True
except ImportError:
    _TTS_OK = False

try:
    import speech_recognition as sr
    _STT_OK = True
except ImportError:
    _STT_OK = False


class VoiceEngine:
    def __init__(self):
        self.tts_available = _TTS_OK
        self.stt_available = _STT_OK
        self.live = False  # toggled on/off; GUI shows this state clearly
        self._tts_engine = None
        self._lock = threading.Lock()

        if self.tts_available:
            try:
                self._tts_engine = pyttsx3.init()
            except Exception:
                self.tts_available = False

    def list_voices(self):
        """Lists TTS voices actually installed on this system -- e.g. on
        Windows this includes SAPI5 voices like 'Microsoft Zira Desktop'
        or 'Microsoft David Desktop' if installed. pyttsx3 exposes
        whatever the OS has; it doesn't ship or fake extra voices."""
        if not self.tts_available:
            return []
        try:
            voices = self._tts_engine.getProperty("voices")
            return [{"id": v.id, "name": v.name} for v in voices]
        except Exception:
            return []

    def set_voice(self, name_or_id):
        """Select a voice by name (partial match, case-insensitive) or
        exact id. Returns True if a match was set, False otherwise."""
        if not self.tts_available:
            return False
        for v in self.list_voices():
            if name_or_id.lower() in v["name"].lower() or name_or_id == v["id"]:
                self._tts_engine.setProperty("voice", v["id"])
                return True
        return False

    def status_text(self):
        if not (self.tts_available or self.stt_available):
            return ("voice: unavailable -- install with `pip install pyttsx3 SpeechRecognition` "
                    "(and, for STT, a working microphone + `pyaudio`) to enable it")
        parts = []
        parts.append("TTS: ready" if self.tts_available else "TTS: not installed")
        parts.append("STT: ready" if self.stt_available else "STT: not installed")
        parts.append("LIVE" if self.live else "off")
        return " | ".join(parts)

    def toggle(self):
        self.live = not self.live
        return self.live

    def speak(self, text):
        if not self.live:
            return "(voice is off -- toggle it on first)"
        if not self.tts_available:
            return "[TTS unavailable] pip install pyttsx3"
        with self._lock:
            try:
                self._tts_engine.say(text)
                self._tts_engine.runAndWait()
                return "(spoken)"
            except Exception as e:
                return f"[TTS error] {e}"

    def listen_once(self, timeout=5):
        """Blocking single-utterance listen. Returns transcribed text or
        a clear error/fallback string -- never raises into the caller."""
        if not self.live:
            return "(voice is off -- toggle it on first)"
        if not self.stt_available:
            return "[STT unavailable] pip install SpeechRecognition pyaudio"
        try:
            recognizer = sr.Recognizer()
            with sr.Microphone() as source:
                audio = recognizer.listen(source, timeout=timeout)
            return recognizer.recognize_google(audio)
        except Exception as e:
            return f"[STT error] {e}"
