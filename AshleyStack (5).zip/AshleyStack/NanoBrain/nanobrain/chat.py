"""
Simple chat history: an ordered list of messages, persisted to JSON.
Nothing fancy -- this is the "chatbox and chat history and messaging
system" piece, kept small and reliable.
"""

import json
import os
import time

from . import config


class ChatHistory:
    def __init__(self, path=None):
        self.path = path or config.CHAT_HISTORY_FILE
        self.messages = []  # [{"role": "user"/"assistant", "content": str, "time": str}]
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, "r") as fh:
                self.messages = json.load(fh)

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as fh:
            json.dump(self.messages, fh, indent=2)

    def add(self, role, content):
        self.messages.append({
            "role": role,
            "content": content,
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        self.save()

    def recent(self, n=20):
        return self.messages[-n:]

    def as_ollama_messages(self, n=20):
        return [{"role": m["role"], "content": m["content"]} for m in self.recent(n)]

    def clear(self):
        self.messages = []
        self.save()
