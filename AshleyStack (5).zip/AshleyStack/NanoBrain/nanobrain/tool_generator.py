"""
Tool Generator -- Ollama writes a candidate tool as Python source, and
it only becomes a trusted, registered tool after passing sandbox
checks. Nothing generated here is ever imported into the running
process directly; it's checked in a separate subprocess first.

Honest scope: this doesn't make an LLM a reliable software engineer --
generated code can still be wrong, inefficient, or solve the wrong
problem. What this DOES give you is the same real safety pattern used
in self_repair.py (syntax check -> isolated dry run -> accept or
discard), so a bad generation can never crash or corrupt the main
app -- it just gets rejected with the error shown.
"""

import ast
import os
import py_compile
import subprocess
import sys

from . import config
from . import ollama_bridge

GENERATED_DIR = os.path.join(config.DATA_DIR, "generated_tools")

TOOL_GENERATION_SYSTEM_PROMPT = """You write small, single-purpose Python tool modules.
Rules:
- Output ONLY Python code, no markdown fences, no explanation text.
- The module must define exactly one function matching the requested purpose.
- Use only the Python standard library unless the request clearly requires something else.
- Include a docstring explaining what it does.
- Do not include a __main__ block that does anything destructive (no file deletion, no
  network calls, no subprocess calls to system-modifying commands).
- Keep it under 60 lines."""


class ToolGenerationResult:
    def __init__(self, accepted, name, code, error=None, path=None):
        self.accepted = accepted
        self.name = name
        self.code = code
        self.error = error
        self.path = path

    def to_dict(self):
        return {"accepted": self.accepted, "name": self.name, "error": self.error, "path": self.path}


def _check_syntax(code: str):
    try:
        ast.parse(code)
        return None
    except SyntaxError as e:
        return f"syntax error: {e}"


def _check_no_obvious_danger(code: str):
    """Cheap denylist, not a real sandbox -- catches the obvious cases
    (file deletion, arbitrary shell execution, network calls) so a
    generated 'tool' can't quietly do something destructive. This is a
    speed bump, not a security boundary; only run generated tools you
    would be willing to read yourself."""
    danger_markers = ["os.remove", "os.rmdir", "shutil.rmtree", "os.system(",
                       "subprocess.Popen", "eval(", "exec(", "socket.", "urllib.request.urlopen("]
    hits = [m for m in danger_markers if m in code]
    if hits:
        return f"contains potentially unsafe calls: {hits}"
    return None


def _dry_run_isolated(path: str, timeout=10):
    """Runs an actual isolated import in a fresh subprocess (not this
    process), so a bad generated module can only crash its own
    throwaway process."""
    try:
        result = subprocess.run(
            [sys.executable, "-c", f"import importlib.util; "
             f"spec = importlib.util.spec_from_file_location('candidate', {path!r}); "
             f"mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)"],
            capture_output=True, text=True, timeout=timeout,
        )
        if result.returncode != 0:
            return f"import/exec failed in sandbox: {result.stderr[-500:]}"
        return None
    except subprocess.TimeoutExpired:
        return f"timed out after {timeout}s (possible infinite loop)"
    except Exception as e:
        return f"sandbox error: {e}"


def generate_tool(description: str, tool_name: str, model=None) -> ToolGenerationResult:
    """Ask Ollama to write a tool module for `description`, name it
    `tool_name`, and only accept it if it passes: syntax check, denylist
    check, py_compile, and an isolated import/exec dry run."""
    os.makedirs(GENERATED_DIR, exist_ok=True)

    prompt = f"Write a Python tool module that does the following: {description}"
    code = ollama_bridge.summarize(prompt, instruction=TOOL_GENERATION_SYSTEM_PROMPT, model=model)

    if code.startswith("[Ollama unavailable]"):
        return ToolGenerationResult(False, tool_name, code, error=code)

    # strip accidental markdown fences -- models do this even when told not to
    code = code.strip()
    if code.startswith("```"):
        lines = code.splitlines()
        code = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])

    for check in (_check_syntax, _check_no_obvious_danger):
        err = check(code)
        if err:
            return ToolGenerationResult(False, tool_name, code, error=err)

    candidate_path = os.path.join(GENERATED_DIR, f"{tool_name}.py")
    with open(candidate_path, "w") as fh:
        fh.write(code)

    try:
        py_compile.compile(candidate_path, doraise=True)
    except py_compile.PyCompileError as e:
        os.remove(candidate_path)
        return ToolGenerationResult(False, tool_name, code, error=f"compile error: {e}")

    err = _dry_run_isolated(candidate_path)
    if err:
        os.remove(candidate_path)
        return ToolGenerationResult(False, tool_name, code, error=err)

    return ToolGenerationResult(True, tool_name, code, path=candidate_path)
