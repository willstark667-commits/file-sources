"""
Central configuration. ROOT is anchored to this file's location,
not the current working directory -- this is the single most common
bug class in these kinds of projects (paths breaking depending on
where you launch the script from), so it's fixed here once and
imported everywhere else.
"""

import os

# nanobrain/config.py -> project root is one level up
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA_DIR = os.path.join(ROOT, "data")
WORKSPACE_DIR = os.path.join(ROOT, "workspace")
LOGS_DIR = os.path.join(ROOT, "logs")
CHECKPOINT_FILE = os.path.join(DATA_DIR, "network_checkpoint.json")
SCAN_INDEX_FILE = os.path.join(DATA_DIR, "file_index.json")
CHAT_HISTORY_FILE = os.path.join(DATA_DIR, "chat_history.json")
KEYWORD_FILE = os.path.join(DATA_DIR, "keywords.json")
PERSONA_FILE = os.path.join(DATA_DIR, "persona_ashley.json")
UPLOADS_DIR = os.path.join(DATA_DIR, "uploads")

OLLAMA_HOST = "http://localhost:11434"
OLLAMA_MODEL = "llama3"  # change to whatever you have pulled locally

# training-time tuning
SECONDS_PER_EPOCH_ESTIMATE = 0.0008  # rough ETA estimate for the toy net
GROK_LOSS_THRESHOLD = 0.05           # below this, keep training extra "grok" passes
GROK_EXTRA_EPOCHS = 40

# Toy network defaults
MIN_NODES = 3
MAX_NODES = 8
FILES_PER_NODE = 3          # spawn ~1 node per N indexed files
VECTORS_PER_NODE = (5, 10)  # min, max
FILES_PER_NODE_STORAGE = (5, 15)  # each node's own folder gets this many small files

LEARNING_RATE = 0.15
TRAIN_EPOCHS_PER_STEP = 25


def ensure_dirs():
    """Create only the directories this project actually uses.
    Safe to call every launch -- must never wipe existing data.
    """
    for d in (DATA_DIR, WORKSPACE_DIR, LOGS_DIR, UPLOADS_DIR):
        os.makedirs(d, exist_ok=True)
