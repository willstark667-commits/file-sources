"""
Picks which locally-pulled Ollama model to use for a given task type.

Honest scope: this can only route among models you've actually pulled
(`ollama pull ...`) -- it can't conjure a coding-specialist model out
of nothing. If you've only pulled one model, every task type routes to
that one model; the router becomes useful once you've pulled more than
one and want e.g. a smaller/faster model for quick chat and a larger
one for code.

Preference lists are ordered by common reputation for that task type
as of this writing -- not benchmarked on your machine. Use
ollama_bridge.benchmark() per-model if you want a measured answer
instead of a reputation-based guess.
"""

from . import ollama_bridge

TASK_PREFERENCES = {
    "coding":      ["deepseek-coder", "codellama", "qwen2.5-coder", "deepseek", "qwen"],
    "reasoning":   ["qwen2.5", "deepseek-r1", "qwen", "llama3.1", "llama3"],
    "chat":        ["llama3.2", "llama3.1", "llama3", "mistral", "phi3"],
    "fast":        ["phi3", "gemma2", "llama3.2", "qwen2.5:0.5b"],
    "summarize":   ["llama3.2", "mistral", "phi3"],
}


def route(task_type: str, fallback=None):
    """Returns the name of an installed model best matching task_type,
    or `fallback` (or the first installed model) if nothing matches."""
    installed = ollama_bridge.list_models()
    if not installed:
        return fallback

    preferences = TASK_PREFERENCES.get(task_type, [])
    for pref in preferences:
        for name in installed:
            if name.split(":")[0].lower().startswith(pref.split(":")[0].lower()):
                return name
    return fallback or installed[0]


def routing_report():
    installed = ollama_bridge.list_models()
    if not installed:
        return "no models pulled -- run e.g. `ollama pull llama3.2`"
    lines = [f"installed models: {installed}", ""]
    for task_type in TASK_PREFERENCES:
        choice = route(task_type)
        lines.append(f"  {task_type:12s} -> {choice}")
    return "\n".join(lines)
