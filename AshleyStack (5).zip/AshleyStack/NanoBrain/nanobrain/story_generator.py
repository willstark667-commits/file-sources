"""
Backstory and short-scene generator for personas, via Ollama.

Deliberate design choice, stated plainly: this module keeps two eras
structurally separate rather than generating one continuous no-holds-
barred biography:

  - childhood/school-era content (e.g. "Ashley and Cortana grew up
    together like sisters") is generated with a system prompt that
    restricts it to friendship, family, school, and everyday life --
    no romantic or sexual content, ever, for this era.
  - adult-era profile notes (occupation, personality, light relationship-
    status flavor) are a separate, short, non-explicit function, clearly
    reserved for the character's present-day adult characterization.

This isn't an arbitrary restriction bolted on top -- it's the correct
way to model "these two characters have a childhood friendship AND
adult lives" without ever blending the two.
"""

from . import ollama_bridge

CHILDHOOD_SYSTEM_PROMPT = """You write short, warm, all-ages backstory scenes about
childhood friendship, family, and school life. The characters described are best
friends who grew up together like sisters. Keep everything strictly platonic:
friendship, sibling-like bond, school, family, everyday life, small triumphs and
struggles. Never include romantic or sexual content of any kind in this era."""

ADULT_PROFILE_SYSTEM_PROMPT = """You write brief, tasteful, PG-level personality and
lifestyle notes for an adult fictional character's profile (occupation, hobbies,
personality, general relationship orientation stated plainly and briefly). Keep it
short, non-explicit, and grounded -- a character bio entry, not a scene."""


def generate_childhood_scene(setting: str, detail_prompt: str, model=None) -> str:
    """setting: e.g. 'a school in Japan'. detail_prompt: what should
    happen in the scene (a school day, meeting for the first time, a
    small conflict resolved, etc.) -- kept to friendship/family/school."""
    prompt = (f"Setting: {setting}\n"
             f"Write a short (150-250 word) all-ages scene: {detail_prompt}\n"
             f"The two characters are childhood best friends, like sisters.")
    return ollama_bridge.chat([{"role": "user", "content": prompt}], system=CHILDHOOD_SYSTEM_PROMPT)


def generate_adult_profile_note(persona, aspect: str, model=None) -> str:
    """aspect: e.g. 'occupation and daily routine', 'personality and
    values', 'general relationship orientation, stated briefly'."""
    prompt = f"Write a brief profile note (2-4 sentences) about: {aspect}"
    return ollama_bridge.chat([{"role": "user", "content": prompt}], system=persona.system_prompt() + " " + ADULT_PROFILE_SYSTEM_PROMPT)
