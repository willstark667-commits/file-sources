"""
Connection status across LLM backends: Ollama (local, no key needed),
and optionally Anthropic/OpenAI if the person has set their own API
key as an environment variable.

Important honest framing: there is no way for this program to "link
into" a running Claude.ai chat or ChatGPT session -- those aren't
reachable from a local script. What IS real: the Anthropic API and
OpenAI API are ordinary HTTPS endpoints you can call with your own API
key, exactly like Ollama's local HTTP API. This module checks each
backend the same way -- a real, lightweight request -- and reports
why a backend is unreachable (no key set, auth rejected, rate
limited, network error) instead of a vague "disconnected."

This module never reads, logs, or stores an API key anywhere except
passing it in the Authorization header of the single request it
makes. Keys are read fresh from the environment each call.
"""

import json
import os
import urllib.request
import urllib.error

from . import config
from . import ollama_bridge


def _probe_url(url, headers, body=None, timeout=8):
    try:
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, headers=headers,
                                     method="POST" if body else "GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, None
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode(errors="ignore")[:300]
    except urllib.error.URLError as e:
        return None, str(e.reason)
    except Exception as e:
        return None, str(e)


def check_ollama():
    available = ollama_bridge.is_available()
    return {
        "backend": "ollama", "connected": available,
        "reason": "reachable at " + config.OLLAMA_HOST if available else
                  f"can't reach {config.OLLAMA_HOST} -- is `ollama serve` running?",
        "needs_key": False,
    }


def check_anthropic():
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return {"backend": "anthropic (Claude API)", "connected": False,
                "reason": "no ANTHROPIC_API_KEY environment variable set", "needs_key": True}
    status, err = _probe_url(
        "https://api.anthropic.com/v1/messages",
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        body={"model": "claude-3-5-haiku-20241022", "max_tokens": 1, "messages": [{"role": "user", "content": "hi"}]},
    )
    if status == 200:
        return {"backend": "anthropic (Claude API)", "connected": True, "reason": "key valid, API reachable", "needs_key": True}
    if status == 401:
        return {"backend": "anthropic (Claude API)", "connected": False, "reason": "API key rejected (401 -- check the key)", "needs_key": True}
    if status == 429:
        return {"backend": "anthropic (Claude API)", "connected": False, "reason": "rate limited (429) -- key works, but you're over your current limit", "needs_key": True}
    return {"backend": "anthropic (Claude API)", "connected": False,
            "reason": f"unreachable: {err or status}", "needs_key": True}


def check_openai():
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return {"backend": "openai (Codex/GPT API)", "connected": False,
                "reason": "no OPENAI_API_KEY environment variable set", "needs_key": True}
    status, err = _probe_url(
        "https://api.openai.com/v1/models",
        headers={"Authorization": f"Bearer {key}"},
    )
    if status == 200:
        return {"backend": "openai (Codex/GPT API)", "connected": True, "reason": "key valid, API reachable", "needs_key": True}
    if status == 401:
        return {"backend": "openai (Codex/GPT API)", "connected": False, "reason": "API key rejected (401 -- check the key)", "needs_key": True}
    if status == 429:
        return {"backend": "openai (Codex/GPT API)", "connected": False, "reason": "rate limited (429) -- key works, but you're over your current quota/free-tier limit", "needs_key": True}
    return {"backend": "openai (Codex/GPT API)", "connected": False,
            "reason": f"unreachable: {err or status}", "needs_key": True}


def check_all():
    return [check_ollama(), check_anthropic(), check_openai()]


def report(results=None):
    results = results or check_all()
    lines = []
    for r in results:
        mark = "CONNECTED" if r["connected"] else "disconnected"
        lines.append(f"  {r['backend']:24s} {mark:12s} -- {r['reason']}")
    return "\n".join(lines)
