"""
Test-pattern generators for exercising a media pipeline before any real
generative model is wired in -- these produce genuine signals (a real
sine wave at a real frequency, real random noise), not AI-generated
content. Useful for testing "does my save/load/playback code work"
independently of whether you have an image/video/audio model hooked up
yet. Stdlib only (wave, struct, random) -- no extra dependencies.
"""

import math
import os
import random
import struct
import wave

from . import config

MEDIA_TEST_DIR = os.path.join(config.DATA_DIR, "media_test")


def generate_test_tone(path=None, frequency_hz=440.0, duration_s=1.0, volume=0.5,
                       sample_rate=44100):
    """A real sine wave at `frequency_hz` (e.g. 440 = concert A), written
    as a standard 16-bit mono WAV file. volume is 0.0-1.0."""
    os.makedirs(MEDIA_TEST_DIR, exist_ok=True)
    path = path or os.path.join(MEDIA_TEST_DIR, f"tone_{int(frequency_hz)}hz.wav")
    n_samples = int(duration_s * sample_rate)
    amplitude = int(32767 * max(0.0, min(1.0, volume)))

    with wave.open(path, "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)  # 16-bit
        wav_file.setframerate(sample_rate)
        frames = bytearray()
        for i in range(n_samples):
            sample = int(amplitude * math.sin(2 * math.pi * frequency_hz * i / sample_rate))
            frames += struct.pack("<h", sample)
        wav_file.writeframes(bytes(frames))
    return path


def generate_test_noise(path=None, duration_s=1.0, volume=0.3, sample_rate=44100):
    """Genuine white noise (uniformly random samples) -- useful as a
    stand-in for 'any audio at all' when testing file I/O."""
    os.makedirs(MEDIA_TEST_DIR, exist_ok=True)
    path = path or os.path.join(MEDIA_TEST_DIR, "noise.wav")
    n_samples = int(duration_s * sample_rate)
    amplitude = int(32767 * max(0.0, min(1.0, volume)))

    with wave.open(path, "w") as wav_file:
        wav_file.setnchannels(1)
        wav_file.setsampwidth(2)
        wav_file.setframerate(sample_rate)
        frames = bytearray()
        for _ in range(n_samples):
            sample = random.randint(-amplitude, amplitude)
            frames += struct.pack("<h", sample)
        wav_file.writeframes(bytes(frames))
    return path


def generate_test_image(path=None, width=64, height=64, mode="random"):
    """Writes a real PPM (Portable Pixmap) image -- plain-text header
    plus raw RGB bytes, viewable in most image tools and trivially
    convertible to PNG. mode: 'random' (colored static) or 'gradient'."""
    os.makedirs(MEDIA_TEST_DIR, exist_ok=True)
    path = path or os.path.join(MEDIA_TEST_DIR, f"test_{width}x{height}_{mode}.ppm")

    with open(path, "wb") as fh:
        fh.write(f"P6\n{width} {height}\n255\n".encode("ascii"))
        for y in range(height):
            for x in range(width):
                if mode == "gradient":
                    r, g, b = int(255 * x / width), int(255 * y / height), 128
                else:
                    r, g, b = random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)
                fh.write(bytes([r, g, b]))
    return path


def pitch_estimate_from_wav(path):
    """A real (if simple) pitch estimate via zero-crossing rate -- good
    enough to sanity-check 'is this roughly a low or high tone', not a
    substitute for proper FFT-based pitch detection (librosa/numpy)."""
    with wave.open(path, "r") as wav_file:
        n_frames = wav_file.getnframes()
        rate = wav_file.getframerate()
        raw = wav_file.readframes(n_frames)
        samples = struct.unpack(f"<{n_frames}h", raw[:n_frames * 2])

    crossings = sum(1 for i in range(1, len(samples)) if samples[i - 1] < 0 <= samples[i])
    duration_s = n_frames / rate
    estimated_hz = crossings / duration_s if duration_s else 0
    return round(estimated_hz, 1)
