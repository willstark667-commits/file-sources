"""
Bridge between NanoBrain (the cognitive/decision layer: nodes,
personas, the global workspace) and GenesisOS (the deterministic
substrate: virtual filesystem, virtual CPU, scheduler).

This is the concrete implementation of the design principle from the
original architecture doc:

    "the network is the cognitive core / decision layer, and it
    invokes OS-level functions (read file, run script, spawn process)
    when it needs exact operations."

NanoBrain nodes/agents never do raw file I/O against GenesisOS's disk
image directly -- they go through this bridge, which calls into
GenesisOS's own VirtualFileSystem / VirtualCPU. That keeps the
boundary honest: fuzzy/learned decisions stay in NanoBrain, exact
operations stay in GenesisOS.

Import path assumption: GenesisOS/ and NanoBrain/ are sibling
directories (as shipped). Adjust GENESIS_OS_PATH if you place them
elsewhere.
"""

import os
import sys

GENESIS_OS_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "GenesisOS")


class OSBridgeError(Exception):
    pass


class GenesisOSBridge:
    """Lazily imports GenesisOS so NanoBrain still runs standalone if
    GenesisOS isn't present -- the bridge is optional, not required."""

    def __init__(self, genesis_os_path=None):
        self.path = genesis_os_path or GENESIS_OS_PATH
        self.available = False
        self.last_error = None
        self.fs = None
        self.cpu = None
        self._try_connect()

    def _try_connect(self):
        if not os.path.isdir(self.path):
            return
        if self.path not in sys.path:
            sys.path.insert(0, self.path)
        try:
            from genesis_os.kernel.filesystem import VirtualFileSystem
            from genesis_os.kernel.memory import VirtualRAM
            from genesis_os.kernel.cpu import VirtualCPU

            self.fs = VirtualFileSystem()
            self.fs.mount()
            ram = VirtualRAM()
            self.cpu = VirtualCPU(ram)
            self.available = True
        except Exception as e:
            self.available = False
            self.last_error = str(e)

    # -- exact operations, invoked BY NanoBrain's decision layer -----------
    def read_file(self, path):
        if not self.available:
            raise OSBridgeError("GenesisOS not available -- is it installed as a sibling directory?")
        return self.fs.read_file(path)

    def write_file(self, path, content):
        if not self.available:
            raise OSBridgeError("GenesisOS not available.")
        self.fs.write_file(path, content)
        self.fs.flush()

    def list_dir(self, prefix="/"):
        if not self.available:
            raise OSBridgeError("GenesisOS not available.")
        return self.fs.list_dir(prefix)

    def run_asm(self, source, max_steps=10000):
        """Run a small assembly program on GenesisOS's virtual CPU --
        this is the 'exact, deterministic operation' NanoBrain's
        learned/fuzzy layer can never itself guarantee."""
        if not self.available:
            raise OSBridgeError("GenesisOS not available.")
        self.cpu.assemble(source)
        self.cpu.run(max_steps=max_steps)
        return list(self.cpu.registers) if hasattr(self.cpu, "registers") else None

    def status(self):
        return {
            "available": self.available,
            "genesis_os_path": self.path,
            "fs_mounted": self.fs is not None,
            "last_error": self.last_error,
        }
