"""
The real version of "autonomous building": Ollama proposes a change,
self_repair.py's backup/verify/rollback wrapper is what makes it safe
to actually apply. Nothing here removes the need for a human to read
the diff before trusting it long-term -- what it removes is the risk
of a bad generated change leaving your file more broken than before.

Loop, each step logged:
  1. Read target file's current content.
  2. Ask Ollama to fix/improve it given a description of the problem.
  3. self_repair.safe_apply(): backup -> write candidate -> syntax/AST/
     import checks (+ your own test command if you give one) -> keep
     if it passes, auto-restore if it fails.
  4. Report what happened. Never applies silently -- always returns a
     diff-sized summary of what changed.
"""

import difflib
import os

from . import ollama_bridge
from .self_repair import SelfRepairManager

AUTO_IMPROVE_SYSTEM_PROMPT = """You are fixing/improving a single Python file.
Output ONLY the complete corrected file content -- no markdown fences, no
explanation before or after. Preserve everything that already works; change
only what's needed to address the described problem."""


class AutoImproveResult:
    def __init__(self, applied, backup_path, diff_lines, failure_reason=None):
        self.applied = applied
        self.backup_path = backup_path
        self.diff_lines = diff_lines
        self.failure_reason = failure_reason


def auto_improve_file(target_path: str, problem_description: str, backup_dir=None,
                      test_command=None, model=None) -> AutoImproveResult:
    if not os.path.exists(target_path):
        return AutoImproveResult(False, None, [], failure_reason=f"file not found: {target_path}")

    with open(target_path, "r") as fh:
        original = fh.read()

    prompt = (f"Problem to fix in this file:\n{problem_description}\n\n"
             f"Current file content:\n{original}")
    new_content = ollama_bridge.summarize(prompt, instruction=AUTO_IMPROVE_SYSTEM_PROMPT, model=model)

    if new_content.startswith("[Ollama unavailable]"):
        return AutoImproveResult(False, None, [], failure_reason=new_content)

    new_content = new_content.strip()
    if new_content.startswith("```"):
        lines = new_content.splitlines()
        new_content = "\n".join(lines[1:-1]) if lines[-1].strip() == "```" else "\n".join(lines[1:])

    backup_dir = backup_dir or os.path.join(os.path.dirname(target_path), ".backups")
    mgr = SelfRepairManager(target_file=target_path, backup_dir=backup_dir, test_command=test_command)

    def apply_change():
        with open(target_path, "w") as fh:
            fh.write(new_content)

    result = mgr.safe_apply(apply_change)

    diff_lines = list(difflib.unified_diff(
        original.splitlines(keepends=True), new_content.splitlines(keepends=True),
        fromfile="before", tofile="after (proposed)", n=2,
    ))[:80]  # cap the diff shown -- full diffs can be huge

    return AutoImproveResult(result.applied, result.backup_path, diff_lines, result.failure_reason)
