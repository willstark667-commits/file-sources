# AshleyStack — GenesisOS + NanoBrain combined

Two sibling projects, meant to run side by side:

```
AshleyStack/
├── GenesisOS/   the deterministic substrate: virtual filesystem,
│                virtual CPU, boot sequence, Tk desktop shell
└── NanoBrain/   the cognitive/decision layer: neuron-nodes, personas
                 (Ashley/Cortana/Generic), a Global Workspace for
                 multi-agent coordination, chat via Ollama -- and a
                 bridge (nanobrain/os_bridge.py) that calls into
                 GenesisOS for exact operations (file I/O, running
                 assembly) when NanoBrain's learned/fuzzy layer needs
                 something deterministic done.
```

They must stay **siblings** (same parent folder) for
`NanoBrain/nanobrain/os_bridge.py` to auto-detect GenesisOS. Each also
runs completely standalone if you only want one of them.

## Quick start
```bash
cd NanoBrain
python3 launcher.py
```
Then in the shell tab: `osbridge` to confirm it found GenesisOS,
`agents` to see the Ashley/Cortana/Generic hierarchy, `think` to run a
Global Workspace competition+broadcast cycle, `whiteboard` to see
what's currently "in mind."

See `GenesisOS/README.md` and `NanoBrain/README.md` for the full
details of each half.
