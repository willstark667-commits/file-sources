"""
Ashley AI Studio -- Tkinter dashboard console, same CRT aesthetic as
GenesisOS and NanoBrain. Six tabs:

  Overview   -- stack status (NanoBrain / GenesisOS / Ollama), quick actions
  Chat       -- talk to Ashley/Cortana/Generic, pick which agent replies
  Agents     -- the Global Workspace: run cycles, see broadcasts/whiteboard
  Files      -- non-destructive scan + search + duplicate detection
  System     -- GenesisOS bridge: virtual filesystem browser + run assembly
  Performance -- live CPU/RAM/GPU snapshot + plain-language advice

If NanoBrain or GenesisOS aren't present as sibling directories, each
tab that needs them degrades gracefully and says so instead of crashing.
"""

import os
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog

from . import config
from .system_monitor import SystemMonitor
from .duplicate_detector import DuplicateDetector

BG = "#0a0f0a"
PANEL_BG = "#0e140e"
FG = "#33ff66"
ACCENT = "#ffb000"
DIM = "#1c6b34"
ERR = "#ff5555"
FONT = ("Consolas", 12)
FONT_SMALL = ("Consolas", 10)
FONT_BIG = ("Consolas", 16, "bold")


class AshleyStudio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ashley AI Studio")
        self.configure(bg=BG)
        self.geometry("1140x760")

        config.ensure_dirs()

        self.nb_ok = False
        self.gos_ok = False
        self.nb_load_error = None
        self.gos_load_error = None
        self.agents = {}
        self.workspace = None
        self.scanner = None
        self.ollama_bridge = None
        self.os_bridge = None
        self.chat_history = {}
        self.last_scan_records = []
        self.monitor = SystemMonitor()
        self.dupe_detector = DuplicateDetector()
        self._load_stack()

        style = ttk.Style()
        style.theme_use("default")
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL_BG, foreground=FG, padding=(12, 7))
        style.map("TNotebook.Tab", background=[("selected", DIM)])

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill="both", expand=True)

        self.overview_tab = tk.Frame(self.tabs, bg=BG)
        self.chat_tab = tk.Frame(self.tabs, bg=BG)
        self.agents_tab = tk.Frame(self.tabs, bg=BG)
        self.files_tab = tk.Frame(self.tabs, bg=BG)
        self.system_tab = tk.Frame(self.tabs, bg=BG)
        self.perf_tab = tk.Frame(self.tabs, bg=BG)
        self.tools_tab = tk.Frame(self.tabs, bg=BG)

        self.tabs.add(self.overview_tab, text="Overview")
        self.tabs.add(self.chat_tab, text="Chat")
        self.tabs.add(self.agents_tab, text="Agents / Workspace")
        self.tabs.add(self.files_tab, text="Files")
        self.tabs.add(self.system_tab, text="System")
        self.tabs.add(self.perf_tab, text="Performance")
        self.tabs.add(self.tools_tab, text="Tools")

        self._build_overview_tab()
        self._build_chat_tab()
        self._build_agents_tab()
        self._build_files_tab()
        self._build_system_tab()
        self._build_perf_tab()
        self._build_tools_tab()

    # ======================================================================
    def _load_stack(self):
        if config.nanobrain_available():
            try:
                from nanobrain.agents import build_default_hierarchy
                from nanobrain import scanner as nb_scanner
                from nanobrain import ollama_bridge as nb_ollama
                from nanobrain.chat import ChatHistory
                from nanobrain.tool_registry import ToolRegistry
                from nanobrain import tool_generator as nb_tool_generator
                self.agents, self.workspace = build_default_hierarchy()
                self.scanner = nb_scanner
                self.ollama_bridge = nb_ollama
                self.tool_registry = ToolRegistry()
                self.tool_generator = nb_tool_generator
                self.chat_history = {name: ChatHistory(path=os.path.join(
                    config.DATA_DIR, f"chat_{name.lower()}.json")) for name in self.agents}
                self.nb_ok = True
            except Exception as e:
                self.nb_load_error = str(e)
        if config.genesisos_available() and self.nb_ok:
            try:
                from nanobrain.os_bridge import GenesisOSBridge
                self.os_bridge = GenesisOSBridge()
                self.gos_ok = self.os_bridge.available
                if not self.gos_ok:
                    self.gos_load_error = self.os_bridge.last_error
            except Exception as e:
                self.gos_load_error = str(e)

    # ======================================================================
    # OVERVIEW TAB
    # ======================================================================
    def _build_overview_tab(self):
        tk.Label(self.overview_tab, text="ASHLEY AI STUDIO", bg=BG, fg=ACCENT, font=FONT_BIG).pack(pady=(16, 4))
        tk.Label(self.overview_tab, text="console for NanoBrain + GenesisOS", bg=BG, fg=DIM, font=FONT_SMALL).pack()

        grid = tk.Frame(self.overview_tab, bg=BG)
        grid.pack(pady=20)

        self._status_card(grid, 0, "NanoBrain",
                          "connected" if self.nb_ok else "not found",
                          f"agents: {list(self.agents.keys())}" if self.nb_ok else "expected as sibling dir ../NanoBrain")
        self._status_card(grid, 1, "GenesisOS",
                          "connected" if self.gos_ok else "not found",
                          "virtual filesystem + CPU ready" if self.gos_ok else "expected as sibling dir ../GenesisOS")
        ollama_up = self.ollama_bridge.is_available() if self.ollama_bridge else False
        self._status_card(grid, 2, "Ollama",
                          "reachable" if ollama_up else "not reachable",
                          "local LLM backend for Chat tab" if ollama_up else "run `ollama serve`")

        out = scrolledtext.ScrolledText(self.overview_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                        height=14, borderwidth=0, highlightthickness=0)
        out.pack(fill="both", expand=True, padx=16, pady=(8, 16))
        out.insert("end", self._overview_report())
        out.configure(state="disabled")
        self.overview_output = out

    def _status_card(self, parent, col, name, status, detail):
        ok = status in ("connected", "reachable")
        color = FG if ok else ERR
        card = tk.Frame(parent, bg=PANEL_BG, padx=16, pady=12, highlightbackground=DIM, highlightthickness=1)
        card.grid(row=0, column=col, padx=10)
        tk.Label(card, text=name, bg=PANEL_BG, fg=ACCENT, font=FONT).pack()
        tk.Label(card, text=status, bg=PANEL_BG, fg=color, font=FONT_SMALL).pack()
        tk.Label(card, text=detail, bg=PANEL_BG, fg=DIM, font=("Consolas", 8), wraplength=220).pack(pady=(4, 0))

    def _overview_report(self):
        lines = ["=" * 70, "  STACK REPORT", "=" * 70, ""]
        lines.append(f"NanoBrain:  {'OK' if self.nb_ok else 'MISSING -- ' + (self.nb_load_error or 'directory not found')}")
        lines.append(f"GenesisOS:  {'OK' if self.gos_ok else 'MISSING -- ' + (self.gos_load_error or 'directory not found')}")
        if self.nb_ok:
            lines.append("")
            lines.append("agents registered on the shared Global Workspace:")
            for name, agent in self.agents.items():
                traits = {k: round(v, 2) for k, v in agent.persona.traits.items()}
                lines.append(f"  - {name}: {len(agent.network.nodes)} nodes, traits={traits}")
        lines.append("")
        lines.append("Chat: talk to an agent.  Agents/Workspace: run Global Workspace cycles.")
        lines.append("Files: scan+search+dedupe a directory.  System: GenesisOS virtual FS/CPU.")
        lines.append("Performance: live CPU/RAM/GPU snapshot + advice.")
        return "\n".join(lines)

    # ======================================================================
    # CHAT TAB
    # ======================================================================
    def _build_chat_tab(self):
        if not self.nb_ok:
            tk.Label(self.chat_tab, text="NanoBrain not found -- Chat tab needs it (sibling ../NanoBrain).",
                    bg=BG, fg=ERR, font=FONT).pack(pady=40)
            return

        top = tk.Frame(self.chat_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Label(top, text="talking with:", bg=BG, fg=DIM, font=FONT_SMALL).pack(side="left")
        self.agent_choice = tk.StringVar(value=list(self.agents.keys())[0])
        for name in self.agents.keys():
            tk.Radiobutton(top, text=name, variable=self.agent_choice, value=name,
                          bg=BG, fg=FG, selectcolor=PANEL_BG, activebackground=BG,
                          font=FONT_SMALL, command=self._switch_chat_agent).pack(side="left", padx=6)

        self.chat_box = scrolledtext.ScrolledText(self.chat_tab, bg=BG, fg=FG, font=FONT,
                                                   wrap="word", borderwidth=0, highlightthickness=0)
        self.chat_box.pack(fill="both", expand=True, padx=8, pady=(0, 8))
        self.chat_box.tag_configure("user", foreground=ACCENT)
        self.chat_box.configure(state="disabled")
        self._load_chat_display()

        bottom = tk.Frame(self.chat_tab, bg=BG)
        bottom.pack(fill="x", padx=8, pady=(0, 8))
        self.chat_entry = tk.Entry(bottom, bg=BG, fg=FG, insertbackground=FG, font=FONT,
                                   borderwidth=0, highlightthickness=1, highlightbackground=FG)
        self.chat_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.chat_entry.bind("<Return>", self._send_chat)
        tk.Button(bottom, text="Send", command=self._send_chat, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")

    def _switch_chat_agent(self):
        self._load_chat_display()

    def _load_chat_display(self):
        self.chat_box.configure(state="normal")
        self.chat_box.delete("1.0", "end")
        name = self.agent_choice.get()
        history = self.chat_history.get(name)
        if history:
            for msg in history.recent():
                speaker = name if msg["role"] == "assistant" else "you"
                tag = "user" if msg["role"] == "user" else ()
                self.chat_box.insert("end", f"{speaker}: {msg['content']}\n\n", tag)
        self.chat_box.configure(state="disabled")

    def _send_chat(self, event=None):
        text = self.chat_entry.get().strip()
        if not text:
            return
        self.chat_entry.delete(0, "end")
        name = self.agent_choice.get()
        history = self.chat_history[name]
        history.add("user", text)
        self._append_chat_line("you", text, "user")
        threading.Thread(target=self._get_reply, args=(name, text), daemon=True).start()

    def _append_chat_line(self, speaker, text, tag=None):
        try:
            self.chat_box.configure(state="normal")
            self.chat_box.insert("end", f"{speaker}: {text}\n\n", tag or ())
            self.chat_box.see("end")
            self.chat_box.configure(state="disabled")
        except tk.TclError:
            pass  # window was closed while a background reply was in flight

    def _get_reply(self, agent_name, user_text):
        agent = self.agents[agent_name]
        history = self.chat_history[agent_name]
        if self.ollama_bridge.is_available():
            reply = self.ollama_bridge.chat(history.as_ollama_messages(), system=agent.persona.system_prompt())
        else:
            out, sal = agent.think_and_propose()
            reply = (f"[Ollama not reachable -- fallback path] my node chain read your message "
                     f"and produced output={out:.4f}, salience={sal:.3f}. Start `ollama serve` "
                     f"for a real reply.")
        history.add("assistant", reply)
        # hand the UI update back to the main thread -- Tk widgets aren't
        # safe to touch directly from a background thread
        self.after(0, self._append_chat_line, agent_name, reply)

    # ======================================================================
    # AGENTS / WORKSPACE TAB
    # ======================================================================
    def _build_agents_tab(self):
        if not self.nb_ok:
            tk.Label(self.agents_tab, text="NanoBrain not found -- Agents tab needs it.",
                    bg=BG, fg=ERR, font=FONT).pack(pady=40)
            return

        btns = tk.Frame(self.agents_tab, bg=BG)
        btns.pack(fill="x", padx=8, pady=8)
        tk.Button(btns, text="Run Workspace Cycle", command=self._run_cycle, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        tk.Button(btns, text="Train Selected (10 steps)", command=self._train_selected, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        tk.Button(btns, text="Refresh Status", command=self._refresh_agents, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        self.train_agent_choice = tk.StringVar(value=list(self.agents.keys())[0])
        for name in self.agents.keys():
            tk.Radiobutton(btns, text=name, variable=self.train_agent_choice, value=name,
                          bg=BG, fg=FG, selectcolor=PANEL_BG, activebackground=BG,
                          font=FONT_SMALL).pack(side="left", padx=4)

        self.loss_canvas = tk.Canvas(self.agents_tab, bg=BG, highlightthickness=0, height=120)
        self.loss_canvas.pack(fill="x", padx=8, pady=(0, 4))

        self.agents_output = scrolledtext.ScrolledText(self.agents_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                                        wrap="word", borderwidth=0, highlightthickness=0)
        self.agents_output.pack(fill="both", expand=True, padx=8, pady=8)
        self.agents_output.tag_configure("accent", foreground=ACCENT)
        self._refresh_agents()
        self._draw_loss_chart()

    def _train_selected(self):
        name = self.train_agent_choice.get()
        agent = self.agents[name]
        avg_loss = agent.network.train_joint(epochs=10)
        self.agents_output.configure(state="normal")
        self.agents_output.insert("end", f"trained {name} for 10 steps, avg_loss={avg_loss:.5f}\n", "accent")
        self.agents_output.see("end")
        self.agents_output.configure(state="disabled")
        self._draw_loss_chart()

    def _draw_loss_chart(self):
        """Real loss-over-time plot from each agent's actual
        network.loss_history -- a genuine training monitor, not a
        decorative animation."""
        self.loss_canvas.delete("all")
        self.update_idletasks()
        w = max(self.loss_canvas.winfo_width(), 400)
        h = 120
        colors = {"Ashley": ACCENT, "Cortana": FG, "Generic": DIM}

        all_losses = [agent.network.loss_history for agent in self.agents.values()]
        max_loss = max((max(hist) for hist in all_losses if hist), default=1.0) or 1.0

        self.loss_canvas.create_text(6, 8, anchor="nw", text="loss history (lower = better)",
                                     fill=DIM, font=("Consolas", 8))
        for name, agent in self.agents.items():
            hist = agent.network.loss_history
            if len(hist) < 2:
                continue
            color = colors.get(name, FG)
            points = []
            for i, loss in enumerate(hist):
                x = 10 + (w - 20) * (i / max(1, len(hist) - 1))
                y = h - 10 - (h - 30) * (loss / max_loss)
                points.extend([x, y])
            if len(points) >= 4:
                self.loss_canvas.create_line(*points, fill=color, width=2)
            self.loss_canvas.create_text(w - 60, 20 + list(self.agents.keys()).index(name) * 12,
                                         anchor="w", text=name, fill=color, font=("Consolas", 8))

    def _refresh_agents(self):
        self.agents_output.configure(state="normal")
        self.agents_output.delete("1.0", "end")
        for name, agent in self.agents.items():
            s = agent.status()
            self.agents_output.insert("end", f"{name}: nodes={s['nodes']} maturity={s['maturity_pct']}% "
                                             f"inbox={s['inbox_size']}\n")
        self.agents_output.insert("end", "\nworkspace whiteboard (working memory):\n", "accent")
        for item in self.workspace.whiteboard():
            self.agents_output.insert("end", f"  [{item['source']}] salience={item['salience']:.3f} "
                                             f"{item['content']}\n")
        self.agents_output.configure(state="disabled")

    def _run_cycle(self):
        for name, agent in self.agents.items():
            agent.think_and_propose()
        winners = self.workspace.run_cycle()
        self.agents_output.configure(state="normal")
        if winners:
            for w in winners:
                self.agents_output.insert("end", f">>> broadcast winner: {w.source} (salience={w.salience:.3f})\n",
                                          "accent")
        else:
            self.agents_output.insert("end", "no winner this cycle.\n")
        self.agents_output.see("end")
        self.agents_output.configure(state="disabled")
        self._refresh_agents()

    # ======================================================================
    # FILES TAB
    # ======================================================================
    def _build_files_tab(self):
        if not self.nb_ok:
            tk.Label(self.files_tab, text="NanoBrain not found -- Files tab needs it.",
                    bg=BG, fg=ERR, font=FONT).pack(pady=40)
            return

        top = tk.Frame(self.files_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Button(top, text="Choose Directory + Scan (read-only)", command=self._scan_dir,
                 bg=PANEL_BG, fg=FG, activebackground=DIM, borderwidth=0).pack(side="left")
        tk.Button(top, text="Find Exact Duplicates", command=self._find_duplicates,
                 bg=PANEL_BG, fg=FG, activebackground=DIM, borderwidth=0).pack(side="left", padx=6)
        self.search_entry = tk.Entry(top, bg=BG, fg=FG, insertbackground=FG, font=FONT_SMALL,
                                     borderwidth=0, highlightthickness=1, highlightbackground=FG)
        self.search_entry.pack(side="left", fill="x", expand=True, padx=8)
        self.search_entry.bind("<Return>", self._search_files)
        tk.Button(top, text="Search", command=self._search_files, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")

        self.files_output = scrolledtext.ScrolledText(self.files_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                                       wrap="word", borderwidth=0, highlightthickness=0)
        self.files_output.pack(fill="both", expand=True, padx=8, pady=8)
        self.files_output.tag_configure("accent", foreground=ACCENT)
        self.files_output.insert("end", "choose a directory to scan (metadata + short preview only -- "
                                        "nothing is ever modified).\n")
        self.files_output.configure(state="disabled")
        self.scanned_dir = None

    def _scan_dir(self):
        path = filedialog.askdirectory()
        if not path:
            return
        self.scanned_dir = path
        self._files_print(f"scanning {path} (read-only)...\n")
        records = self.scanner.scan_directory(path)
        self.last_scan_records = records
        self._files_print(f"indexed {len(records)} files.\n")
        for r in records[:100]:
            self._files_print(f"  {r['filename']}  ({r['size_bytes']} bytes)\n")

    def _find_duplicates(self):
        if not self.scanned_dir:
            self._files_print("scan a directory first.\n")
            return
        self._files_print(f"\nhashing files in {self.scanned_dir} for exact duplicates...\n", "accent")
        groups = self.dupe_detector.find_exact_duplicates(self.scanned_dir)
        if not groups:
            self._files_print("no exact duplicates found.\n")
            return
        for g in groups:
            self._files_print(f"  duplicate set ({len(g.paths)} files):\n")
            for p in g.paths:
                self._files_print(f"    {p}\n")

    def _search_files(self, event=None):
        kw = self.search_entry.get().strip()
        if not kw:
            return
        hits = self.scanner.search_keyword(kw)
        self._files_print(f"\nsearch '{kw}': {len(hits)} hit(s)\n")
        for h in hits[:50]:
            self._files_print(f"  {h['filename']}  {h['path']}\n")

    def _files_print(self, text, tag=None):
        self.files_output.configure(state="normal")
        self.files_output.insert("end", text, tag or ())
        self.files_output.see("end")
        self.files_output.configure(state="disabled")

    # ======================================================================
    # SYSTEM TAB (GenesisOS bridge)
    # ======================================================================
    def _build_system_tab(self):
        if not self.gos_ok:
            msg = "GenesisOS bridge not available."
            if self.nb_ok and self.os_bridge:
                msg += f" ({self.os_bridge.last_error})"
            elif not config.genesisos_available():
                msg += " (no sibling ../GenesisOS directory found)"
            tk.Label(self.system_tab, text=msg, bg=BG, fg=ERR, font=FONT, wraplength=800).pack(pady=40)
            return

        top = tk.Frame(self.system_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Button(top, text="List virtual filesystem", command=self._list_vfs, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left", padx=(0, 6))
        tk.Button(top, text="Run sample ASM", command=self._run_sample_asm, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")

        self.system_output = scrolledtext.ScrolledText(self.system_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                                        wrap="word", borderwidth=0, highlightthickness=0)
        self.system_output.pack(fill="both", expand=True, padx=8, pady=8)
        self.system_output.insert("end", "GenesisOS bridge is live -- NanoBrain agents can invoke this "
                                         "virtual filesystem/CPU for exact operations.\n\n")
        self.system_output.configure(state="disabled")

    def _sys_print(self, text):
        self.system_output.configure(state="normal")
        self.system_output.insert("end", text + "\n")
        self.system_output.see("end")
        self.system_output.configure(state="disabled")

    def _list_vfs(self):
        try:
            files = self.os_bridge.list_dir("/")
            self._sys_print("virtual filesystem:\n  " + "\n  ".join(files))
        except Exception as e:
            self._sys_print(f"error: {e}")

    def _run_sample_asm(self):
        try:
            regs = self.os_bridge.run_asm("MOV R0, 5\nMOV R1, 3\nADD R0, R1\nHALT")
            self._sys_print(f"ran sample ASM (MOV/ADD/HALT). register names: {regs}")
        except Exception as e:
            self._sys_print(f"error: {e}")

    # ======================================================================
    # PERFORMANCE TAB (system_monitor.py)
    # ======================================================================
    def _build_perf_tab(self):
        top = tk.Frame(self.perf_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Button(top, text="Take Snapshot", command=self._take_snapshot, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")
        if self.nb_ok:
            tk.Button(top, text="Benchmark Ollama", command=self._benchmark_ollama, bg=PANEL_BG, fg=FG,
                     activebackground=DIM, borderwidth=0).pack(side="left", padx=6)
        tk.Label(top, text="reads CPU/RAM/GPU via OS-safe APIs (psutil / nvidia-smi) -- "
                          "no vendor driver access.", bg=BG, fg=DIM, font=("Consolas", 8)).pack(side="left", padx=10)

        self.perf_output = scrolledtext.ScrolledText(self.perf_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                                      wrap="word", borderwidth=0, highlightthickness=0)
        self.perf_output.pack(fill="both", expand=True, padx=8, pady=8)
        self.perf_output.tag_configure("accent", foreground=ACCENT)
        self.perf_output.tag_configure("err", foreground=ERR)
        self.perf_output.insert("end", "click 'Take Snapshot' for a live CPU/RAM/GPU read plus "
                                       "plain-language advice (e.g. VRAM pressure, thermal throttling).\n")
        self.perf_output.configure(state="disabled")

    def _take_snapshot(self):
        snap = self.monitor.snapshot()
        advice = self.monitor.recommend(snap)
        self.perf_output.configure(state="normal")
        self.perf_output.delete("1.0", "end")
        self.perf_output.insert("end", f"OS: {snap.os_name}\n")
        self.perf_output.insert("end", f"CPU: {snap.cpu_name}  ({snap.cpu_cores_physical} physical / "
                                       f"{snap.cpu_cores_logical} logical cores)\n")
        self.perf_output.insert("end", f"CPU utilization: {snap.cpu_utilization_pct}%\n")
        if snap.cpu_temp_c:
            self.perf_output.insert("end", f"CPU temp: {snap.cpu_temp_c}°C\n")
        self.perf_output.insert("end", f"RAM: {snap.ram_used_gb}/{snap.ram_total_gb} GB used "
                                       f"({snap.ram_available_gb} GB available)\n")
        for gpu in snap.gpus:
            self.perf_output.insert("end", f"GPU: {gpu.name}")
            if gpu.memory_total_mb:
                self.perf_output.insert("end", f"  VRAM {gpu.memory_used_mb}/{gpu.memory_total_mb} MB")
            if gpu.temperature_c:
                self.perf_output.insert("end", f"  {gpu.temperature_c}°C")
            self.perf_output.insert("end", "\n")
        if snap.notes:
            for n in snap.notes:
                self.perf_output.insert("end", f"note: {n}\n", "err")
        self.perf_output.insert("end", "\nadvice:\n", "accent")
        for a in advice:
            self.perf_output.insert("end", f"  - {a}\n")
        self.perf_output.configure(state="disabled")

    def _benchmark_ollama(self):
        self.perf_output.configure(state="normal")
        self.perf_output.insert("end", "\nbenchmarking Ollama (warm-up + timed run)...\n", "accent")
        self.perf_output.configure(state="disabled")
        threading.Thread(target=self._benchmark_ollama_bg, daemon=True).start()

    def _benchmark_ollama_bg(self):
        self.ollama_bridge.benchmark(num_predict=1)  # warm-up, discard
        result = self.ollama_bridge.benchmark()
        self.after(0, self._show_benchmark_result, result)

    def _show_benchmark_result(self, result):
        self.perf_output.configure(state="normal")
        if "error" in result:
            self.perf_output.insert("end", f"  {result['error']}\n", "err")
        else:
            self.perf_output.insert("end", f"  model={result['model']}  "
                                          f"tokens/sec={result['tokens_per_sec']}  "
                                          f"wall_time={result['wall_time_s']}s  "
                                          f"load_time={result['load_duration_s']}s\n")
        self.perf_output.see("end")
        self.perf_output.configure(state="disabled")

    # ======================================================================
    # TOOLS TAB (external tool detection + Ollama tool generation)
    # ======================================================================
    def _build_tools_tab(self):
        if not self.nb_ok:
            tk.Label(self.tools_tab, text="NanoBrain not found -- Tools tab needs it.",
                    bg=BG, fg=ERR, font=FONT).pack(pady=40)
            return

        top = tk.Frame(self.tools_tab, bg=BG)
        top.pack(fill="x", padx=8, pady=8)
        tk.Button(top, text="Scan for Installed Tools", command=self._scan_tools, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")
        tk.Label(top, text="checks PATH for claude/codex CLIs, git, docker, node, ollama, etc. -- "
                          "read-only detection, not a hook into any running session.",
                bg=BG, fg=DIM, font=("Consolas", 8), wraplength=500).pack(side="left", padx=10)

        gen_frame = tk.Frame(self.tools_tab, bg=BG)
        gen_frame.pack(fill="x", padx=8, pady=(0, 8))
        tk.Label(gen_frame, text="generate a new tool:", bg=BG, fg=DIM, font=FONT_SMALL).pack(side="left")
        self.tool_desc_entry = tk.Entry(gen_frame, bg=BG, fg=FG, insertbackground=FG, font=FONT_SMALL,
                                        borderwidth=0, highlightthickness=1, highlightbackground=FG)
        self.tool_desc_entry.pack(side="left", fill="x", expand=True, padx=8)
        self.tool_name_entry = tk.Entry(gen_frame, bg=BG, fg=FG, insertbackground=FG, font=FONT_SMALL,
                                        width=18, borderwidth=0, highlightthickness=1, highlightbackground=FG)
        self.tool_name_entry.insert(0, "tool_name")
        self.tool_name_entry.pack(side="left", padx=(0, 8))
        tk.Button(gen_frame, text="Generate + Test", command=self._generate_tool, bg=PANEL_BG, fg=FG,
                 activebackground=DIM, borderwidth=0).pack(side="left")

        self.tools_output = scrolledtext.ScrolledText(self.tools_tab, bg=BG, fg=FG, font=FONT_SMALL,
                                                       wrap="word", borderwidth=0, highlightthickness=0)
        self.tools_output.pack(fill="both", expand=True, padx=8, pady=8)
        self.tools_output.tag_configure("accent", foreground=ACCENT)
        self.tools_output.tag_configure("err", foreground=ERR)
        self.tools_output.insert("end", "click 'Scan for Installed Tools' to detect what's on this "
                                        "machine, or describe a tool below and Ollama will write it -- "
                                        "generated code is sandbox-tested (syntax + isolated dry-run "
                                        "in a throwaway subprocess) before it's ever trusted.\n")
        self.tools_output.configure(state="disabled")

    def _tools_print(self, text, tag=None):
        self.tools_output.configure(state="normal")
        self.tools_output.insert("end", text + "\n", tag or ())
        self.tools_output.see("end")
        self.tools_output.configure(state="disabled")

    def _scan_tools(self):
        self.tool_registry.scan()
        self._tools_print(self.tool_registry.report())

    def _generate_tool(self):
        desc = self.tool_desc_entry.get().strip()
        name = self.tool_name_entry.get().strip() or "generated_tool"
        if not desc:
            self._tools_print("describe what the tool should do first.")
            return
        self._tools_print(f"\nasking Ollama to write '{name}': {desc}", "accent")
        threading.Thread(target=self._generate_tool_bg, args=(desc, name), daemon=True).start()

    def _generate_tool_bg(self, desc, name):
        result = self.tool_generator.generate_tool(desc, name)
        self.after(0, self._show_tool_result, result)

    def _show_tool_result(self, result):
        if result.accepted:
            self._tools_print(f"ACCEPTED -- saved to {result.path}", "accent")
            self.tool_registry.register_generated(result.name, {
                "description": self.tool_desc_entry.get().strip(), "path": result.path,
            })
        else:
            self._tools_print(f"REJECTED -- {result.error}", "err")
            self._tools_print("(the candidate code was discarded; nothing was added to your project)")


def run():
    config.ensure_dirs()
    app = AshleyStudio()
    app.mainloop()
