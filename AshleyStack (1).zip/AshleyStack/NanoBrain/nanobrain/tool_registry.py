"""
Tool Registry -- detects external command-line tools actually installed
on this machine, and lets agents invoke them as subprocess tools.

Honest scope note: there's no API or protocol that lets one local
program reach into a *running* Claude.ai chat session or a Codex
session and use "their" connectors/skills -- those live server-side
in Anthropic's/OpenAI's own infrastructure, not on your filesystem.
What IS real and useful: if you have the `claude` (Claude Code) or
`codex` CLI installed, this registry detects the binary on PATH and
lets your own agents shell out to it as an external tool -- the same
mechanism used here for git, docker, node, ollama, etc. That's a
normal, well-understood integration pattern (subprocess + PATH
detection), not a hook into another vendor's live session.
"""

import json
import os
import shutil
import subprocess
import time

from . import config

# name -> (candidate binary names, version flag)
KNOWN_TOOLS = {
    "claude_code": (["claude"], "--version"),
    "codex_cli":   (["codex"], "--version"),
    "git":         (["git"], "--version"),
    "docker":      (["docker"], "--version"),
    "node":        (["node"], "--version"),
    "npm":         (["npm"], "--version"),
    "python3":     (["python3", "python"], "--version"),
    "gh_cli":      (["gh"], "--version"),
    "ollama_cli":  (["ollama"], "--version"),
    "ffmpeg":      (["ffmpeg"], "-version"),
    "qemu":        (["qemu-system-x86_64"], "--version"),
    "wine":        (["wine"], "--version"),
}


class ToolRegistry:
    def __init__(self, path=None):
        self.path = path or os.path.join(config.DATA_DIR, "tool_registry.json")
        self.detected = {}   # name -> {path, version, available}
        self.generated = {}  # name -> metadata dict, see tool_generator.py
        self._load()

    def _load(self):
        if os.path.exists(self.path):
            with open(self.path, "r") as fh:
                data = json.load(fh)
                self.generated = data.get("generated", {})

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        with open(self.path, "w") as fh:
            json.dump({"generated": self.generated}, fh, indent=2)

    def scan(self):
        """Re-detect installed tools. Cheap and safe to call often --
        this only checks PATH + runs --version, never anything that
        modifies state."""
        self.detected = {}
        for name, (candidates, version_flag) in KNOWN_TOOLS.items():
            found_path = None
            for candidate in candidates:
                p = shutil.which(candidate)
                if p:
                    found_path = p
                    break
            entry = {"path": found_path, "available": found_path is not None, "version": None}
            if found_path:
                try:
                    result = subprocess.run([found_path, version_flag], capture_output=True,
                                            text=True, timeout=5)
                    entry["version"] = (result.stdout or result.stderr).strip().splitlines()[0][:120]
                except Exception as e:
                    entry["version"] = f"(version check failed: {e})"
            self.detected[name] = entry
        return self.detected

    def run_tool(self, name, args=None, timeout=30):
        """Shell out to a detected external tool. Returns (returncode, stdout, stderr).
        Refuses to run anything not found by scan() first."""
        args = args or []
        entry = self.detected.get(name)
        if not entry or not entry["available"]:
            raise ValueError(f"'{name}' is not installed/detected. Run scan() first, "
                             f"or check the exact binary name.")
        result = subprocess.run([entry["path"]] + args, capture_output=True, text=True, timeout=timeout)
        return result.returncode, result.stdout, result.stderr

    def register_generated(self, name, metadata):
        self.generated[name] = metadata
        self.save()

    def report(self):
        lines = ["detected external tools:"]
        for name, entry in self.detected.items():
            status = f"OK  {entry['version']}" if entry["available"] else "not found"
            lines.append(f"  {name:14s} {status}")
        if self.generated:
            lines.append("\ngenerated tools (Ollama-written, sandbox-tested):")
            for name, meta in self.generated.items():
                lines.append(f"  {name:14s} {meta.get('description', '')}")
        return "\n".join(lines)
